import torch
from pdb_project.models.constant import ConstantPredictor


def test_constant_predictor_forward() -> None:
    y_train = torch.tensor([[1.0, 10.0, 0.5], [3.0, 20.0, 0.7]])
    model = ConstantPredictor.fit(y_train)

    batch_size = 4
    y_hat = model.predict(batch_size)
    assert y_hat.shape == (batch_size, 3)
    assert torch.allclose(y_hat[0], torch.tensor([2.0, 15.0, 0.6]))
