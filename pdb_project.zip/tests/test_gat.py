import torch
from pdb_project.data.dataset import FluorescenceDataset
from pdb_project.models.gat import GATFluorescenceModel
from torch_geometric.data import Batch


def test_gat_forward(repo_root) -> None:
    ds = FluorescenceDataset(
        labels_csv=repo_root / "data" / "labels.csv",
        repo_root=repo_root,
    )
    s0, s1 = ds[0], ds[1]
    protein_batch = Batch.from_data_list([s0["protein"], s1["protein"]])
    ligand_batch = Batch.from_data_list([s0["ligand"], s1["ligand"]])
    kDa = torch.stack([s0["kDa"], s1["kDa"]], dim=0)  # noqa: N806

    model = GATFluorescenceModel(
        node_in_protein=20,
        node_in_ligand=4,
        hidden=32,
        num_layers=2,
        heads=2,
        rbf_k=8,
        protein_rbf_high=20.0,
        ligand_rbf_high=10.0,
        out_dim=3,
    )
    y_hat = model(protein_batch, ligand_batch, kDa)
    assert y_hat.shape == (2, 3)
