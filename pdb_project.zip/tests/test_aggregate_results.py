"""Tests for scripts/aggregate_results.py."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

SCRIPTS_DIR = Path(__file__).resolve().parent.parent / "scripts"
sys.path.insert(0, str(SCRIPTS_DIR))

from aggregate_results import (  # noqa: E402
    fold_maes,
    load_results,
    paired_bootstrap_ci,
    render_markdown,
)


def _fake_result(
    model: str, per_fold_maes: dict[str, list[float]], per_fold_r2: dict[str, list[float]]
) -> dict:
    per_fold = [
        {f"mae/{t}": per_fold_maes[t][i] for t in per_fold_maes}
        | {f"r2/{t}": per_fold_r2[t][i] for t in per_fold_r2}
        | {"mae/overall": float(np.mean([per_fold_maes[t][i] for t in per_fold_maes]))}
        for i in range(len(next(iter(per_fold_maes.values()))))
    ]
    aggregate = {}
    for t in per_fold_maes:
        aggregate[f"mae/{t}"] = {
            "mean": float(np.mean(per_fold_maes[t])),
            "std": float(np.std(per_fold_maes[t])),
        }
        aggregate[f"r2/{t}"] = {
            "mean": float(np.mean(per_fold_r2[t])),
            "std": float(np.std(per_fold_r2[t])),
        }
    return {"model": model, "per_fold": per_fold, "aggregate": aggregate}


def test_load_results_roundtrip(tmp_path: Path) -> None:
    r = _fake_result(
        "constant",
        {"brightness": [10.0, 12.0], "emission": [50.0, 55.0], "qy": [0.2, 0.3]},
        {"brightness": [0.0, 0.0], "emission": [0.0, 0.0], "qy": [0.0, 0.0]},
    )
    p = tmp_path / "cv_constant.json"
    p.write_text(json.dumps(r))
    loaded = load_results([p])
    assert len(loaded) == 1
    assert loaded[0]["model"] == "constant"


def test_paired_bootstrap_deterministic() -> None:
    model = np.array([5.0, 6.0, 4.0, 5.5, 5.2])
    baseline = np.array([10.0, 11.0, 9.0, 10.5, 10.2])
    d1 = paired_bootstrap_ci(model, baseline, n_resamples=2_000, seed=42)
    d2 = paired_bootstrap_ci(model, baseline, n_resamples=2_000, seed=42)
    assert d1 == d2
    mean_diff, lo, hi = d1
    # Model is uniformly 5 points better than baseline → mean diff is ~-5
    assert abs(mean_diff - (-5.0)) < 1e-6
    # CI should lie entirely below zero
    assert hi < 0


def test_paired_bootstrap_no_difference() -> None:
    x = np.array([1.0, 2.0, 3.0, 4.0, 5.0])
    mean_diff, lo, hi = paired_bootstrap_ci(x, x, n_resamples=1_000, seed=0)
    assert mean_diff == 0.0
    assert lo == 0.0
    assert hi == 0.0


def test_fold_maes_extracts_per_target() -> None:
    r = _fake_result(
        "m",
        {"brightness": [10.0, 20.0, 30.0], "emission": [1.0, 2.0, 3.0], "qy": [0.1, 0.2, 0.3]},
        {"brightness": [0, 0, 0], "emission": [0, 0, 0], "qy": [0, 0, 0]},
    )
    arr = fold_maes(r, "brightness")
    assert arr.tolist() == [10.0, 20.0, 30.0]


def test_render_markdown_includes_all_models_and_targets() -> None:
    r1 = _fake_result(
        "constant",
        {"brightness": [10.0, 12.0], "emission": [50.0, 55.0], "qy": [0.2, 0.3]},
        {"brightness": [0.0, 0.0], "emission": [0.0, 0.0], "qy": [0.0, 0.0]},
    )
    r2 = _fake_result(
        "schnet",
        {"brightness": [5.0, 6.0], "emission": [25.0, 30.0], "qy": [0.1, 0.15]},
        {"brightness": [0.5, 0.6], "emission": [0.7, 0.8], "qy": [0.3, 0.4]},
    )
    md = render_markdown(
        [r1, r2], baseline_name="constant", bootstrap_resamples=500, bootstrap_seed=0
    )
    for target in ("brightness", "emission", "qy"):
        assert target in md
    assert "constant" in md
    assert "schnet" in md
    assert "Paired bootstrap" in md


def test_render_markdown_without_baseline_skips_bootstrap() -> None:
    r1 = _fake_result(
        "m1",
        {"brightness": [1.0], "emission": [500.0], "qy": [0.5]},
        {"brightness": [0.0], "emission": [0.0], "qy": [0.0]},
    )
    md = render_markdown([r1], baseline_name=None, bootstrap_resamples=10, bootstrap_seed=0)
    assert "Paired bootstrap" not in md
