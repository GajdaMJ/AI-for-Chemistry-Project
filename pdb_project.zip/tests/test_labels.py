from pathlib import Path

from pdb_project.data.labels import LabelRow, load_labels


def test_load_labels(repo_root: Path) -> None:
    rows = load_labels(repo_root / "data" / "labels.csv", repo_root=repo_root)
    assert len(rows) == 2
    first: LabelRow = rows[0]
    assert first.pdb_code == "7ZCT"
    assert first.protein_name == "mScarlet3"
    assert first.pdb_path.name == "7ZCT_mScarlet3.pdb"
    assert first.pdb_path.exists()
    assert first.kDa == 25.85
    assert first.targets["brightness"] == 78.00
    assert first.targets["emission"] == 592.0
    assert first.targets["qy"] == 0.75
    assert first.sequence.startswith("MDST")
