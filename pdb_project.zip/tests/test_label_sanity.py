from pathlib import Path

import pytest
from pdb_project.data.labels import load_labels


def _write(
    path: Path,
    brightness: float = 78.0,
    emission: float = 592.0,
    qy: float = 0.75,
    kDa: float = 25.85,  # noqa: N803
) -> None:
    path.write_text(
        "pdb_code,protein_name,pdb_path,kDa,brightness,emission,qy,sequence\n"
        f"7ZCT,mScarlet3,data/raw/7ZCT_mScarlet3.pdb,{kDa},{brightness},{emission},{qy},M\n"
    )


def test_rejects_qy_over_one(tmp_path: Path, repo_root: Path) -> None:
    csv = tmp_path / "labels.csv"
    _write(csv, qy=1.5)
    with pytest.raises(ValueError, match="qy"):
        load_labels(csv, repo_root=repo_root)


def test_rejects_emission_out_of_range(tmp_path: Path, repo_root: Path) -> None:
    csv = tmp_path / "labels.csv"
    _write(csv, emission=1200.0)
    with pytest.raises(ValueError, match="emission"):
        load_labels(csv, repo_root=repo_root)


def test_rejects_negative_brightness(tmp_path: Path, repo_root: Path) -> None:
    csv = tmp_path / "labels.csv"
    _write(csv, brightness=-1.0)
    with pytest.raises(ValueError, match="brightness"):
        load_labels(csv, repo_root=repo_root)


def test_rejects_implausible_kDa(tmp_path: Path, repo_root: Path) -> None:  # noqa: N802
    csv = tmp_path / "labels.csv"
    _write(csv, kDa=250.0)
    with pytest.raises(ValueError, match="kDa"):
        load_labels(csv, repo_root=repo_root)


def test_accepts_valid_row(tmp_path: Path, repo_root: Path) -> None:
    csv = tmp_path / "labels.csv"
    _write(csv)
    rows = load_labels(csv, repo_root=repo_root)
    assert len(rows) == 1
