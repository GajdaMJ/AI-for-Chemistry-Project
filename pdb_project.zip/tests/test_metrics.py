import torch
from pdb_project.training.metrics import compute_metrics


def test_perfect_prediction() -> None:
    y = torch.tensor([[1.0, 10.0, 0.5], [2.0, 20.0, 0.3]])
    y_hat = y.clone()
    m = compute_metrics(y_hat=y_hat, y=y, target_names=("brightness", "emission", "qy"))
    assert m["mae/brightness"] == 0.0
    assert m["r2/brightness"] == 1.0
    assert m["mae/overall"] == 0.0


def test_mae_value() -> None:
    y = torch.tensor([[1.0, 10.0, 0.5], [2.0, 20.0, 0.3]])
    y_hat = torch.tensor([[1.5, 12.0, 0.4], [2.5, 18.0, 0.4]])
    m = compute_metrics(y_hat=y_hat, y=y, target_names=("brightness", "emission", "qy"))
    # |1-1.5| + |2-2.5| / 2 = 0.5
    assert abs(m["mae/brightness"] - 0.5) < 1e-6
    # |10-12| + |20-18| / 2 = 2.0
    assert abs(m["mae/emission"] - 2.0) < 1e-6
