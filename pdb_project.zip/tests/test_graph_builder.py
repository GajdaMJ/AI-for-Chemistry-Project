from pathlib import Path

import torch
from pdb_project.data.graph_builder import build_graphs
from pdb_project.data.pdb_parser import parse_pdb


def test_protein_graph_fully_connected(mscarlet3_pdb: Path) -> None:
    records = parse_pdb(mscarlet3_pdb)
    protein_g, ligand_g = build_graphs(records, drop_hydrogens=True)

    n = protein_g.x.size(0)
    # Fully connected without self-loops: n * (n - 1) directed edges
    assert protein_g.edge_index.size(1) == n * (n - 1)
    # Node features = one-hot of AA type, 20-dim
    assert protein_g.x.shape == (n, 20)
    # Edge attr = scalar distances (RBF expansion happens in the model)
    assert protein_g.edge_attr.shape == (n * (n - 1), 1)
    # All distances positive
    assert (protein_g.edge_attr > 0).all()


def test_ligand_graph_heavy_atoms_only(mscarlet3_pdb: Path) -> None:
    records = parse_pdb(mscarlet3_pdb)
    _, ligand_g = build_graphs(records, drop_hydrogens=True)

    assert ligand_g.x.dtype == torch.float32
    # Element one-hot over {C, N, O, S} → 4-dim
    assert ligand_g.x.shape[1] == 4
    # At least the canonical NRQ heavy-atom count (~24)
    assert ligand_g.x.shape[0] >= 20
    # No hydrogens
    # (we don't store element in graph, but row counts vs. raw records must differ)
    heavy = [a for a in records.ligand.atoms if a.element != "H"]  # type: ignore[union-attr]
    assert ligand_g.x.shape[0] == len(heavy)


def test_protein_com_distance_sanity(mscarlet3_pdb: Path) -> None:
    records = parse_pdb(mscarlet3_pdb)
    protein_g, _ = build_graphs(records, drop_hydrogens=True)
    # Min/max distance in a ~225-residue protein: min >= ~3 Å, max <= ~80 Å
    d = protein_g.edge_attr.squeeze(-1)
    assert d.min() >= 2.0
    assert d.max() <= 100.0
