"""Shared pytest fixtures."""

from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent


@pytest.fixture(scope="session")
def repo_root() -> Path:
    return REPO_ROOT


@pytest.fixture(scope="session")
def raw_pdb_dir(repo_root: Path) -> Path:
    return repo_root / "data" / "raw"


@pytest.fixture(scope="session")
def mscarlet3_pdb(raw_pdb_dir: Path) -> Path:
    path = raw_pdb_dir / "7ZCT_mScarlet3.pdb"
    assert path.exists(), f"Missing test PDB: {path}"
    return path


@pytest.fixture(scope="session")
def mcardinal_pdb(raw_pdb_dir: Path) -> Path:
    path = raw_pdb_dir / "4OQW_mCardinal.pdb"
    assert path.exists(), f"Missing test PDB: {path}"
    return path
