import torch
from pdb_project.data.dataset import FluorescenceDataset
from pdb_project.models.schnet import SchNetFluorescenceModel
from pdb_project.training.loop import TrainConfig, collate_fn, train_one_epoch
from pdb_project.training.standardize import Standardizer
from torch.utils.data import DataLoader


def test_train_one_epoch_reduces_loss(repo_root) -> None:
    torch.manual_seed(0)
    ds = FluorescenceDataset(
        labels_csv=repo_root / "data" / "labels.csv",
        repo_root=repo_root,
    )
    loader = DataLoader(ds, batch_size=2, shuffle=False, collate_fn=collate_fn)

    # Fit target standardizer on the only 2 samples we have (plumbing test)
    y_train = torch.stack([ds[i]["y"] for i in range(len(ds))], dim=0)
    y_std = Standardizer.fit(y_train)
    kDa_train = torch.stack([ds[i]["kDa"] for i in range(len(ds))], dim=0)  # noqa: N806
    kDa_std = Standardizer.fit(kDa_train)  # noqa: N806

    model = SchNetFluorescenceModel(hidden=16, num_layers=2, rbf_k=8)
    opt = torch.optim.AdamW(model.parameters(), lr=1e-2)

    cfg = TrainConfig()
    # Compute initial loss
    model.eval()
    with torch.no_grad():
        init_loss = _eval_loss(model, loader, y_std, kDa_std)
    # Train a few epochs on the tiny set
    for _ in range(5):
        train_one_epoch(model, loader, opt, y_std, kDa_std, cfg)
    model.eval()
    with torch.no_grad():
        final_loss = _eval_loss(model, loader, y_std, kDa_std)

    assert final_loss < init_loss


def _eval_loss(model, loader, y_std, kDa_std) -> float:  # noqa: N803
    total = 0.0
    n = 0
    for batch in loader:
        y = batch["y"]
        kDa = kDa_std.transform(batch["kDa"])  # noqa: N806
        y_hat = model(batch["protein"], batch["ligand"], kDa)
        z = y_std.transform(y)
        total += float(((y_hat - z) ** 2).mean())
        n += 1
    return total / max(n, 1)
