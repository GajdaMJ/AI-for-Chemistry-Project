import torch
from pdb_project.training.standardize import Standardizer


def test_standardizer_roundtrip() -> None:
    y = torch.tensor([[78.0, 592.0, 0.75], [16.53, 659.0, 0.19]])
    s = Standardizer.fit(y)
    z = s.transform(y)
    assert torch.allclose(z.mean(0), torch.zeros(3), atol=1e-5)
    # Only one degree of freedom with n=2, std uses ddof=0 below
    assert torch.allclose(s.inverse(z), y, atol=1e-4)


def test_standardizer_preserves_shape() -> None:
    y = torch.randn(10, 3)
    s = Standardizer.fit(y)
    assert s.transform(y).shape == y.shape


def test_standardizer_state_dict() -> None:
    y = torch.randn(5, 3)
    s = Standardizer.fit(y)
    s2 = Standardizer.from_state_dict(s.state_dict())
    assert torch.allclose(s.transform(y), s2.transform(y))
