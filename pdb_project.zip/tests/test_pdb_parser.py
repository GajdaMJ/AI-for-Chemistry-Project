from pathlib import Path

import numpy as np
from pdb_project.data.pdb_parser import PDBRecords, parse_pdb


def test_parse_mscarlet3(mscarlet3_pdb: Path) -> None:
    records: PDBRecords = parse_pdb(mscarlet3_pdb)

    # Standard-AA residues: non-empty, in order
    assert len(records.residues) > 100
    first = records.residues[0]
    assert first.resname == "ALA"
    assert first.resseq == 7
    assert len(first.atoms) >= 5  # heavy atoms at least
    # Each atom has element + xyz
    assert first.atoms[0].element in {"N", "C", "O", "S", "H"}
    xyz = first.atoms[0].xyz
    assert xyz.shape == (3,)
    assert xyz.dtype == np.float32

    # NRQ ligand present
    assert records.ligand is not None
    assert records.ligand.resname == "NRQ"
    assert len(records.ligand.atoms) >= 20

    # Waters present (we keep them; dropping happens in graph builder)
    assert len(records.waters) >= 0


def test_parse_mcardinal_has_ligand(mcardinal_pdb: Path) -> None:
    records = parse_pdb(mcardinal_pdb)
    assert records.ligand is not None
    assert records.ligand.resname == "NRQ"
