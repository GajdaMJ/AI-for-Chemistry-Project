from pathlib import Path

from pdb_project.data.pdb_parser import parse_pdb


def test_altloc_only_primary_kept(tmp_path: Path) -> None:
    pdb = tmp_path / "fake.pdb"
    # Two altLocs of the same CA atom (A=primary, B=secondary), one CB (no altLoc).
    # PDB column layout: atom_name[12:16], altloc[16], resname[17:20], chain[21].
    pdb.write_text(
        "ATOM      1  N   ALA A   1       0.000   0.000   0.000  1.00  0.00           N\n"
        "ATOM      2  CA AALA A   1       1.000   0.000   0.000  1.00  0.00           C\n"
        "ATOM      3  CA BALA A   1       1.500   0.000   0.000  0.50  0.00           C\n"
        "ATOM      4  CB  ALA A   1       2.000   0.000   0.000  1.00  0.00           C\n"
    )
    records = parse_pdb(pdb)
    assert len(records.residues) == 1
    # N + CA (altLoc A) + CB — NOT CA (altLoc B)
    assert len(records.residues[0].atoms) == 3
    atom_names = [a.name for a in records.residues[0].atoms]
    assert atom_names == ["N", "CA", "CB"]


def test_altloc_custom_keep(tmp_path: Path) -> None:
    """Overriding altloc_keep to the B conformation inverts the selection."""
    pdb = tmp_path / "fake.pdb"
    pdb.write_text(
        "ATOM      1  N   ALA A   1       0.000   0.000   0.000  1.00  0.00           N\n"
        "ATOM      2  CA AALA A   1       1.000   0.000   0.000  1.00  0.00           C\n"
        "ATOM      3  CA BALA A   1       1.500   0.000   0.000  0.50  0.00           C\n"
    )
    records = parse_pdb(pdb, altloc_keep=(" ", "B", ""))
    assert [a.name for a in records.residues[0].atoms] == ["N", "CA"]
    # The kept CA should be the B-conformation (x=1.5), not the A (x=1.0)
    ca = records.residues[0].atoms[1]
    assert abs(ca.xyz[0] - 1.5) < 1e-5
