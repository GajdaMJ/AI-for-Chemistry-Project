import pytest
import torch
from pdb_project.models.esm2_mlp import ESM2Baseline


def test_esm2_baseline_forward_cpu() -> None:
    try:
        model = ESM2Baseline(esm_model_name="esm2_t6_8M_UR50D", mlp_hidden=16)
    except Exception as e:  # network failure, etc.
        pytest.skip(f"ESM-2 weights unavailable: {e}")

    sequences = [
        "MVSKGEELIKENMHMKLY",
        "MDSTEAVIKEFMRFKVHM",
    ]
    kDa = torch.tensor([[25.85], [27.55]])  # noqa: N806
    y_hat = model(sequences, kDa)
    assert y_hat.shape == (2, 3)
