import torch
from pdb_project.models.head import FusionHead


def test_fusion_head_shapes() -> None:
    head = FusionHead(h_prot_dim=64, h_lig_dim=64, scalar_feature_dim=1, hidden=64, out_dim=3)
    h_prot = torch.randn(5, 64)
    h_lig = torch.randn(5, 64)
    scalar = torch.randn(5, 1)
    y_hat = head(h_prot, h_lig, scalar)
    assert y_hat.shape == (5, 3)


def test_fusion_head_scalar_only() -> None:
    head = FusionHead(h_prot_dim=0, h_lig_dim=0, scalar_feature_dim=41, hidden=32, out_dim=3)
    scalar = torch.randn(3, 41)
    y_hat = head(None, None, scalar)
    assert y_hat.shape == (3, 3)
