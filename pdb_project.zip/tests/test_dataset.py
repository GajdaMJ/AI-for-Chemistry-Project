from pathlib import Path

from pdb_project.data.dataset import FluorescenceDataset


def test_dataset_len_and_item(repo_root: Path) -> None:
    ds = FluorescenceDataset(
        labels_csv=repo_root / "data" / "labels.csv",
        repo_root=repo_root,
    )
    assert len(ds) == 2

    sample = ds[0]
    # Sample is a dict with protein graph, ligand graph, kDa, targets, pdb_code
    assert set(sample.keys()) == {"protein", "ligand", "kDa", "y", "pdb_code"}
    assert sample["protein"].x.shape[1] == 20
    assert sample["ligand"].x.shape[1] == 4
    assert sample["kDa"].shape == (1,)
    assert sample["y"].shape == (3,)  # brightness, emission, qy
    assert sample["pdb_code"] in {"7ZCT", "4OQW"}


def test_dataset_cache(repo_root: Path, tmp_path: Path) -> None:
    ds = FluorescenceDataset(
        labels_csv=repo_root / "data" / "labels.csv",
        repo_root=repo_root,
        cache_dir=tmp_path,
    )
    _ = ds[0]
    _ = ds[0]  # second access should hit cache
    cache_files = list(tmp_path.glob("*.pt"))
    assert len(cache_files) >= 1
