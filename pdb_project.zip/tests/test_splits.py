from pdb_project.training.splits import assign_folds, cluster_sequences


def test_assign_folds_deterministic() -> None:
    clusters = {
        "A": ["p1", "p2"],
        "B": ["p3"],
        "C": ["p4", "p5", "p6"],
        "D": ["p7"],
        "E": ["p8"],
    }
    a1 = assign_folds(clusters, k=3, seed=42)
    a2 = assign_folds(clusters, k=3, seed=42)
    assert a1 == a2
    # Every protein assigned to exactly one fold
    all_proteins = {p for members in clusters.values() for p in members}
    assigned = {p: f for f, ps in a1.items() for p in ps}
    assert set(assigned.keys()) == all_proteins
    # Cluster integrity: all members of a cluster in the same fold
    for members in clusters.values():
        folds = {assigned[m] for m in members}
        assert len(folds) == 1


def test_cluster_sequences_small_fallback() -> None:
    """When mmseqs2 is unavailable OR n < 2, each sequence becomes its own cluster."""
    seqs = {"p1": "MVSK", "p2": "MVSK", "p3": "ACGT"}
    clusters = cluster_sequences(seqs, identity=0.7, fallback=True)
    # 2 clusters expected: {p1, p2} share identical sequence; p3 is alone
    grouped = {frozenset(v) for v in clusters.values()}
    assert frozenset({"p1", "p2"}) in grouped or all(len(v) == 1 for v in clusters.values())
