import torch
from pdb_project.models.rbf import GaussianRBF


def test_rbf_shape() -> None:
    rbf = GaussianRBF(num_centers=16, low=0.0, high=20.0)
    d = torch.tensor([0.0, 5.0, 10.0, 20.0])
    out = rbf(d)
    assert out.shape == (4, 16)


def test_rbf_peaks_at_center() -> None:
    rbf = GaussianRBF(num_centers=5, low=0.0, high=4.0)
    # centers at 0, 1, 2, 3, 4
    d = torch.tensor([2.0])
    out = rbf(d).squeeze(0)
    assert out.argmax().item() == 2  # center #2 is at distance 2.0


def test_rbf_monotone_decreasing_away_from_center() -> None:
    rbf = GaussianRBF(num_centers=3, low=0.0, high=2.0)
    # centers at 0, 1, 2
    d = torch.tensor([1.0, 1.5, 2.0])
    # Center #0 (at 0.0) should be monotonically decreasing as d grows
    out = rbf(d)
    assert out[0, 0] > out[1, 0] > out[2, 0]
