from pathlib import Path

from pdb_project.data.dataset import FluorescenceDataset


def test_dataset_chain_default_A(repo_root: Path, tmp_path: Path) -> None:  # noqa: N802
    # Copy labels and ADD a second row for 7ZCT with an invented chain Z — filtering should drop it entirely.
    csv = tmp_path / "labels.csv"
    csv.write_text(
        "pdb_code,protein_name,pdb_path,kDa,brightness,emission,qy,sequence,chain\n"
        "7ZCT,mScarlet3,data/raw/7ZCT_mScarlet3.pdb,25.85,78.00,592,0.75,M,A\n"
        "7ZCT_Z,mScarlet3,data/raw/7ZCT_mScarlet3.pdb,25.85,78.00,592,0.75,M,Z\n"
    )
    ds = FluorescenceDataset(labels_csv=csv, repo_root=repo_root)
    # Row 0: chain A → residues present
    s0 = ds[0]
    assert s0["protein"].x.size(0) > 100
    # Row 1: chain Z → 0 residues, which should raise a clear error at build time
    # (test that we DO NOT silently build an empty graph)
    import pytest as _pt

    with _pt.raises(ValueError):
        _ = ds[1]
