import torch
from pdb_project.data.dataset import FluorescenceDataset
from pdb_project.models.schnet import SchNetFluorescenceModel
from torch_geometric.data import Batch


def test_schnet_forward(repo_root) -> None:
    ds = FluorescenceDataset(
        labels_csv=repo_root / "data" / "labels.csv",
        repo_root=repo_root,
    )
    s0 = ds[0]
    s1 = ds[1]

    protein_batch = Batch.from_data_list([s0["protein"], s1["protein"]])
    ligand_batch = Batch.from_data_list([s0["ligand"], s1["ligand"]])
    kDa = torch.stack([s0["kDa"], s1["kDa"]], dim=0)  # (2, 1)  # noqa: N806

    model = SchNetFluorescenceModel(
        node_in_protein=20,
        node_in_ligand=4,
        hidden=32,
        num_layers=2,
        rbf_k=8,
        protein_rbf_high=20.0,
        ligand_rbf_high=10.0,
        out_dim=3,
    )
    y_hat = model(protein_batch, ligand_batch, kDa)
    assert y_hat.shape == (2, 3)


def test_schnet_backward(repo_root) -> None:
    ds = FluorescenceDataset(
        labels_csv=repo_root / "data" / "labels.csv",
        repo_root=repo_root,
    )
    s0 = ds[0]
    protein_batch = Batch.from_data_list([s0["protein"]])
    ligand_batch = Batch.from_data_list([s0["ligand"]])
    kDa = s0["kDa"].unsqueeze(0)  # noqa: N806

    model = SchNetFluorescenceModel(
        node_in_protein=20,
        node_in_ligand=4,
        hidden=16,
        num_layers=2,
        rbf_k=8,
        protein_rbf_high=20.0,
        ligand_rbf_high=10.0,
        out_dim=3,
    )
    y_hat = model(protein_batch, ligand_batch, kDa)
    loss = y_hat.pow(2).sum()
    loss.backward()
    # At least one parameter has a non-zero gradient
    assert any(p.grad is not None and p.grad.abs().sum() > 0 for p in model.parameters())


def test_schnet_protein_only(repo_root) -> None:
    from pdb_project.data.dataset import FluorescenceDataset
    from torch_geometric.data import Batch

    ds = FluorescenceDataset(labels_csv=repo_root / "data" / "labels.csv", repo_root=repo_root)
    s0 = ds[0]
    pb = Batch.from_data_list([s0["protein"]])
    lb = Batch.from_data_list([s0["ligand"]])
    kDa = s0["kDa"].unsqueeze(0)  # noqa: N806
    model = SchNetFluorescenceModel(
        hidden=16, num_layers=2, rbf_k=8, use_protein=True, use_ligand=False
    )
    y_hat = model(pb, lb, kDa)
    assert y_hat.shape == (1, 3)


def test_schnet_ligand_only(repo_root) -> None:
    from pdb_project.data.dataset import FluorescenceDataset
    from torch_geometric.data import Batch

    ds = FluorescenceDataset(labels_csv=repo_root / "data" / "labels.csv", repo_root=repo_root)
    s0 = ds[0]
    pb = Batch.from_data_list([s0["protein"]])
    lb = Batch.from_data_list([s0["ligand"]])
    kDa = s0["kDa"].unsqueeze(0)  # noqa: N806
    model = SchNetFluorescenceModel(
        hidden=16, num_layers=2, rbf_k=8, use_protein=False, use_ligand=True
    )
    y_hat = model(pb, lb, kDa)
    assert y_hat.shape == (1, 3)
