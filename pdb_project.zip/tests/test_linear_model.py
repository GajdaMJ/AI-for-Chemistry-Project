import numpy as np
import torch
from pdb_project.data.dataset import FluorescenceDataset
from pdb_project.models.linear import LinearBaseline, featurize_sample


def test_featurize_shape(repo_root) -> None:
    ds = FluorescenceDataset(
        labels_csv=repo_root / "data" / "labels.csv",
        repo_root=repo_root,
    )
    feats = featurize_sample(ds[0], contact_cutoff=6.0)
    # kDa (1) + AA composition (20) + NRQ contact composition (20) = 41
    assert feats.shape == (41,)


def test_linear_baseline_fit_and_predict(repo_root) -> None:
    ds = FluorescenceDataset(
        labels_csv=repo_root / "data" / "labels.csv",
        repo_root=repo_root,
    )
    X = np.stack([featurize_sample(ds[i], contact_cutoff=6.0) for i in range(len(ds))], axis=0)  # noqa: N806
    y = torch.stack([ds[i]["y"] for i in range(len(ds))], dim=0).numpy()
    model = LinearBaseline(alpha=1.0).fit(X, y)
    preds = model.predict(X)
    assert preds.shape == y.shape
