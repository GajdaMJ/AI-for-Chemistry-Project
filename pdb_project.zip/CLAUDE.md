# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project

Predicts fluorescent-protein properties (brightness, emission wavelength, QY) from 3D structure using a SchNet-style dual-graph GNN, with an ESM-2 sequence baseline and constant/linear baselines. Design lives in `docs/superpowers/specs/2026-04-18-fluorescence-gnn-design.md`; the reproduction recipe is `docs/report/commands.md`.

## Commands

Always invoke Python through `uv run` — never bare `python` — so env resolution stays deterministic.

```bash
# setup
uv sync --all-extras
uv run pre-commit install

# tests
uv run pytest -v                          # full suite (expect ~38 pass)
uv run pytest tests/test_schnet.py -v     # single file
uv run pytest tests/test_schnet.py::test_name -v

# lint + format (ruff runs in pre-commit; mypy does not — see below)
uv run pre-commit run --all-files
bash scripts/typecheck.sh                 # mypy strict on src/pdb_project

# quick checks
uv run python -m pdb_project.cli model=schnet    # Hydra wiring check (builds model, one forward pass)

# 5-fold CV (real training entrypoint)
uv run python scripts/run_cv.py --model {schnet|gat|esm2|constant|linear}
# With n=2 dev dataset add: --k 2 --fallback-clustering --max-epochs 10 --patience 5
# SchNet branch ablations:
uv run python scripts/run_cv.py --model schnet --no-protein   # ligand-only
uv run python scripts/run_cv.py --model schnet --no-ligand    # protein-only
```

`scripts/run_cv.py` is the real trainer; `src/pdb_project/cli.py` (Hydra) is currently only a wiring smoke test that builds the configured model and exits.

mypy is deliberately **not** in pre-commit — it needs the torch+CUDA stack and duplicating that into pre-commit's isolated env is ~5 GB for no benefit. Run it via `scripts/typecheck.sh` instead.

## Architecture

**Dual-graph sample.** Each PDB yields *two independent* PyG `Data` objects — a protein residue-COM graph and an NRQ heavy-atom ligand graph — plus a scalar `kDa` and a 3-target `y`. Both graphs are fully connected with raw Euclidean distance as the edge attr; the RBF expansion happens **inside the model** so it can be tuned per-branch (`protein_rbf_high≈20Å`, `ligand_rbf_high≈10Å`). Consequence: the default PyG `DataLoader` cannot batch these samples — use `pdb_project.training.loop.collate_fn`, which calls `Batch.from_data_list` twice (once per stream).

**Label pipeline (`src/pdb_project/data/`).** `labels.py` loads `data/labels.csv` and enforces physics-level invariants in `_validate_row` (emission ∈ [400,800] nm, qy ∈ (0,1], brightness ≥ 0, kDa ∈ [10,100]). These are invariants, not hyperparameters — changing them belongs in that file, not in Hydra config. `pdb_parser.py` applies chain + altLoc filters (`altloc_keep` defaults to primary conformations). `dataset.py` caches per-PDB parsed+graph-built tensors at `data/cache/{pdb_code}.pt`. **If you change the parser, altLoc policy, `drop_hydrogens`, or add/modify a PDB, `rm -rf data/cache/` before rerunning** — otherwise stale tensors will silently mask the change.

**Models (`src/pdb_project/models/`).** All learned models fuse the two graph embeddings + standardized `kDa` via `FusionHead` and emit 3 standardized outputs. Standardization is fit **per-fold on train only** (`Standardizer.fit` in `training/standardize.py`) for both `y` and `kDa`; predictions are inverted before metric computation. `esm2_mlp.py` freezes the ESM-2 backbone — only head params are trainable, so the optimizer explicitly filters on `requires_grad`. `constant.py` (B0) and `linear.py` (B1 ridge on hand-crafted contact features) have their own fold logic in `run_cv.py` — they bypass the gradient loop entirely.

**CV splits (`training/splits.py`).** Sequence-identity clusters come from `mmseqs2 easy-cluster` when the binary is on `$PATH`; otherwise a sha1 exact-sequence fallback kicks in. The fallback is **dev-only** — never report numbers from it. `run_cv.py` further holds out ~10% of train clusters per fold for early-stopping val.

**Hydra layout (`conf/`).** `config.yaml` composes `data/`, `model/`, `training/`, `validation/` groups. To swap models at the CLI use `model=<name>`; override any leaf with dotted paths (e.g. `model.use_ligand=false`, `data.altloc_keep=[B]`). The Hydra CLI is currently a wiring check — CV still runs through `scripts/run_cv.py`.

## Conventions

- `kDa` and `N806` lint suppressions are intentional — molecular-weight convention beats PEP8 here. Keep the `# noqa: N806` / `N803` comments when touching those lines.
- Ruff config (`pyproject.toml`): line length 100, formatter handles wrapping (`E501` ignored), selected rules include `B`, `UP`, `N`, `SIM`, `RUF`.
- mypy is `strict = true` on `src/pdb_project`.
- Prefer editing `docs/report/commands.md` when adding new runnable recipes; it is the single source of truth for reproduction.
