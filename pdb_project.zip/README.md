# PDB Project — Fluorescence Property GNN

Predicts (Brightness, Emission wavelength, QY) for fluorescent proteins from 3D structure using a SchNet-style dual-graph GNN.

See `docs/superpowers/specs/2026-04-18-fluorescence-gnn-design.md` for the full design and `docs/superpowers/plans/2026-04-19-fluorescence-gnn-implementation.md` for the implementation plan.

## Setup

```bash
uv sync --all-extras
uv run pre-commit install
uv run pytest
```

## Quick commands

Hydra CLI wiring check:

```bash
uv run python -m pdb_project.cli model=schnet
uv run python -m pdb_project.cli model=gat
```

5-fold CV (once ~100 proteins are added to `data/labels.csv`):

```bash
uv run python scripts/run_cv.py --model schnet
uv run python scripts/run_cv.py --model constant
uv run python scripts/run_cv.py --model linear
```

Ablations (via Hydra overrides):

```bash
uv run python -m pdb_project.cli model=schnet model.use_ligand=false
uv run python -m pdb_project.cli model=schnet model.use_protein=false
```

## Adding new proteins

1. Drop the PDB into `data/raw/`.
2. Append a row to `data/labels.csv` with `pdb_code, protein_name, pdb_path, kDa, brightness, emission, qy, sequence`.
3. Clear the cache: `rm -rf data/cache/*`.
4. Run tests to make sure parsing still works: `uv run pytest tests/test_dataset.py tests/test_graph_builder.py`.

## Layout

- `src/pdb_project/data/` — parsing, graph building, dataset
- `src/pdb_project/models/` — SchNet, GAT, ESM-2, linear, constant
- `src/pdb_project/training/` — loop, metrics, splits, standardization
- `conf/` — Hydra config tree
- `scripts/` — CV runner + plumbing test
- `tests/` — pytest suite
