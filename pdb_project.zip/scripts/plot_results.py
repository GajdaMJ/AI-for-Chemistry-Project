"""Plot per-target MAE across baselines from run_cv.py JSON outputs.

One figure per target (brightness, emission, qy); bars are model means with
std-over-folds error bars.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

TARGETS = ("brightness", "emission", "qy")
TARGET_UNITS = {"brightness": "(EC·QY/1000)", "emission": "(nm)", "qy": "(dimensionless)"}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("results", nargs="+", type=Path, help="run_cv.py JSON outputs")
    parser.add_argument("--out", type=Path, default=Path("figures"), help="Output directory.")
    parser.add_argument("--dpi", type=int, default=150)
    args = parser.parse_args()

    args.out.mkdir(parents=True, exist_ok=True)

    models: list[str] = []
    means: dict[str, list[float]] = {t: [] for t in TARGETS}
    stds: dict[str, list[float]] = {t: [] for t in TARGETS}
    for p in args.results:
        data = json.loads(Path(p).read_text())
        models.append(data["model"])
        for t in TARGETS:
            means[t].append(data["aggregate"][f"mae/{t}"]["mean"])
            stds[t].append(data["aggregate"][f"mae/{t}"]["std"])

    x = np.arange(len(models))
    for t in TARGETS:
        fig, ax = plt.subplots(figsize=(6, 4))
        ax.bar(x, means[t], yerr=stds[t], capsize=4, color="steelblue", alpha=0.85)
        ax.set_xticks(x)
        ax.set_xticklabels(models, rotation=15, ha="right")
        ax.set_ylabel(f"MAE {TARGET_UNITS[t]}")
        ax.set_title(f"{t} — MAE (mean ± std across CV folds)")
        ax.grid(axis="y", linestyle=":", alpha=0.5)
        fig.tight_layout()
        out_path = args.out / f"mae_{t}.png"
        fig.savefig(out_path, dpi=args.dpi)
        plt.close(fig)
        print(f"wrote {out_path}")


if __name__ == "__main__":
    main()
