"""Aggregate per-fold CV results across baselines into a markdown report.

Reads one or more JSON files produced by `scripts/run_cv.py` (each shaped as
`{"model": str, "per_fold": [...], "aggregate": {...}}`) and emits a markdown
table with mean ± std of MAE and R² per target, plus paired-bootstrap 95 % CIs
of (model - baseline) fold-level MAE differences.

Intended for the final class-report write-up once the 100-protein CV runs are
complete.
"""

from __future__ import annotations

import argparse
import json
from collections.abc import Sequence
from pathlib import Path
from typing import TypedDict

import numpy as np

TARGETS = ("brightness", "emission", "qy")


class ModelResult(TypedDict):
    model: str
    per_fold: list[dict[str, float]]
    aggregate: dict[str, dict[str, float]]


def load_results(paths: Sequence[Path]) -> list[ModelResult]:
    out: list[ModelResult] = []
    for p in paths:
        data = json.loads(Path(p).read_text())
        if not ({"model", "per_fold", "aggregate"} <= set(data.keys())):
            raise ValueError(f"{p} is not a run_cv.py output (missing expected keys).")
        out.append(data)
    return out


def fold_maes(result: ModelResult, target: str) -> np.ndarray:
    return np.array([f[f"mae/{target}"] for f in result["per_fold"]], dtype=np.float64)


def paired_bootstrap_ci(
    model_maes: np.ndarray,
    baseline_maes: np.ndarray,
    n_resamples: int = 10_000,
    alpha: float = 0.05,
    seed: int = 0,
) -> tuple[float, float, float]:
    """Paired bootstrap on fold-level differences.

    Returns (mean_diff, lo, hi) where lo/hi are the (alpha/2, 1-alpha/2)
    percentiles of the bootstrap distribution of (model - baseline) mean MAE.
    Positive `mean_diff` means the model is WORSE than the baseline.
    """
    if model_maes.shape != baseline_maes.shape:
        raise ValueError("Paired bootstrap requires matching fold counts.")
    diffs = model_maes - baseline_maes
    rng = np.random.default_rng(seed)
    n = diffs.size
    samples = rng.integers(0, n, size=(n_resamples, n))
    boot_means = diffs[samples].mean(axis=1)
    lo = float(np.quantile(boot_means, alpha / 2))
    hi = float(np.quantile(boot_means, 1 - alpha / 2))
    return float(diffs.mean()), lo, hi


def render_markdown(
    results: Sequence[ModelResult],
    baseline_name: str | None,
    bootstrap_resamples: int,
    bootstrap_seed: int,
) -> str:
    lines: list[str] = []
    lines.append("# CV Results Summary\n")
    lines.append(
        f"Aggregated across {len(results[0]['per_fold'])} folds. "
        "MAE is on original scale (nm for emission, dimensionless for brightness and QY). "
        "R² is computed per fold and averaged.\n"
    )

    # Per-target MAE tables
    for target in TARGETS:
        lines.append(f"## `{target}` — MAE (mean ± std over folds)\n")
        lines.append("| Model | MAE mean | MAE std | R² mean | R² std |")
        lines.append("|---|---:|---:|---:|---:|")
        for r in results:
            mae = r["aggregate"][f"mae/{target}"]
            r2 = r["aggregate"][f"r2/{target}"]
            lines.append(
                f"| {r['model']} | {mae['mean']:.3f} | {mae['std']:.3f} | "
                f"{r2['mean']:.3f} | {r2['std']:.3f} |"
            )
        lines.append("")

    # Paired bootstrap CIs vs baseline
    if baseline_name is not None:
        baseline = next((r for r in results if r["model"] == baseline_name), None)
        if baseline is None:
            raise ValueError(
                f"Baseline {baseline_name!r} not found in results; available: "
                f"{[r['model'] for r in results]}"
            )
        lines.append(
            f"## Paired bootstrap: (model - {baseline_name}) MAE difference "
            f"(95 % CI, {bootstrap_resamples} resamples, seed={bootstrap_seed})\n"
        )
        lines.append("Negative = model is BETTER than the baseline on that target.\n")
        lines.append("| Model | Target | Mean Δ MAE | 95 % CI |")
        lines.append("|---|---|---:|---|")
        for r in results:
            if r["model"] == baseline_name:
                continue
            for target in TARGETS:
                m_maes = fold_maes(r, target)
                b_maes = fold_maes(baseline, target)
                mean_diff, lo, hi = paired_bootstrap_ci(
                    m_maes, b_maes, n_resamples=bootstrap_resamples, seed=bootstrap_seed
                )
                sig = "✓" if (lo < 0 < hi) is False and hi < 0 else " "
                lines.append(
                    f"| {r['model']} | {target} | {mean_diff:+.3f} | "
                    f"[{lo:+.3f}, {hi:+.3f}] {sig} |"
                )
        lines.append("")
        lines.append(
            "✓ = CI lies entirely below zero (model significantly better than "
            f"{baseline_name} on that target at alpha=0.05)."
        )

    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("results", nargs="+", type=Path, help="run_cv.py JSON outputs")
    parser.add_argument(
        "--baseline",
        default="constant",
        help="Model name to treat as the paired-bootstrap baseline (default: constant).",
    )
    parser.add_argument("--no-baseline", action="store_true", help="Skip bootstrap CI section.")
    parser.add_argument("--bootstrap-resamples", type=int, default=10_000)
    parser.add_argument("--bootstrap-seed", type=int, default=0)
    parser.add_argument(
        "--out", type=Path, default=None, help="Write markdown here; default stdout."
    )
    args = parser.parse_args()

    results = load_results(args.results)
    md = render_markdown(
        results,
        baseline_name=None if args.no_baseline else args.baseline,
        bootstrap_resamples=args.bootstrap_resamples,
        bootstrap_seed=args.bootstrap_seed,
    )
    if args.out is None:
        print(md)
    else:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(md)


if __name__ == "__main__":
    main()
