"""5-fold cross-validation over sequence-identity clusters.

Steps per fold:
  1. Build sequence-identity clusters from labels.csv (mmseqs2 or fallback).
  2. Assign clusters to 5 folds (LPT).
  3. For each fold k: train on folds != k (with 10% cluster-level val holdout
     for early stopping), test on fold k.
  4. Aggregate per-fold per-target MAE/R^2 and report mean +/- std.

This script uses SchNet (B3a) by default; change `--model` to run others.
Baselines B0/B1 have their own scikit-learn-style inner loop (no gradient
training), which this script delegates to `_run_sklearn_baseline`.
"""

from __future__ import annotations

import argparse
import json
import logging
from pathlib import Path

import numpy as np
import torch
from pdb_project.data.dataset import FluorescenceDataset
from pdb_project.data.labels import TARGET_COLUMNS, load_labels
from pdb_project.models.constant import ConstantPredictor
from pdb_project.models.linear import LinearBaseline, featurize_sample
from pdb_project.models.schnet import SchNetFluorescenceModel
from pdb_project.training.loop import TrainConfig, collate_fn, evaluate, train_one_epoch
from pdb_project.training.metrics import compute_metrics
from pdb_project.training.splits import assign_folds, cluster_sequences
from pdb_project.training.standardize import Standardizer
from torch.utils.data import DataLoader, Subset

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger(__name__)


def _gnn_one_fold(
    ds: FluorescenceDataset,
    train_idx: list[int],
    val_idx: list[int],
    test_idx: list[int],
    *,
    max_epochs: int,
    patience: int,
    lr: float,
    weight_decay: float,
    batch_size: int,
    device: str,
    model_ctor,
) -> dict[str, float]:
    y_train = torch.stack([ds[i]["y"] for i in train_idx], dim=0)
    kDa_train = torch.stack([ds[i]["kDa"] for i in train_idx], dim=0)  # noqa: N806
    y_std = Standardizer.fit(y_train)
    kDa_std = Standardizer.fit(kDa_train)  # noqa: N806

    train_loader = DataLoader(
        Subset(ds, train_idx), batch_size=batch_size, shuffle=True, collate_fn=collate_fn
    )
    val_loader = DataLoader(
        Subset(ds, val_idx), batch_size=batch_size, shuffle=False, collate_fn=collate_fn
    )
    test_loader = DataLoader(
        Subset(ds, test_idx), batch_size=batch_size, shuffle=False, collate_fn=collate_fn
    )

    model = model_ctor().to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
    cfg = TrainConfig()

    best_val = float("inf")
    best_state: dict[str, torch.Tensor] | None = None
    epochs_without_improve = 0
    has_val = len(val_idx) > 0
    if not has_val:
        log.warning("val set empty — training %d epochs without early stopping", max_epochs)

    for epoch in range(1, max_epochs + 1):
        _ = train_one_epoch(model, train_loader, opt, y_std, kDa_std, cfg)
        if not has_val:
            continue
        y_hat_val, y_val = evaluate(model, val_loader, y_std, kDa_std)
        val_metrics = compute_metrics(y_hat_val, y_val, TARGET_COLUMNS)
        val_loss = val_metrics["mae/overall"]
        if val_loss < best_val - 1e-6:
            best_val = val_loss
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            epochs_without_improve = 0
        else:
            epochs_without_improve += 1
            if epochs_without_improve >= patience:
                log.info("early stop at epoch %d (best val %.4f)", epoch, best_val)
                break

    if best_state is not None:
        model.load_state_dict(best_state)
    y_hat_test, y_test = evaluate(model, test_loader, y_std, kDa_std)
    return compute_metrics(y_hat_test, y_test, TARGET_COLUMNS)


def _constant_one_fold(ds, train_idx, test_idx) -> dict[str, float]:
    y_train = torch.stack([ds[i]["y"] for i in train_idx], dim=0)
    pred = ConstantPredictor.fit(y_train).predict(len(test_idx))
    y_test = torch.stack([ds[i]["y"] for i in test_idx], dim=0)
    return compute_metrics(pred, y_test, TARGET_COLUMNS)


def _linear_one_fold(
    ds, train_idx, test_idx, contact_cutoff: float, alpha: float
) -> dict[str, float]:
    X_train = np.stack(  # noqa: N806
        [featurize_sample(ds[i], contact_cutoff=contact_cutoff) for i in train_idx], axis=0
    )
    X_test = np.stack(  # noqa: N806
        [featurize_sample(ds[i], contact_cutoff=contact_cutoff) for i in test_idx], axis=0
    )
    y_train = torch.stack([ds[i]["y"] for i in train_idx], dim=0).numpy()
    y_test = torch.stack([ds[i]["y"] for i in test_idx], dim=0)
    preds = LinearBaseline(alpha=alpha).fit(X_train, y_train).predict(X_test)
    return compute_metrics(torch.from_numpy(preds.astype(np.float32)), y_test, TARGET_COLUMNS)


def _esm2_one_fold(
    ds: FluorescenceDataset,
    labels: list,  # list[LabelRow]
    train_idx: list[int],
    val_idx: list[int],
    test_idx: list[int],
    *,
    esm_model_name: str,
    mlp_hidden: int,
    max_epochs: int,
    patience: int,
    lr: float,
    weight_decay: float,
    batch_size: int,
    device: str,
) -> dict[str, float]:
    from pdb_project.models.esm2_mlp import ESM2Baseline

    def _batch(indices: list[int], bs: int):
        """Yield (sequences, kDa_tensor, y_tensor) batches."""
        for start in range(0, len(indices), bs):
            chunk = indices[start : start + bs]
            seqs = [labels[i].sequence for i in chunk]
            kDa = torch.stack([ds[i]["kDa"] for i in chunk], dim=0)  # noqa: N806
            y = torch.stack([ds[i]["y"] for i in chunk], dim=0)
            yield seqs, kDa, y

    y_train = torch.stack([ds[i]["y"] for i in train_idx], dim=0)
    kDa_train = torch.stack([ds[i]["kDa"] for i in train_idx], dim=0)  # noqa: N806
    y_std = Standardizer.fit(y_train)
    kDa_std = Standardizer.fit(kDa_train)  # noqa: N806

    model = ESM2Baseline(esm_model_name=esm_model_name, mlp_hidden=mlp_hidden).to(device)
    # Only head params are trainable (backbone is frozen in ESM2Baseline.__init__).
    trainable = [p for p in model.parameters() if p.requires_grad]
    opt = torch.optim.AdamW(trainable, lr=lr, weight_decay=weight_decay)

    best_val = float("inf")
    best_state: dict[str, torch.Tensor] | None = None
    epochs_without_improve = 0
    has_val = len(val_idx) > 0
    if not has_val:
        log.warning("val set empty — training %d epochs without early stopping", max_epochs)

    for epoch in range(1, max_epochs + 1):
        model.train()
        for seqs, kDa, y in _batch(train_idx, batch_size):  # noqa: N806
            opt.zero_grad()
            kDa_z = kDa_std.transform(kDa.to(device))  # noqa: N806
            y_hat = model(seqs, kDa_z)
            z = y_std.transform(y.to(device))
            loss = ((y_hat - z) ** 2).mean()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(trainable, 1.0)
            opt.step()

        if not has_val:
            continue
        model.eval()
        with torch.no_grad():
            preds: list[torch.Tensor] = []
            gts: list[torch.Tensor] = []
            for seqs, kDa, y in _batch(val_idx, batch_size):  # noqa: N806
                kDa_z = kDa_std.transform(kDa.to(device))  # noqa: N806
                z_hat = model(seqs, kDa_z)
                preds.append(y_std.inverse(z_hat).cpu())
                gts.append(y)
            y_hat_val = torch.cat(preds, 0)
            y_val = torch.cat(gts, 0)
        val_metrics = compute_metrics(y_hat_val, y_val, TARGET_COLUMNS)
        val_loss = val_metrics["mae/overall"]
        if val_loss < best_val - 1e-6:
            best_val = val_loss
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            epochs_without_improve = 0
        else:
            epochs_without_improve += 1
            if epochs_without_improve >= patience:
                log.info("early stop at epoch %d (best val %.4f)", epoch, best_val)
                break

    if best_state is not None:
        model.load_state_dict(best_state)

    model.eval()
    with torch.no_grad():
        preds = []
        gts = []
        for seqs, kDa, y in _batch(test_idx, batch_size):  # noqa: N806
            kDa_z = kDa_std.transform(kDa.to(device))  # noqa: N806
            z_hat = model(seqs, kDa_z)
            preds.append(y_std.inverse(z_hat).cpu())
            gts.append(y)
        y_hat_test = torch.cat(preds, 0)
        y_test = torch.cat(gts, 0)
    return compute_metrics(y_hat_test, y_test, TARGET_COLUMNS)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--model",
        choices=["schnet", "gat", "esm2", "constant", "linear"],
        default="schnet",
    )
    parser.add_argument(
        "--heads", type=int, default=4, help="GAT attention heads (ignored for other models)"
    )
    parser.add_argument("--esm-model", default="esm2_t12_35M_UR50D", help="fair-esm model name")
    parser.add_argument("--mlp-hidden", type=int, default=128, help="MLP hidden dim for ESM-2 head")
    parser.add_argument("--k", type=int, default=5)
    parser.add_argument("--identity", type=float, default=0.7)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--fallback-clustering", action="store_true")
    parser.add_argument("--max-epochs", type=int, default=200)
    parser.add_argument("--patience", type=int, default=30)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--val-fraction", type=float, default=0.1)
    parser.add_argument("--contact-cutoff", type=float, default=6.0)
    parser.add_argument("--ridge-alpha", type=float, default=1.0)
    parser.add_argument("--out-json", default="outputs/cv_results.json")
    # SchNet graph-branch ablations (B4 in the design spec).
    parser.add_argument(
        "--no-protein",
        dest="use_protein",
        action="store_false",
        help="SchNet ablation: drop the protein graph branch (ligand-only).",
    )
    parser.add_argument(
        "--no-ligand",
        dest="use_ligand",
        action="store_false",
        help="SchNet ablation: drop the NRQ ligand branch (protein-only).",
    )
    parser.set_defaults(use_protein=True, use_ligand=True)
    args = parser.parse_args()
    if not (args.use_protein or args.use_ligand):
        parser.error(
            "--no-protein and --no-ligand cannot both be set; the model needs at least one graph branch."
        )

    repo_root = Path(__file__).resolve().parent.parent
    torch.manual_seed(args.seed)

    labels = load_labels(repo_root / "data" / "labels.csv", repo_root=repo_root)
    sequences = {r.pdb_code: r.sequence for r in labels}
    clusters = cluster_sequences(
        sequences, identity=args.identity, fallback=args.fallback_clustering
    )
    folds = assign_folds(clusters, k=args.k, seed=args.seed)
    pid_to_idx = {r.pdb_code: i for i, r in enumerate(labels)}

    ds = FluorescenceDataset(
        labels_csv=repo_root / "data" / "labels.csv",
        repo_root=repo_root,
        cache_dir=repo_root / "data" / "cache",
    )

    per_fold: list[dict[str, float]] = []
    for k in range(args.k):
        test_pids = folds[k]
        train_pids = [p for kk, ps in folds.items() if kk != k for p in ps]
        # Hold out ~val_fraction of TRAIN clusters for early stopping
        train_clusters = [
            cid for cid, members in clusters.items() if any(m in train_pids for m in members)
        ]
        rng = np.random.default_rng(args.seed + k)
        rng.shuffle(train_clusters)
        # Ensure train has at least 1 cluster after val holdout.
        n_val = min(
            max(1, int(len(train_clusters) * args.val_fraction)), max(len(train_clusters) - 1, 0)
        )
        val_cluster_ids = set(train_clusters[:n_val])
        val_pids = [m for cid in val_cluster_ids for m in clusters[cid] if m in train_pids]
        train_pids_net = [p for p in train_pids if p not in val_pids]

        train_idx = [pid_to_idx[p] for p in train_pids_net]
        val_idx = [pid_to_idx[p] for p in val_pids]
        test_idx = [pid_to_idx[p] for p in test_pids]

        log.info("fold %d: train=%d val=%d test=%d", k, len(train_idx), len(val_idx), len(test_idx))

        if args.model == "constant":
            metrics = _constant_one_fold(ds, train_idx + val_idx, test_idx)
        elif args.model == "linear":
            metrics = _linear_one_fold(
                ds, train_idx + val_idx, test_idx, args.contact_cutoff, args.ridge_alpha
            )
        elif args.model == "esm2":
            metrics = _esm2_one_fold(
                ds,
                labels,
                train_idx,
                val_idx,
                test_idx,
                esm_model_name=args.esm_model,
                mlp_hidden=args.mlp_hidden,
                max_epochs=args.max_epochs,
                patience=args.patience,
                lr=args.lr,
                weight_decay=args.weight_decay,
                batch_size=args.batch_size,
                device=args.device,
            )
        elif args.model == "gat":
            from pdb_project.models.gat import GATFluorescenceModel

            def _gat_ctor() -> torch.nn.Module:
                return GATFluorescenceModel(heads=args.heads)

            metrics = _gnn_one_fold(
                ds,
                train_idx,
                val_idx,
                test_idx,
                max_epochs=args.max_epochs,
                patience=args.patience,
                lr=args.lr,
                weight_decay=args.weight_decay,
                batch_size=args.batch_size,
                device=args.device,
                model_ctor=_gat_ctor,
            )
        else:  # schnet

            def _schnet_ctor() -> torch.nn.Module:
                return SchNetFluorescenceModel(
                    use_protein=args.use_protein, use_ligand=args.use_ligand
                )

            metrics = _gnn_one_fold(
                ds,
                train_idx,
                val_idx,
                test_idx,
                max_epochs=args.max_epochs,
                patience=args.patience,
                lr=args.lr,
                weight_decay=args.weight_decay,
                batch_size=args.batch_size,
                device=args.device,
                model_ctor=_schnet_ctor,
            )
        log.info("fold %d metrics: %s", k, metrics)
        per_fold.append(metrics)

    # Aggregate
    agg: dict[str, dict[str, float]] = {}
    keys = per_fold[0].keys()
    for key in keys:
        values = [m[key] for m in per_fold]
        agg[key] = {"mean": float(np.mean(values)), "std": float(np.std(values))}
    log.info("Aggregated metrics:\n%s", json.dumps(agg, indent=2))

    out_path = Path(args.out_json)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps({"model": args.model, "per_fold": per_fold, "aggregate": agg}, indent=2)
    )


if __name__ == "__main__":
    main()
