"""Hydra entry point.

Dispatches by model.type. For now the CLI just builds the requested
model and runs a single forward pass as a wiring check; the full CV
runner lives in scripts/run_cv.py (Task 17) and reuses the same factory.
"""

from __future__ import annotations

import logging
from pathlib import Path

import hydra
import torch
from omegaconf import DictConfig, OmegaConf

from pdb_project.data.dataset import FluorescenceDataset
from pdb_project.models.schnet import SchNetFluorescenceModel

log = logging.getLogger(__name__)


def build_model(cfg: DictConfig) -> torch.nn.Module:
    t = cfg.model.type
    if t == "schnet":
        return SchNetFluorescenceModel(
            hidden=cfg.model.hidden,
            num_layers=cfg.model.num_layers,
            rbf_k=cfg.model.rbf_k,
            protein_rbf_high=cfg.model.protein_rbf_high,
            ligand_rbf_high=cfg.model.ligand_rbf_high,
            dropout=cfg.model.dropout,
            use_protein=cfg.model.use_protein,
            use_ligand=cfg.model.use_ligand,
        )
    if t == "gat":
        from pdb_project.models.gat import GATFluorescenceModel

        return GATFluorescenceModel(
            hidden=cfg.model.hidden,
            num_layers=cfg.model.num_layers,
            heads=cfg.model.heads,
            rbf_k=cfg.model.rbf_k,
            protein_rbf_high=cfg.model.protein_rbf_high,
            ligand_rbf_high=cfg.model.ligand_rbf_high,
            dropout=cfg.model.dropout,
        )
    raise NotImplementedError(f"Model type {t!r} not yet wired into the CLI.")


@hydra.main(version_base=None, config_path="../../conf", config_name="config")
def main(cfg: DictConfig) -> None:
    log.info("Resolved config:\n%s", OmegaConf.to_yaml(cfg))
    repo_root = Path(cfg.data.repo_root).resolve()
    ds = FluorescenceDataset(
        labels_csv=cfg.data.labels_csv,
        repo_root=repo_root,
        drop_hydrogens=cfg.data.drop_hydrogens,
        cache_dir=cfg.data.cache_dir,
        altloc_keep=list(cfg.data.altloc_keep),
    )
    log.info("Loaded %d samples", len(ds))
    model = build_model(cfg)
    log.info("Built model: %s", type(model).__name__)


if __name__ == "__main__":
    main()
