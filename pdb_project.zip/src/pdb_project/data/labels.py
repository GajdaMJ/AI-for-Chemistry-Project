"""Load the protein-level labels CSV and resolve PDB file paths."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import pandas as pd

TARGET_COLUMNS = ("brightness", "emission", "qy")


@dataclass(frozen=True)
class LabelRow:
    pdb_code: str
    protein_name: str
    pdb_path: Path
    kDa: float  # noqa: N815 - molecular weight unit convention
    targets: dict[str, float]  # keys: brightness, emission, qy
    sequence: str
    chain: str = "A"


def load_labels(csv_path: str | Path, repo_root: str | Path) -> list[LabelRow]:
    df = pd.read_csv(csv_path)
    required = {"pdb_code", "protein_name", "pdb_path", "kDa", "sequence", *TARGET_COLUMNS}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"labels.csv missing columns: {sorted(missing)}")

    chain_col = "chain" in df.columns

    root = Path(repo_root)
    rows: list[LabelRow] = []
    for _, r in df.iterrows():
        rows.append(
            LabelRow(
                pdb_code=str(r["pdb_code"]),
                protein_name=str(r["protein_name"]),
                pdb_path=(root / str(r["pdb_path"])).resolve(),
                kDa=float(r["kDa"]),
                targets={k: float(r[k]) for k in TARGET_COLUMNS},
                sequence=str(r["sequence"]),
                chain=str(r["chain"]) if chain_col else "A",
            )
        )
    for row in rows:
        _validate_row(row)
    return rows


def _validate_row(row: LabelRow) -> None:
    b = row.targets["brightness"]
    if b < 0:
        raise ValueError(f"Row {row.pdb_code}: brightness must be >= 0 (got {b})")
    e = row.targets["emission"]
    if not (400.0 <= e <= 800.0):
        raise ValueError(f"Row {row.pdb_code}: emission must be in [400, 800] nm (got {e})")
    q = row.targets["qy"]
    if not (0.0 < q <= 1.0):
        raise ValueError(f"Row {row.pdb_code}: qy must be in (0, 1] (got {q})")
    if not (10.0 <= row.kDa <= 100.0):
        raise ValueError(f"Row {row.pdb_code}: kDa must be in [10, 100] (got {row.kDa})")
