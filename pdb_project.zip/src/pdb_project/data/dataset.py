"""Fluorescence dataset: one sample per PDB.

Each sample is a dict to keep two independent PyG graphs + scalar kDa
+ 3-target vector together. We don't use torch_geometric.data.Dataset
because we want two graphs per item; batching is handled explicitly
in the training loop.
"""

from __future__ import annotations

from collections.abc import Sequence
from pathlib import Path
from typing import TypedDict

import torch
from torch.utils.data import Dataset
from torch_geometric.data import Data

from .graph_builder import build_graphs
from .labels import TARGET_COLUMNS, LabelRow, load_labels
from .pdb_parser import DEFAULT_ALTLOC_KEEP, parse_pdb


class Sample(TypedDict):
    """One dataset item: two graphs, a scalar kDa tensor, a 3-target vector, and an id."""

    protein: Data
    ligand: Data
    kDa: torch.Tensor
    y: torch.Tensor
    pdb_code: str


class FluorescenceDataset(Dataset[Sample]):
    def __init__(
        self,
        labels_csv: str | Path,
        repo_root: str | Path,
        drop_hydrogens: bool = True,
        cache_dir: str | Path | None = None,
        altloc_keep: Sequence[str] = DEFAULT_ALTLOC_KEEP,
    ) -> None:
        self.rows: list[LabelRow] = load_labels(labels_csv, repo_root=repo_root)
        self.drop_hydrogens = drop_hydrogens
        self.altloc_keep = tuple(altloc_keep)
        self.cache_dir = Path(cache_dir) if cache_dir is not None else None
        if self.cache_dir is not None:
            self.cache_dir.mkdir(parents=True, exist_ok=True)

    def __len__(self) -> int:
        return len(self.rows)

    def _cache_path(self, row: LabelRow) -> Path | None:
        if self.cache_dir is None:
            return None
        return self.cache_dir / f"{row.pdb_code}.pt"

    def __getitem__(self, idx: int) -> Sample:
        row = self.rows[idx]
        cpath = self._cache_path(row)
        if cpath is not None and cpath.exists():
            cached: Sample = torch.load(cpath, weights_only=False)
            return cached

        records = parse_pdb(row.pdb_path, chain=row.chain, altloc_keep=self.altloc_keep)
        protein_g, ligand_g = build_graphs(records, drop_hydrogens=self.drop_hydrogens)
        y = torch.tensor([row.targets[k] for k in TARGET_COLUMNS], dtype=torch.float32)
        kDa = torch.tensor([row.kDa], dtype=torch.float32)  # noqa: N806
        sample: Sample = {
            "protein": protein_g,
            "ligand": ligand_g,
            "kDa": kDa,
            "y": y,
            "pdb_code": row.pdb_code,
        }
        if cpath is not None:
            torch.save(sample, cpath)
        return sample
