"""Build protein (residue-COM) and NRQ (heavy-atom) graphs.

Both graphs are fully connected with no self-loops. Edge attribute
is the raw scalar Euclidean distance; RBF expansion is done inside
the model so it can be tuned per-graph.
"""

from __future__ import annotations

from typing import cast

import numpy as np
import torch
from torch_geometric.data import Data

from .pdb_parser import STANDARD_AA, PDBRecords, Residue

AA_ORDER = sorted(STANDARD_AA)
AA_TO_IDX = {aa: i for i, aa in enumerate(AA_ORDER)}
LIGAND_ELEMENTS = ("C", "N", "O", "S")
LIGAND_ELEM_TO_IDX = {e: i for i, e in enumerate(LIGAND_ELEMENTS)}


def _residue_com(res: Residue, drop_hydrogens: bool) -> np.ndarray:
    atoms = [a for a in res.atoms if not (drop_hydrogens and a.element == "H")]
    if not atoms:  # fallback: include H if somehow no heavy atoms
        atoms = res.atoms
    xyz = np.stack([a.xyz for a in atoms], axis=0)
    return cast(np.ndarray, xyz.mean(axis=0))


def _fully_connected_edges(n: int) -> torch.Tensor:
    if n < 2:
        return torch.empty((2, 0), dtype=torch.long)
    src, dst = torch.meshgrid(torch.arange(n), torch.arange(n), indexing="ij")
    mask = src != dst
    return torch.stack([src[mask], dst[mask]], dim=0)


def _pairwise_dist(coords: torch.Tensor, edge_index: torch.Tensor) -> torch.Tensor:
    d = coords[edge_index[0]] - coords[edge_index[1]]
    return cast(torch.Tensor, d.norm(dim=-1, keepdim=True))


def build_protein_graph(records: PDBRecords, drop_hydrogens: bool = True) -> Data:
    residues = records.residues
    n = len(residues)
    if n == 0:
        raise ValueError("PDB has no standard amino-acid residues (empty protein graph).")
    x = torch.zeros((n, 20), dtype=torch.float32)
    coms = np.zeros((n, 3), dtype=np.float32)
    for i, res in enumerate(residues):
        x[i, AA_TO_IDX[res.resname]] = 1.0
        coms[i] = _residue_com(res, drop_hydrogens)
    pos = torch.from_numpy(coms)
    edge_index = _fully_connected_edges(n)
    edge_attr = _pairwise_dist(pos, edge_index)
    return Data(x=x, edge_index=edge_index, edge_attr=edge_attr, pos=pos)


def build_ligand_graph(records: PDBRecords, drop_hydrogens: bool = True) -> Data:
    if records.ligand is None:
        raise ValueError("PDB has no NRQ ligand; cannot build ligand graph.")
    atoms = records.ligand.atoms
    if drop_hydrogens:
        atoms = [a for a in atoms if a.element != "H"]
    n = len(atoms)
    x = torch.zeros((n, len(LIGAND_ELEMENTS)), dtype=torch.float32)
    xyz = np.zeros((n, 3), dtype=np.float32)
    for i, a in enumerate(atoms):
        if a.element not in LIGAND_ELEM_TO_IDX:
            raise ValueError(f"Unexpected NRQ element: {a.element!r}")
        x[i, LIGAND_ELEM_TO_IDX[a.element]] = 1.0
        xyz[i] = a.xyz
    pos = torch.from_numpy(xyz)
    edge_index = _fully_connected_edges(n)
    edge_attr = _pairwise_dist(pos, edge_index)
    return Data(x=x, edge_index=edge_index, edge_attr=edge_attr, pos=pos)


def build_graphs(records: PDBRecords, drop_hydrogens: bool = True) -> tuple[Data, Data]:
    return (
        build_protein_graph(records, drop_hydrogens=drop_hydrogens),
        build_ligand_graph(records, drop_hydrogens=drop_hydrogens),
    )
