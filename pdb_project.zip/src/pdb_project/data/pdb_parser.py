"""Minimal PDB parser.

Reads ATOM / HETATM lines using fixed-column PDB format, not BioPython,
so we can run on bare dependencies and stay deterministic. BioPython is
listed as a dependency for downstream use (ESM / sequence extraction)
but parsing is hand-rolled here for speed + auditability.
"""

from __future__ import annotations

import logging
from collections.abc import Sequence
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

logger = logging.getLogger(__name__)

STANDARD_AA = {
    "ALA",
    "ARG",
    "ASN",
    "ASP",
    "CYS",
    "GLN",
    "GLU",
    "GLY",
    "HIS",
    "ILE",
    "LEU",
    "LYS",
    "MET",
    "PHE",
    "PRO",
    "SER",
    "THR",
    "TRP",
    "TYR",
    "VAL",
}


@dataclass(frozen=True)
class Atom:
    name: str
    element: str
    xyz: np.ndarray  # shape (3,), float32


@dataclass
class Residue:
    resname: str
    chain: str
    resseq: int
    atoms: list[Atom] = field(default_factory=list)


@dataclass
class PDBRecords:
    residues: list[Residue]  # standard amino acids only
    ligand: Residue | None  # the NRQ residue, or None if absent
    waters: list[Residue]  # HOH residues


def _parse_line(line: str) -> tuple[str, str, str, str, int, str, np.ndarray, str]:
    """Return (record, atom_name, altloc, resname, resseq, chain, xyz, element)."""
    record = line[0:6].strip()
    atom_name = line[12:16].strip()
    altloc = line[16:17]
    resname = line[17:20].strip()
    chain = line[21:22].strip()
    resseq = int(line[22:26])
    x = float(line[30:38])
    y = float(line[38:46])
    z = float(line[46:54])
    element = line[76:78].strip()
    return (
        record,
        atom_name,
        altloc,
        resname,
        resseq,
        chain,
        np.array([x, y, z], dtype=np.float32),
        element,
    )


DEFAULT_ALTLOC_KEEP: tuple[str, ...] = (" ", "A", "")


def parse_pdb(
    path: str | Path,
    chain: str | None = None,
    altloc_keep: Sequence[str] = DEFAULT_ALTLOC_KEEP,
) -> PDBRecords:
    residues: list[Residue] = []
    ligand: Residue | None = None
    waters: list[Residue] = []
    current: Residue | None = None
    current_key: tuple[str, int, str] | None = None
    altloc_set = set(altloc_keep)

    path = Path(path)
    for lineno, raw_line in enumerate(path.read_text().splitlines(), start=1):
        if not (raw_line.startswith("ATOM") or raw_line.startswith("HETATM")):
            continue
        try:
            record, atom_name, altloc, resname, resseq, chain_id, xyz, element = _parse_line(
                raw_line
            )
        except ValueError:
            logger.warning("Skipping malformed %s line %d: %r", path.name, lineno, raw_line)
            continue
        if altloc not in altloc_set:
            continue
        if chain is not None and chain_id != chain:
            continue
        atom = Atom(name=atom_name, element=element, xyz=xyz)

        key = (resname, resseq, chain_id)

        if resname in STANDARD_AA and record == "ATOM":
            if key != current_key:
                current = Residue(resname=resname, chain=chain_id, resseq=resseq)
                residues.append(current)
                current_key = key
            assert current is not None
            current.atoms.append(atom)
        elif resname == "NRQ":
            if ligand is None:
                ligand = Residue(resname="NRQ", chain=chain_id, resseq=resseq)
            ligand.atoms.append(atom)
        elif resname == "HOH":
            if not waters or (waters[-1].resname, waters[-1].resseq, waters[-1].chain) != key:
                waters.append(Residue(resname="HOH", chain=chain_id, resseq=resseq))
            waters[-1].atoms.append(atom)
        # Ignore other HETATMs (ions, etc.) - they are not used anywhere.

    return PDBRecords(residues=residues, ligand=ligand, waters=waters)
