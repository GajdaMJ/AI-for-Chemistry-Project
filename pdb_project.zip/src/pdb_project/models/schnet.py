"""SchNet-style continuous-filter convolution + end-to-end model.

Reference: Schütt et al., NeurIPS 2017.
cfconv message: m_ij = h_j * MLP(RBF(d_ij))
"""

from __future__ import annotations

from typing import cast

import torch
from torch import nn
from torch_geometric.data import Batch
from torch_geometric.nn import MessagePassing, global_mean_pool

from .head import FusionHead
from .rbf import GaussianRBF


class CFConv(MessagePassing):  # type: ignore[misc]
    """Continuous-filter convolution (SchNet)."""

    def __init__(self, hidden: int, rbf_k: int) -> None:
        super().__init__(aggr="mean")
        self.filter_net = nn.Sequential(
            nn.Linear(rbf_k, hidden),
            nn.SiLU(),
            nn.Linear(hidden, hidden),
        )
        self.lin_in = nn.Linear(hidden, hidden)
        self.lin_out = nn.Linear(hidden, hidden)

    def forward(
        self,
        x: torch.Tensor,  # (N, H)
        edge_index: torch.Tensor,  # (2, E)
        edge_rbf: torch.Tensor,  # (E, K)
    ) -> torch.Tensor:
        h = self.lin_in(x)
        w = self.filter_net(edge_rbf)
        out = self.propagate(edge_index, x=h, W=w)
        return cast(torch.Tensor, x + self.lin_out(nn.functional.silu(out)))

    def message(self, x_j: torch.Tensor, W: torch.Tensor) -> torch.Tensor:  # noqa: N803
        return x_j * W


class SchNetEncoder(nn.Module):
    """Shared encoder template for either graph (protein or ligand).

    Input node features are projected to `hidden`, then `num_layers`
    cfconv blocks apply distance-aware message passing. Mean pool
    collapses to a graph-level embedding.
    """

    def __init__(
        self,
        node_in: int,
        hidden: int,
        num_layers: int,
        rbf_k: int,
        rbf_high: float,
    ) -> None:
        super().__init__()
        self.embed = nn.Linear(node_in, hidden)
        self.rbf = GaussianRBF(num_centers=rbf_k, low=0.0, high=rbf_high)
        self.layers = nn.ModuleList([CFConv(hidden, rbf_k) for _ in range(num_layers)])

    def forward(self, batch: Batch) -> torch.Tensor:
        x = self.embed(batch.x)
        d = batch.edge_attr.squeeze(-1)  # (E,)
        rbf = self.rbf(d)  # (E, K)
        for layer in self.layers:
            x = layer(x, batch.edge_index, rbf)
        return cast(torch.Tensor, global_mean_pool(x, batch.batch))


class SchNetFluorescenceModel(nn.Module):
    def __init__(
        self,
        node_in_protein: int = 20,
        node_in_ligand: int = 4,
        hidden: int = 64,
        num_layers: int = 3,
        rbf_k: int = 16,
        protein_rbf_high: float = 20.0,
        ligand_rbf_high: float = 10.0,
        out_dim: int = 3,
        dropout: float = 0.2,
        use_protein: bool = True,
        use_ligand: bool = True,
    ) -> None:
        super().__init__()
        assert use_protein or use_ligand, "At least one graph stream must be enabled."
        self.use_protein = use_protein
        self.use_ligand = use_ligand
        self.protein_enc = (
            SchNetEncoder(
                node_in=node_in_protein,
                hidden=hidden,
                num_layers=num_layers,
                rbf_k=rbf_k,
                rbf_high=protein_rbf_high,
            )
            if use_protein
            else None
        )
        self.ligand_enc = (
            SchNetEncoder(
                node_in=node_in_ligand,
                hidden=hidden,
                num_layers=num_layers,
                rbf_k=rbf_k,
                rbf_high=ligand_rbf_high,
            )
            if use_ligand
            else None
        )
        self.head = FusionHead(
            h_prot_dim=hidden if use_protein else 0,
            h_lig_dim=hidden if use_ligand else 0,
            scalar_feature_dim=1,
            hidden=hidden,
            out_dim=out_dim,
            dropout=dropout,
        )

    def forward(
        self,
        protein_batch: Batch,
        ligand_batch: Batch,
        kDa: torch.Tensor,  # noqa: N803
    ) -> torch.Tensor:
        h_prot = self.protein_enc(protein_batch) if self.protein_enc is not None else None
        h_lig = self.ligand_enc(ligand_batch) if self.ligand_enc is not None else None
        return cast(torch.Tensor, self.head(h_prot, h_lig, kDa))
