"""B1: ridge regression on 41-dim hand-crafted features.

Features:
  - kDa                                         (1)
  - AA composition (fraction per AA)            (20)
  - NRQ contact-residue composition              (20)
      residues with COM within `contact_cutoff` Å of any NRQ atom
      → 20-dim fraction (normalized, or all-zero if no contacts)
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from sklearn.linear_model import Ridge

from ..data.dataset import Sample
from ..data.graph_builder import AA_ORDER


def featurize_sample(sample: Sample, contact_cutoff: float = 6.0) -> np.ndarray:
    protein = sample["protein"]  # PyG Data
    ligand = sample["ligand"]
    kDa = sample["kDa"].item()  # noqa: N806

    aa_hot = protein.x.numpy()
    n = aa_hot.shape[0]
    aa_comp = aa_hot.sum(axis=0) / max(n, 1)  # (20,)

    # Contact residues: any ligand atom within `contact_cutoff` Å of residue COM
    prot_pos = protein.pos.numpy()  # (N_res, 3)
    lig_pos = ligand.pos.numpy()  # (N_atom, 3)
    # pairwise distances, (N_res, N_atom)
    diff = prot_pos[:, None, :] - lig_pos[None, :, :]
    dists = np.linalg.norm(diff, axis=-1)
    in_contact = (dists <= contact_cutoff).any(axis=1)  # (N_res,)
    contact_aa_hot = aa_hot[in_contact]
    if contact_aa_hot.shape[0] == 0:
        contact_comp = np.zeros(len(AA_ORDER), dtype=np.float32)
    else:
        contact_comp = contact_aa_hot.sum(axis=0) / contact_aa_hot.shape[0]

    return np.concatenate([[kDa], aa_comp, contact_comp]).astype(np.float32)


@dataclass
class LinearBaseline:
    alpha: float = 1.0
    model: Ridge | None = None

    def fit(self, X: np.ndarray, y: np.ndarray) -> LinearBaseline:  # noqa: N803
        self.model = Ridge(alpha=self.alpha).fit(X, y)
        return self

    def predict(self, X: np.ndarray) -> np.ndarray:  # noqa: N803
        assert self.model is not None
        return self.model.predict(X)  # type: ignore[no-any-return]
