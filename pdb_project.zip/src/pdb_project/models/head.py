"""Shared fusion + MLP head used by SchNet, GAT, ESM-2, and linear baselines.

Concatenates [h_prot, h_lig, scalar_features] -> MLP -> out_dim.
Accepts None for either graph embedding to support sequence-only or
scalar-only models without code duplication.
"""

from __future__ import annotations

from typing import cast

import torch
from torch import nn


class FusionHead(nn.Module):
    def __init__(
        self,
        h_prot_dim: int,
        h_lig_dim: int,
        scalar_feature_dim: int,
        hidden: int = 64,
        out_dim: int = 3,
        dropout: float = 0.2,
    ) -> None:
        super().__init__()
        in_dim = h_prot_dim + h_lig_dim + scalar_feature_dim
        assert in_dim > 0, "FusionHead needs at least one input stream."
        self.net = nn.Sequential(
            nn.Dropout(dropout),
            nn.Linear(in_dim, hidden),
            nn.SiLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, hidden // 2),
            nn.SiLU(),
            nn.Linear(hidden // 2, out_dim),
        )

    def forward(
        self,
        h_prot: torch.Tensor | None,
        h_lig: torch.Tensor | None,
        scalar: torch.Tensor,
    ) -> torch.Tensor:
        parts: list[torch.Tensor] = []
        if h_prot is not None:
            parts.append(h_prot)
        if h_lig is not None:
            parts.append(h_lig)
        parts.append(scalar)
        return cast(torch.Tensor, self.net(torch.cat(parts, dim=-1)))
