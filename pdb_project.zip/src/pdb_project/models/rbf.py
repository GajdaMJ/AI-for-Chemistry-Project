"""Gaussian RBF distance expansion (SchNet-style).

Given a distance d (shape [...]) returns a feature vector of shape
[..., num_centers] where feature k = exp(-gamma * (d - mu_k)^2).
"""

from __future__ import annotations

import torch
from torch import nn


class GaussianRBF(nn.Module):
    centers: torch.Tensor
    gamma: torch.Tensor

    def __init__(self, num_centers: int = 16, low: float = 0.0, high: float = 20.0) -> None:
        super().__init__()
        centers = torch.linspace(low, high, num_centers)
        width = (high - low) / max(num_centers - 1, 1)
        # gamma chosen so adjacent RBFs have ~0.5 overlap at their midpoint
        gamma = 1.0 / (2.0 * width**2)
        self.register_buffer("centers", centers)
        self.register_buffer("gamma", torch.tensor(gamma))

    def forward(self, distances: torch.Tensor) -> torch.Tensor:
        # distances: [...], centers: [K] → output: [..., K]
        diff = distances.unsqueeze(-1) - self.centers
        return torch.exp(-self.gamma * diff * diff)
