"""B0: always predict the train-set mean."""

from __future__ import annotations

from dataclasses import dataclass

import torch


@dataclass
class ConstantPredictor:
    mean: torch.Tensor  # shape (T,)

    @classmethod
    def fit(cls, y_train: torch.Tensor) -> ConstantPredictor:
        return cls(mean=y_train.mean(dim=0).detach())

    def predict(self, batch_size: int) -> torch.Tensor:
        return self.mean.unsqueeze(0).expand(batch_size, -1).clone()
