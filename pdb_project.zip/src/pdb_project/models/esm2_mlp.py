"""B2: frozen ESM-2 encoder + MLP head on mean-pooled residue embeddings.

We freeze ESM-2 (no fine-tuning) for both compute reasons and for honesty
as a baseline — the question this baseline answers is "how far does a
pretrained sequence model get us?", not "can we tune a giant model on
100 proteins?".
"""

from __future__ import annotations

from typing import cast

import esm
import torch
from torch import nn

from .head import FusionHead


class ESM2Baseline(nn.Module):
    def __init__(
        self,
        esm_model_name: str = "esm2_t12_35M_UR50D",
        mlp_hidden: int = 128,
        out_dim: int = 3,
        dropout: float = 0.2,
    ) -> None:
        super().__init__()
        load = getattr(esm.pretrained, esm_model_name)
        backbone, alphabet = load()
        for p in backbone.parameters():
            p.requires_grad = False
        backbone.eval()
        self.backbone = backbone
        self.batch_converter = alphabet.get_batch_converter()
        self.repr_layer = backbone.num_layers
        self.embed_dim = backbone.embed_dim
        self.head = FusionHead(
            h_prot_dim=self.embed_dim,
            h_lig_dim=0,
            scalar_feature_dim=1,
            hidden=mlp_hidden,
            out_dim=out_dim,
            dropout=dropout,
        )

    @torch.no_grad()
    def _embed(self, sequences: list[str]) -> torch.Tensor:
        pairs = [(f"s{i}", s) for i, s in enumerate(sequences)]
        _, _, toks = self.batch_converter(pairs)
        toks = toks.to(next(self.head.parameters()).device)
        out = self.backbone(toks, repr_layers=[self.repr_layer])
        reprs = out["representations"][self.repr_layer]  # (B, L, D)
        # Drop BOS/EOS; mean pool over residues
        return cast(torch.Tensor, reprs[:, 1:-1, :].mean(dim=1))

    def forward(self, sequences: list[str], kDa: torch.Tensor) -> torch.Tensor:  # noqa: N803
        h_prot = self._embed(sequences)
        return cast(torch.Tensor, self.head(h_prot, None, kDa))
