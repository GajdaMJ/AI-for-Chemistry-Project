"""GATv2-based variant of the dual-graph model.

Same data pipeline, same pooling, same FusionHead as SchNet.
Only the graph-layer mechanism changes (attention over RBF-expanded
edge features vs. SchNet's continuous-filter convolution).
"""

from __future__ import annotations

from typing import cast

import torch
from torch import nn
from torch_geometric.data import Batch
from torch_geometric.nn import GATv2Conv, global_mean_pool

from .head import FusionHead
from .rbf import GaussianRBF


class GATEncoder(nn.Module):
    def __init__(
        self,
        node_in: int,
        hidden: int,
        num_layers: int,
        heads: int,
        rbf_k: int,
        rbf_high: float,
    ) -> None:
        super().__init__()
        self.embed = nn.Linear(node_in, hidden)
        self.rbf = GaussianRBF(num_centers=rbf_k, low=0.0, high=rbf_high)
        layers: list[nn.Module] = []
        in_dim = hidden
        for i in range(num_layers):
            is_last = i == num_layers - 1
            out_heads = 1 if is_last else heads
            out_dim = hidden if is_last else hidden * heads
            layers.append(
                GATv2Conv(
                    in_dim,
                    hidden if is_last else hidden,
                    heads=out_heads,
                    concat=not is_last,
                    edge_dim=rbf_k,
                    add_self_loops=False,
                )
            )
            in_dim = out_dim
        self.layers = nn.ModuleList(layers)
        self.act = nn.SiLU()

    def forward(self, batch: Batch) -> torch.Tensor:
        x = self.embed(batch.x)
        d = batch.edge_attr.squeeze(-1)
        edge_rbf = self.rbf(d)
        for layer in self.layers:
            x = self.act(layer(x, batch.edge_index, edge_attr=edge_rbf))
        return cast(torch.Tensor, global_mean_pool(x, batch.batch))


class GATFluorescenceModel(nn.Module):
    def __init__(
        self,
        node_in_protein: int = 20,
        node_in_ligand: int = 4,
        hidden: int = 64,
        num_layers: int = 3,
        heads: int = 4,
        rbf_k: int = 16,
        protein_rbf_high: float = 20.0,
        ligand_rbf_high: float = 10.0,
        out_dim: int = 3,
        dropout: float = 0.2,
    ) -> None:
        super().__init__()
        self.protein_enc = GATEncoder(
            node_in=node_in_protein,
            hidden=hidden,
            num_layers=num_layers,
            heads=heads,
            rbf_k=rbf_k,
            rbf_high=protein_rbf_high,
        )
        self.ligand_enc = GATEncoder(
            node_in=node_in_ligand,
            hidden=hidden,
            num_layers=num_layers,
            heads=heads,
            rbf_k=rbf_k,
            rbf_high=ligand_rbf_high,
        )
        self.head = FusionHead(
            h_prot_dim=hidden,
            h_lig_dim=hidden,
            scalar_feature_dim=1,
            hidden=hidden,
            out_dim=out_dim,
            dropout=dropout,
        )

    def forward(
        self,
        protein_batch: Batch,
        ligand_batch: Batch,
        kDa: torch.Tensor,  # noqa: N803
    ) -> torch.Tensor:
        h_prot = self.protein_enc(protein_batch)
        h_lig = self.ligand_enc(ligand_batch)
        return cast(torch.Tensor, self.head(h_prot, h_lig, kDa))
