"""Per-target MAE + R² plus overall (standardized-mean) MAE."""

from __future__ import annotations

from collections.abc import Sequence

import torch


def _r2(y_hat: torch.Tensor, y: torch.Tensor) -> float:
    ss_res = ((y - y_hat) ** 2).sum()
    ss_tot = ((y - y.mean()) ** 2).sum()
    if ss_tot.item() == 0.0:
        return 1.0 if ss_res.item() == 0.0 else 0.0
    return float(1.0 - ss_res / ss_tot)


def compute_metrics(
    y_hat: torch.Tensor,
    y: torch.Tensor,
    target_names: Sequence[str],
) -> dict[str, float]:
    """Inputs are on the original (unstandardized) scale.

    Returns:
      mae/<name>, r2/<name> per target; mae/overall averaged across
      z-scored targets (so brightness ~O(10), emission ~O(100), qy ~O(1)
      all contribute equally).
    """
    assert y_hat.shape == y.shape
    assert y.ndim == 2 and y.shape[1] == len(target_names)

    out: dict[str, float] = {}
    per_std_maes: list[float] = []
    for i, name in enumerate(target_names):
        yh = y_hat[:, i]
        yy = y[:, i]
        out[f"mae/{name}"] = float((yh - yy).abs().mean())
        out[f"r2/{name}"] = _r2(yh, yy)
        std = float(yy.std(unbiased=False).clamp_min(1e-6))
        per_std_maes.append(float((yh - yy).abs().mean() / std))
    out["mae/overall"] = float(sum(per_std_maes) / len(per_std_maes))
    return out
