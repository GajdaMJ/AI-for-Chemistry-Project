"""Simple fit-once standardizer (mean/std) for targets and scalar features.

Intentionally minimal: computed from training data, applied to train/val/test,
inverted for reporting.
"""

from __future__ import annotations

from dataclasses import dataclass

import torch


@dataclass
class Standardizer:
    mean: torch.Tensor
    std: torch.Tensor

    @classmethod
    def fit(cls, x: torch.Tensor, eps: float = 1e-6) -> Standardizer:
        mean = x.mean(dim=0)
        std = x.std(dim=0, unbiased=False).clamp_min(eps)
        return cls(mean=mean.detach(), std=std.detach())

    def transform(self, x: torch.Tensor) -> torch.Tensor:
        return (x - self.mean) / self.std

    def inverse(self, z: torch.Tensor) -> torch.Tensor:
        return z * self.std + self.mean

    def state_dict(self) -> dict[str, torch.Tensor]:
        return {"mean": self.mean, "std": self.std}

    @classmethod
    def from_state_dict(cls, state: dict[str, torch.Tensor]) -> Standardizer:
        return cls(mean=state["mean"], std=state["std"])
