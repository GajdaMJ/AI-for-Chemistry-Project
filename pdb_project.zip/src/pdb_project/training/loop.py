"""Training loop primitives.

Batching: we can't use the default PyG DataLoader because each sample has
TWO graphs plus a scalar and a target vector. collate_fn builds a Batch
for each graph stream independently.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass

import torch
from torch import nn
from torch.utils.data import DataLoader
from torch_geometric.data import Batch

from ..data.dataset import Sample
from .standardize import Standardizer


@dataclass
class TrainConfig:
    grad_clip: float = 1.0


def collate_fn(samples: Sequence[Sample]) -> dict[str, object]:
    proteins = Batch.from_data_list([s["protein"] for s in samples])
    ligands = Batch.from_data_list([s["ligand"] for s in samples])
    kDa = torch.stack([s["kDa"] for s in samples], dim=0)  # noqa: N806
    y = torch.stack([s["y"] for s in samples], dim=0)
    pdb_codes = [s["pdb_code"] for s in samples]
    return {"protein": proteins, "ligand": ligands, "kDa": kDa, "y": y, "pdb_codes": pdb_codes}


def train_one_epoch(
    model: nn.Module,
    loader: DataLoader[Sample],
    optimizer: torch.optim.Optimizer,
    y_std: Standardizer,
    kDa_std: Standardizer,  # noqa: N803
    cfg: TrainConfig,
) -> float:
    model.train()
    total = 0.0
    n = 0
    for batch in loader:
        optimizer.zero_grad()
        kDa = kDa_std.transform(batch["kDa"])  # noqa: N806
        y_hat = model(batch["protein"], batch["ligand"], kDa)
        z = y_std.transform(batch["y"])
        loss = ((y_hat - z) ** 2).mean()
        loss.backward()
        if cfg.grad_clip > 0:
            torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.grad_clip)
        optimizer.step()
        total += float(loss.detach())
        n += 1
    return total / max(n, 1)


@torch.no_grad()
def evaluate(
    model: nn.Module,
    loader: DataLoader[Sample],
    y_std: Standardizer,
    kDa_std: Standardizer,  # noqa: N803
) -> tuple[torch.Tensor, torch.Tensor]:
    """Return (y_hat_original_scale, y_original_scale)."""
    model.eval()
    preds: list[torch.Tensor] = []
    gts: list[torch.Tensor] = []
    for batch in loader:
        kDa = kDa_std.transform(batch["kDa"])  # noqa: N806
        z_hat = model(batch["protein"], batch["ligand"], kDa)
        y_hat = y_std.inverse(z_hat)
        preds.append(y_hat)
        gts.append(batch["y"])
    return torch.cat(preds, 0), torch.cat(gts, 0)
