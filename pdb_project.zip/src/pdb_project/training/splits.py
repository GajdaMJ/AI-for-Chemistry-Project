"""Sequence-identity clustering + k-fold assignment.

Primary path: mmseqs2 easy-cluster on a temporary FASTA.
Fallback (no mmseqs2 binary OR `fallback=True`): union-find on
exact-sequence identity, i.e. only proteins with identical sequences
are clustered. Meant ONLY for development; never for the 100-protein
reporting run.
"""

from __future__ import annotations

import hashlib
import random
import shutil
import subprocess
import tempfile
from collections import defaultdict
from pathlib import Path


def cluster_sequences(
    sequences: dict[str, str],
    identity: float = 0.7,
    fallback: bool = False,
    coverage: float = 0.8,
) -> dict[str, list[str]]:
    """Return {cluster_id: [protein_id, ...]}.

    cluster_id is arbitrary but stable within one call.
    """
    if fallback or shutil.which("mmseqs") is None:
        return _fallback_cluster(sequences)
    return _mmseqs_cluster(sequences, identity=identity, coverage=coverage)


def _fallback_cluster(sequences: dict[str, str]) -> dict[str, list[str]]:
    buckets: dict[str, list[str]] = defaultdict(list)
    for pid, seq in sequences.items():
        key = hashlib.sha1(seq.encode()).hexdigest()
        buckets[key].append(pid)
    return {f"cluster_{i}": members for i, members in enumerate(buckets.values())}


def _mmseqs_cluster(
    sequences: dict[str, str], identity: float, coverage: float
) -> dict[str, list[str]]:
    with tempfile.TemporaryDirectory() as tmp:
        tmpp = Path(tmp)
        fasta = tmpp / "in.fasta"
        fasta.write_text("".join(f">{pid}\n{seq}\n" for pid, seq in sequences.items()))
        out_prefix = tmpp / "out"
        work = tmpp / "work"
        work.mkdir()
        subprocess.run(
            [
                "mmseqs",
                "easy-cluster",
                str(fasta),
                str(out_prefix),
                str(work),
                "--min-seq-id",
                str(identity),
                "-c",
                str(coverage),
                "--cov-mode",
                "0",
            ],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        tsv = Path(f"{out_prefix}_cluster.tsv")
        clusters: dict[str, list[str]] = defaultdict(list)
        for line in tsv.read_text().splitlines():
            rep, member = line.split("\t")
            clusters[rep].append(member)
    return dict(clusters)


def assign_folds(
    clusters: dict[str, list[str]],
    k: int = 5,
    seed: int = 0,
) -> dict[int, list[str]]:
    """Greedy load-balanced assignment of whole clusters to folds.

    Deterministic given (clusters, k, seed).
    """
    rng = random.Random(seed)
    items = sorted(clusters.items())
    rng.shuffle(items)
    # Sort by cluster size desc to pack fuller clusters first (LPT heuristic)
    items.sort(key=lambda kv: (-len(kv[1]), kv[0]))

    folds: dict[int, list[str]] = {i: [] for i in range(k)}
    fold_sizes = [0] * k
    for _cluster_id, members in items:
        target = min(range(k), key=lambda i: (fold_sizes[i], i))
        folds[target].extend(members)
        fold_sizes[target] += len(members)
    return folds
