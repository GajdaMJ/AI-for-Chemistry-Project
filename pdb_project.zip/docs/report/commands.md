# Commands to Reproduce All Results

> **Companion to** `docs/report/scientific-framework.md`. Every command below is a literal copy-paste from the project root. All Python is invoked through `uv run` — never `python` directly — so environment resolution is deterministic.
>
> **Project root:** `/home/l-braz/Documents/git/pdb_project`
>
> **Status note (2026-04-18).** `scripts/run_cv.py` dispatches the full baseline ladder: `constant`, `linear`, `schnet`, `gat`, and `esm2`. Every command below that *is* runnable today is marked ✅; remaining gaps are marked ⚠️.

---

## 1. One-time setup

```bash
# From the project root.
uv sync --all-extras                     # install all runtime + dev deps
uv run pre-commit install                # install the ruff pre-commit hook
```

Expected: `.venv/` populated (~5 GB with torch + cuda + pyg), hook installed at `.git/hooks/pre-commit`.

---

## 2. Verify the pipeline works (tests)

### 2.1 Full unit-test suite ✅

```bash
uv run pytest -v
```

Expected: **38 tests pass** (4 harmless `DeprecationWarning`s from upstream torch/pyg). If fewer than 38 or anything fails, stop and investigate before any training run.

### 2.2 Hydra CLI wiring smoke tests ✅

```bash
uv run python -m pdb_project.cli model=schnet       # default
uv run python -m pdb_project.cli model=gat
uv run python -m pdb_project.cli model=constant
uv run python -m pdb_project.cli model=linear
uv run python -m pdb_project.cli model=esm2
```

Expected: each prints a resolved config block and `Built model: <Class>Model`. Nothing else.

---

## 3. 5-fold cross-validation — full baseline ladder

All CV runs produce `outputs/cv_results.json` **overwriting the previous one**. Redirect with `--out-json` to keep per-model results.

**Important**: With the current 2-protein dataset, pass `--k 2 --fallback-clustering` to the commands below. Once `data/labels.csv` has ~100 rows, drop both flags so `--k 5` + `mmseqs2` take over automatically.

### 3.1 B0 — Constant predictor ✅

```bash
# Current (n=2, dev):
uv run python scripts/run_cv.py --model constant --k 2 --fallback-clustering \
    --out-json outputs/cv_constant.json

# Production (n≈100):
uv run python scripts/run_cv.py --model constant \
    --out-json outputs/cv_constant.json
```

### 3.2 B1 — Ridge on hand-crafted features ✅

```bash
uv run python scripts/run_cv.py --model linear --k 2 --fallback-clustering \
    --ridge-alpha 1.0 --contact-cutoff 6.0 \
    --out-json outputs/cv_linear.json

# Production:
uv run python scripts/run_cv.py --model linear \
    --ridge-alpha 1.0 --contact-cutoff 6.0 \
    --out-json outputs/cv_linear.json
```

### 3.3 B3a — SchNet (primary model) ✅

```bash
# Current (dev):
uv run python scripts/run_cv.py --model schnet --k 2 --fallback-clustering \
    --max-epochs 10 --patience 5 \
    --out-json outputs/cv_schnet.json

# Production (default hyperparameters from conf/model/schnet.yaml):
uv run python scripts/run_cv.py --model schnet \
    --max-epochs 200 --patience 30 --batch-size 8 --lr 1e-3 --weight-decay 1e-4 \
    --out-json outputs/cv_schnet.json
```

### 3.4 B3b — GAT variant ✅

```bash
# Current (n=2, dev):
uv run python scripts/run_cv.py --model gat --k 2 --fallback-clustering \
    --max-epochs 10 --patience 5 --heads 4 \
    --out-json outputs/cv_gat.json

# Production (n≈100):
uv run python scripts/run_cv.py --model gat \
    --max-epochs 200 --patience 30 --batch-size 8 --lr 1e-3 --weight-decay 1e-4 \
    --heads 4 \
    --out-json outputs/cv_gat.json
```

### 3.5 B2 — ESM-2 frozen + MLP ✅

```bash
# Current (n=2, dev) — uses the small 8M-param backbone cached from Task 18:
uv run python scripts/run_cv.py --model esm2 --k 2 --fallback-clustering \
    --esm-model esm2_t6_8M_UR50D --max-epochs 3 --patience 2 \
    --out-json outputs/cv_esm2.json

# Production (n≈100) — 35M-param ESM-2 backbone, frozen; only the MLP head trains:
uv run python scripts/run_cv.py --model esm2 \
    --esm-model esm2_t12_35M_UR50D --mlp-hidden 128 \
    --max-epochs 200 --patience 30 --batch-size 8 --lr 1e-3 --weight-decay 1e-4 \
    --out-json outputs/cv_esm2.json
```

---

## 4. Ablation sweeps

Ablations on **B3a (SchNet)**. Graph-branch ablations run directly through the CV runner; preprocessing ablations go through the Hydra CLI for wiring checks.

### 4.1 Preprocessing-wiring checks ✅

```bash
# Alternative altLoc policy
uv run python -m pdb_project.cli 'data.altloc_keep=[B]'
uv run python -m pdb_project.cli data.drop_hydrogens=false
```

### 4.2 CV with graph-branch ablations ✅

```bash
# Ligand-only (drops the protein graph):
uv run python scripts/run_cv.py --model schnet --no-protein --k 2 --fallback-clustering \
    --max-epochs 10 --patience 5 \
    --out-json outputs/cv_schnet_ligand_only.json

# Protein-only (drops the NRQ graph):
uv run python scripts/run_cv.py --model schnet --no-ligand --k 2 --fallback-clustering \
    --max-epochs 10 --patience 5 \
    --out-json outputs/cv_schnet_protein_only.json
```

Production forms: drop `--k 2 --fallback-clustering` and bump epochs/patience as in §3.3. Both flags together (`--no-protein --no-ligand`) are refused by argparse — the model needs at least one graph branch.

---

## 5. Repeat runs with different seeds (variance over initialization)

Once the 100-protein dataset is in, report mean ± std across **both folds and seeds**:

```bash
for SEED in 0 1 2; do
  uv run python scripts/run_cv.py --model schnet --seed "$SEED" \
      --out-json "outputs/cv_schnet_seed${SEED}.json"
done
```

Then aggregate the three JSONs manually (or add a small aggregation script under `scripts/`).

---

## 6. Interpreting outputs

Each `outputs/cv_<model>.json` contains:

```json
{
  "model": "<name>",
  "per_fold": [ { "mae/brightness": ..., "r2/brightness": ..., ... }, ... ],
  "aggregate": {
    "mae/brightness": { "mean": ..., "std": ... },
    ...
  }
}
```

- **Report `aggregate.mae/<target>.mean ± std`** per target. These are in original units (nm for emission, dimensionless for QY and brightness).
- **Compare against B0**: every learned model should beat B0's MAE comfortably. If not, something is wrong.
- **`mae/overall`** is the standardized-mean MAE used for early stopping; don't report it as a headline number — the unstandardized per-target MAEs are more interpretable.

### 6.1 Aggregate across baselines ✅

`scripts/aggregate_results.py` reads all `outputs/cv_*.json` files and emits a single markdown report with per-target MAE/R² tables and paired-bootstrap 95 % CIs of each model's MAE difference vs. a baseline (default: `constant`).

```bash
# All baselines, bootstrap CI vs B0 (constant), write to report file:
uv run python scripts/aggregate_results.py outputs/cv_*.json \
    --baseline constant --bootstrap-resamples 10000 \
    --out docs/report/results_summary.md

# Or print to stdout:
uv run python scripts/aggregate_results.py outputs/cv_*.json --baseline constant

# Skip bootstrap (tables only):
uv run python scripts/aggregate_results.py outputs/cv_*.json --no-baseline
```

A ✓ in the CI column means the model's 95 % CI lies entirely below zero — i.e. the model is significantly better than the baseline on that target.

### 6.2 Plot per-target MAE bar charts ✅

`scripts/plot_results.py` writes one PNG per target (`mae_brightness.png`, `mae_emission.png`, `mae_qy.png`) with one bar per model and std-over-folds error bars.

```bash
uv run python scripts/plot_results.py outputs/cv_*.json --out figures/
```

Requires `matplotlib` (already in `pyproject.toml`).

---

## 7. Adding new proteins to the dataset

```bash
# 1. Drop the PDB file
cp /path/to/NEWPDB_name.pdb data/raw/

# 2. Append a row to data/labels.csv (all columns required EXCEPT `chain`):
#    pdb_code,protein_name,pdb_path,kDa,brightness,emission,qy,sequence[,chain]
#    Example: NEWPDB,myFP,data/raw/NEWPDB_name.pdb,26.0,50.0,550,0.6,MVSK...,A
echo 'NEWPDB,myFP,data/raw/NEWPDB_name.pdb,26.0,50.0,550,0.6,MVSK...,A' >> data/labels.csv

# 3. Clear the dataset cache (altLoc/chain filters changed inputs since last cache)
rm -rf data/cache

# 4. Verify the new protein parses & graphs build
uv run pytest tests/test_dataset.py tests/test_graph_builder.py -v
```

If the label-sanity check fails, one of the numeric fields is out of physics range (emission ∉ [400, 800], qy ∉ (0, 1], brightness < 0, or kDa ∉ [10, 100]). See `src/pdb_project/data/labels.py::_validate_row`.

---

## 8. Quick housekeeping

```bash
uv run pre-commit run --all-files         # lint+format everything
uv run pytest -q                          # silent test pass
git log --oneline | head -20              # review recent commits
du -sh data/cache                         # check cache size
```

---

## 9. Closing the class — end-to-end workflow

Once the ~100-protein `data/labels.csv` is ready, this is the recommended order.

### 9.1 Install `mmseqs2` (one-time, external binary)

Not a Python package — must be installed outside uv:

```bash
# Pick one:
conda install -c bioconda mmseqs2      # easiest
brew install mmseqs2                   # macOS
sudo apt install mmseqs2               # debian/ubuntu (sometimes outdated)
# or download a release binary from https://github.com/soedinglab/MMseqs2/releases
```

Verify: `which mmseqs` should print a path. If missing, `splits.py` silently falls back to SHA-1 exact-sequence clustering — **do not report numbers from that path**.

### 9.2 Sanity pass before any real training

```bash
uv run pytest -q                                     # 44 tests green (38 core + 6 aggregate)
uv run pre-commit run --all-files                    # ruff + mypy clean
uv run python scripts/run_cv.py --model constant     # smoke the CV runner end-to-end on real n
```

If `--model constant` completes and produces sensible per-fold sizes in the log, the pipeline is ready.

### 9.3 Run the full baseline ladder

Each command writes its own JSON so they can be aggregated afterwards. Expected wall-clock on CPU at n≈100: constant/linear < 1 min each; SchNet/GAT ~10–30 min each; ESM-2 dominated by the frozen backbone pass ~30–60 min.

```bash
mkdir -p outputs/final

uv run python scripts/run_cv.py --model constant \
    --out-json outputs/final/cv_constant.json

uv run python scripts/run_cv.py --model linear --ridge-alpha 1.0 \
    --out-json outputs/final/cv_linear.json

uv run python scripts/run_cv.py --model schnet \
    --max-epochs 200 --patience 30 \
    --out-json outputs/final/cv_schnet.json

uv run python scripts/run_cv.py --model gat --heads 4 \
    --max-epochs 200 --patience 30 \
    --out-json outputs/final/cv_gat.json

uv run python scripts/run_cv.py --model esm2 --esm-model esm2_t12_35M_UR50D \
    --max-epochs 200 --patience 30 \
    --out-json outputs/final/cv_esm2.json
```

### 9.4 Run the graph-branch ablations (design spec §5 B4)

```bash
uv run python scripts/run_cv.py --model schnet --no-ligand \
    --max-epochs 200 --patience 30 \
    --out-json outputs/final/cv_schnet_protein_only.json

uv run python scripts/run_cv.py --model schnet --no-protein \
    --max-epochs 200 --patience 30 \
    --out-json outputs/final/cv_schnet_ligand_only.json
```

### 9.5 Aggregate + plot

```bash
uv run python scripts/aggregate_results.py outputs/final/*.json \
    --baseline constant \
    --out docs/report/results_summary.md

uv run python scripts/plot_results.py outputs/final/*.json \
    --out docs/report/figures/
```

Commit both artefacts:

```bash
git add docs/report/results_summary.md docs/report/figures/
git commit -m "report: n=100 CV results + paired-bootstrap CIs vs B0"
```

### 9.6 Write the report

- Methods section: already written in `docs/report/scientific-framework.md` — cite or inline.
- Results: `docs/report/results_summary.md` (tables) + `docs/report/figures/*.png` (bar charts).
- Discussion: refer to §11 of `scientific-framework.md` for the honest-expectations framing (beating B0 is meaningful; matching B2 is a meaningful negative result; both are publishable statements).

### 9.7 Known non-code items (data-dependent, not blockers)

1. **Balancing check at 0.7 identity.** If `mmseqs2 easy-cluster --min-seq-id 0.7` puts most FPs in one huge cluster (likely for mCherry-family dense sampling), try `--min-seq-id 0.5` by passing `--identity 0.5` to `run_cv.py`. Document the choice in the report.
2. **Seed robustness.** After §9.5, repeat §9.3 with `--seed 1` and `--seed 2` if time permits and aggregate across all three.
