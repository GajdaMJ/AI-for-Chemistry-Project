# Fluorescence-Property GNN — Scientific Framework

> **Purpose of this document.** A standalone methods report that another ML engineer or reviewer can read without the source code to understand (a) what we built, (b) every meaningful design choice and its justification, (c) what we deliberately did *not* build and why. Intended as the scientific-methods backbone of any write-up of the work.
>
> **Authoritative sources.** Design: `docs/superpowers/specs/2026-04-18-fluorescence-gnn-design.md`. Cleaning addendum: `docs/superpowers/specs/2026-04-19-pdb-cleaning-addendum.md`. Implementation plan: `docs/superpowers/plans/2026-04-19-fluorescence-gnn-implementation.md`. Code: `src/pdb_project/`.

---

## 1. Problem statement

Predict three scalar optical properties of fluorescent proteins (FPs) from their 3D structure:

- **Brightness** (EC × QY / 1000),
- **Emission wavelength** (nm),
- **Quantum yield (QY)** ∈ (0, 1].

Inputs per protein: a PDB file containing the protein + an NRQ chromophore ligand, plus molecular mass (kDa). The working dataset size is n ≈ 100 (two samples currently, ~98 pending). The project is a course/collaboration exercise — **not** an attempt at state-of-the-art.

---

## 2. Inputs, targets, and deliberate exclusions

### 2.1 Inputs used

| Input | Source | Shape / units |
|---|---|---|
| Protein 3D structure (residue COMs + residue types) | `ATOM` records in PDB, chain selected per labels.csv | (Nres, 3) + (Nres,) categorical ×20 |
| NRQ ligand 3D structure (heavy-atom xyz + element) | `HETATM` records with resname `NRQ` | (Natoms, 3) + (Natoms,) categorical ×4 |
| Molecular mass | `kDa` column in labels.csv | scalar |

### 2.2 Targets

Three scalars per protein, predicted jointly by a single head (multi-task):

- `brightness`, `emission`, `qy`.

Loss is `mean_over_targets(MSE(z-scored y, z-scored ŷ))` with standardization fit on the training fold only. Reporting is on the original (unstandardized) scale.

### 2.3 Deliberately excluded inputs (target leakage)

The instructor-provided spec proposed feeding Stokes shift and EC value into the model. We refused both on leakage grounds:

- **Stokes shift** = `Emission − Excitation`. Emission is a target. Including Stokes shift, in combination with any proxy for excitation wavelength, lets the model recover the target by subtraction.
- **EC value**. By definition `Brightness = EC × QY / 1000`. Including EC reduces brightness prediction to guessing QY. We verified the identity numerically on both available labels (mScarlet3: 104000 × 0.75 / 1000 = 78.00 ✓; mCardinal: 87000 × 0.19 / 1000 = 16.53 ✓).
- **Excitation wavelength**. Tightly coupled to emission via the (small) Stokes shift. Excluded to keep the task non-trivial.

The cleanly non-leaky input set is therefore `{protein graph, NRQ graph, kDa}`.

### 2.4 Crystallographic waters (HOH)

Kept in the raw parse but excluded from the graph. Reasoning: resolved waters vary wildly across crystal structures (50–500+) for the same protein, most positions are artifacts of the crystallization condition rather than biology, and at n=100 the resulting noise dominates any chromophore-proximal signal. An optional ablation to include `HOH ≤ 5 Å of any NRQ atom` as a 21st node type is noted in the design backlog but not implemented.

---

## 3. Preprocessing pipeline

Parser: hand-rolled fixed-column PDB reader (not BioPython). Rationale: fewer moving parts, deterministic, auditable. BioPython remains available for sequence-side utilities.

Steps per PDB:

1. Split lines into standard-AA `ATOM`, `NRQ` `HETATM`, `HOH` `HETATM`; ignore other HETATMs.
2. **altLoc filter** — keep only `altLoc ∈ {" ", "A", ""}`. Drops secondary conformations that would otherwise duplicate atoms in COM computation.
3. **Chain filter** — keep only atoms on the chain specified in `labels.csv` (default `"A"`). Prevents multi-chain deposits (dimers/tetramers) from producing protein graphs N× larger than monomeric graphs.
4. **Hydrogen drop** — drop atoms with element `H`. Standard practice for both residue-COM and chemical-graph construction.
5. **Residue COM computation** — mean of heavy-atom xyz within each residue.
6. **Label validation at load time** — rejects rows with `qy ∉ (0, 1]`, `emission ∉ [400, 800]`, `brightness < 0`, or `kDa ∉ [10, 100]`.

Corrupt lines (seen once in `4OQW_mCardinal.pdb`, where a stray `"yes "` token shifts the fixed columns) are logged as a warning and skipped — not silently dropped.

---

## 4. Graph construction

### 4.1 Protein graph `G_P`

- **Nodes:** residues (standard amino acids only; HOH excluded; see §2.4).
- **Node features:** one-hot of the 20-AA alphabet (20-dim).
- **Node position:** residue center-of-mass (heavy atoms only).
- **Edges:** **fully connected**, no self-loops. `E = N × (N − 1)` directed edges.
- **Edge features (raw):** scalar Euclidean distance between residue COMs.
- **Edge features (model-side):** distance is expanded into a 16-dim Gaussian RBF inside the encoder (see §5.1).

**Why fully connected?** At n ≈ 100 and ~225 residues per protein, a fully connected protein graph has ~50k edges — trivial computationally. The alternative (k-NN or distance cutoff) adds a hyperparameter and forces us to pre-commit to a locality assumption. With RBF edge features, the learned filter can freely attenuate far-range interactions.

### 4.2 NRQ ligand graph `G_L`

- **Nodes:** heavy atoms of the NRQ chromophore (typically ~24 per PDB).
- **Node features:** one-hot of element ∈ {C, N, O, S} (4-dim).
- **Node position:** raw atom xyz.
- **Edges:** fully connected, no self-loops (~560 directed edges per ligand).
- **Edge features:** scalar distance, RBF-expanded inside the encoder.

**Why atom-level for the ligand?** The chromophore chemistry (bond topology, π-conjugation path) is the primary determinant of emission wavelength. A residue-level abstraction would discard exactly the information we care about.

---

## 5. Model zoo

All models predict the same 3-scalar vector. Except where noted, they share the same training loop, target standardization, and `FusionHead` (the MLP that merges pooled embeddings with scalar features and produces outputs).

### 5.1 B3a — SchNet-style MPNN (primary model)

Reference: **Schütt, Kindermans, Sauceda, Chmiela, Tkatchenko, Müller. *SchNet: A continuous-filter convolutional neural network for modeling quantum interactions.* NeurIPS 2017.**

Core layer: continuous-filter convolution (cfconv).

```
m_ij = h_j ⊙ W_edge(RBF(d_ij))                  # distance-aware message
h'_i = h_i + W_out(SiLU(mean_j m_ij))            # residual update
```

where `RBF(d)` is a vector of K=16 Gaussian bumps centered on `[0, 20] Å` (protein) or `[0, 10] Å` (ligand), `W_edge` and `W_out` are small MLPs, and aggregation is mean-pool over neighbors.

End-to-end architecture (default hyperparameters in brackets; all exposed via Hydra):

```
protein graph G_P
  → Linear(20 → H=64)                     # embed one-hot AA
  → L=3 × cfconv(hidden=64, K=16)         # protein encoder
  → global_mean_pool                      # (B, 64) per-graph
  → h_prot

NRQ graph G_L
  → Linear(4 → 64)                        # embed element one-hot
  → 3 × cfconv(hidden=64, K=16)           # ligand encoder
  → global_mean_pool
  → h_lig

kDa (1-dim, standardized)

concat [h_prot, h_lig, kDa]  → (B, 129)
  → FusionHead:                           # shared head
      Dropout(0.2)
      Linear(129 → 64) → SiLU
      Dropout(0.2)
      Linear(64 → 32)  → SiLU
      Linear(32 → 3)
  → (B, 3) standardized outputs [brightness, emission, qy]
```

Parameters: ~60k for `hidden=64, num_layers=3`. Small by design — at n=100 we cannot afford million-parameter models.

Ablation switches (`model.use_protein=false` / `model.use_ligand=false`) allow single-branch variants without code duplication.

### 5.2 B3b — GATv2 variant

Reference: **Brody, Alon, Yahav. *How Attentive are Graph Attention Networks?* ICLR 2022.** (The GATv2 correction to the original Veličković et al. 2018 GAT.)

Same data pipeline, same RBF-expanded edge features, same `FusionHead`, same pooling. Only the graph-layer mechanism differs: `GATv2Conv` with `edge_dim=K` replaces cfconv. Default: 4 heads on internal layers, 1 head on the final layer, `add_self_loops=False` because edge features only have meaning on true edges.

**Why this pairing?** Holding everything else fixed, B3b isolates the choice between "distance-aware continuous filter" (SchNet) and "learned attention over the same edge features" (GAT). If GAT wins, the interesting content of the edges is relational rather than geometric; if SchNet wins, the explicit distance prior carries weight. Either way, the result is interpretable.

### 5.3 B2 — ESM-2 (frozen) + MLP

Reference: **Lin, Akin, Rao, Hie, Zhu, Lu, Smetanin, Verkuil, Kabeli, Shmueli, dos Santos Costa, Fazel-Zarandi, Sercu, Candido, Rives. *Evolutionary-scale prediction of atomic-level protein structure.* Science 2023.**

Pretrained ESM-2 (variant `esm2_t12_35M_UR50D` by default; `esm2_t6_8M_UR50D` in tests) produces a per-residue embedding vector from the sequence alone. We mean-pool across residues, concatenate with `kDa`, and feed into the same `FusionHead`. **The backbone is frozen** — no fine-tuning — for two reasons:

1. **Honesty.** The question this baseline answers is "how far does a pretrained sequence model get us?", not "can we tune a giant model on 100 proteins?" (We cannot.)
2. **Compute.** Full fine-tuning of even the 35M-parameter variant at n=100 overfits immediately.

B2 is the baseline the structural model most needs to beat: if a pooled sequence embedding + tiny MLP matches the GNN's test error, the 3D structure is not carrying additional signal at this data scale — a meaningful negative result.

### 5.4 B1 — Ridge regression on hand-crafted features

41-dimensional feature vector:

- `kDa` (1).
- AA composition: fraction of each of the 20 residue types across the whole protein (20).
- NRQ contact composition: same distribution but computed only over residues whose COM lies within 6 Å of any NRQ heavy atom (20); all-zero if no contacts.

Fit with `sklearn.linear_model.Ridge(alpha=1.0)`. Tells us how much of the task is "bag of residues + contact shell composition" — i.e., how much needs geometry at all.

### 5.5 B0 — Constant predictor

Predicts the training-set mean for each target. Numerical floor: any model not beating B0 has not learned anything. In the literature this is the "null model" baseline; we include it so that standard-error bars across folds are interpretable (B0 has zero variance across a fixed test fold).

### 5.6 Baseline ladder summary

| ID | Model | Isolates |
|---|---|---|
| B0 | Constant | Trivial floor. |
| B1 | Ridge on 41-dim composition features | How much is "which residues are in the protein and near the chromophore"? |
| B2 | ESM-2 (frozen) + MLP | How much does pretraining-era sequence information give us? |
| B3a | SchNet MPNN (primary) | Geometry + continuous-filter MPNN over two graphs. |
| B3b | GATv2 variant | Attention substituted for continuous-filter convolution. |
| B4 (ablations) | B3a with `use_protein=false` / `use_ligand=false` | Which graph carries the signal? |

---

## 6. Training protocol

- **Loss.** Mean of 3 MSEs on z-scored targets. Equal target weighting — no per-target λ tuning.
- **Optimizer.** AdamW, `lr=1e-3`, `weight_decay=1e-4`.
- **Scheduler.** Cosine anneal (warmup 5 epochs). Simple, one-cycle.
- **Batch size.** 8 (small relative to dataset, but dual-graph batches are nontrivial to construct).
- **Max epochs.** 200.
- **Early stopping.** Patience 30 epochs on validation `mae/overall`. If the validation fold is empty (n=2 plumbing case), we run all `max_epochs` without early stopping and emit a warning.
- **Gradient clip.** `max_norm=1.0` — a cheap regularizer at small data scales.
- **Seed.** All sources of randomness (Python, NumPy, PyTorch, CUDA, fold assignment) seeded from a Hydra config value.

---

## 7. Validation protocol

**5-fold cross-validation over sequence-identity clusters.**

1. Compute sequence-identity clusters with `mmseqs2 easy-cluster --min-seq-id 0.7 -c 0.8 --cov-mode 0`. If `mmseqs2` is not installed, fall back to exact-sequence clustering via SHA-1 (dev-only; forbidden for the reporting run).
2. Assign whole clusters to folds greedy Longest-Processing-Time-first, balancing fold size. Deterministic given (clusters, k, seed).
3. For fold k:
   - **Train:** folds ≠ k, minus a ~10% cluster-level val holdout used for early stopping.
   - **Val:** the held-out training clusters.
   - **Test:** fold k.
   - Fit target + kDa standardizers on train only.
4. Report per-fold MAE and R² per target, plus cluster-normalized overall MAE. Final numbers = mean ± std across folds.

**Why cluster-aware splits?** FPs are a dense mutant family (mScarlet3 is a descendant of mCherry; mCardinal is a descendant of mRFP). A random protein-level split is guaranteed to leak: a mutant one residue away from a held-out protein will be in the training set. 70% identity at 80% coverage is the clustering threshold commonly used in protein ML for "different proteins, not trivial mutants."

---

## 8. Architectural alternatives considered and rejected

| Alternative | Rejected because |
|---|---|
| **Equivariant GNNs (EGNN, SE(3)-Transformer).** References: Satorras et al. ICML 2021; Fuchs et al. NeurIPS 2020. | Our edge features are interatomic distances — already SE(3)-invariant by construction. Our targets are scalars — trivially equivariant. EGNN buys us less than it looks, at real implementation and debugging cost. Kept as a "future work" discussion point. |
| **k-NN or distance-cutoff protein graph (k=10, or 8 Å).** | Introduces a graph-sparsity hyperparameter we cannot tune responsibly at n=100. Fully connected lets the learned RBF filter attenuate long-range interactions implicitly. Optional ablation. |
| **Sum pooling.** | Dominated by the larger graph (protein ~225 nodes vs. ligand ~24): sum-pooled `h_prot` is ~10× the magnitude of `h_lig`, so the fusion MLP would see the ligand as noise. Mean pool equalizes the two streams. |
| **Attention pooling / Set2Set / SortPool.** | Adds parameters and initialization sensitivity. Not affordable at n=100. |
| **ESM-2 fine-tuning / ProstT5 / SaProt.** | Valid next steps if B2 is competitive but the project does not have the data (or the scope) to do them responsibly. Noted as follow-up. |
| **Multi-head (per-target) MLP.** | Multi-task with shared trunk is the regularization-friendlier choice at small n — auxiliary targets inject signal into shared parameters. Independent heads are an ablation in the design backlog. |
| **One-hot residue embedding replaced by learned embedding from a language model.** | Pursued only at the baseline level (B2); using LM embeddings in the GNN would muddle the comparison between B2 and B3a. |

---

## 9. Preprocessing alternatives considered and rejected

From the PDB-cleaning review (`2026-04-19-pdb-cleaning-addendum.md` §3):

| Step | Rejected because |
|---|---|
| Occupancy-based atom filtering | Partial-occupancy atoms are rare, and their noise is well below the label noise floor. Would add a threshold hyperparameter. |
| B-factor outlier trimming | High-B atoms are concentrated in flexible loops, which contribute little to chromophore environment. |
| Clash / geometry sanity checks | Re-doing crystallographer QC. Not our job. |
| Missing-residue reconstruction (MODELLER / AlphaFold patching) | FP β-barrels are well-resolved near the chromophore. Residue-COM graphs are robust to short gaps. |
| Label-outlier removal | At n=100, outliers may be the most informative proteins; trimming would bias the model toward the FPBase mode. |
| Brightness ↔ EC × QY consistency cross-check | Requires loading the EC column we deliberately excluded as input. Useful as a standalone audit script, not as part of the training pipeline. |

---

## 10. Metrics and reporting

Per target (unstandardized scale):

- **MAE** — primary, interpretable in the original units (nm, brightness-units, QY).
- **R²** — secondary, scale-free; useful across targets even if they have different magnitudes.

Overall:

- **Cluster-normalized MAE** — mean of per-target standardized MAEs. Used for model selection (early stopping, hyperparameter comparisons). Avoids the "emission in hundreds of nm dominates QY in 0–1" issue.

**Statistical comparison.** Paired-bootstrap CIs on fold-level MAE differences vs. B0 (design backlog; not yet implemented). A model that does not clear B0's 95% CI is considered not to have learned.

---

## 11. Risks and honest expectations

- **n = 100 is small.** The most likely outcome is that B3a ties or loses to B2 (ESM-2 MLP). This is itself a valid scientific finding worth reporting.
- **Label noise.** FPBase-like sources aggregate optical measurements from different conditions. Expect a floor of a few nm on emission and ~10% relative on brightness.
- **Chromophore non-uniqueness.** The pipeline assumes NRQ is the ligand. If any of the ~100 PDBs uses a different chromophore (CRO, CRQ, CH6, etc.), the data loader will fail with a clear error — intentional.
- **Sequence-vs-structure mismatch.** The `sequence` column in `labels.csv` is assumed to match the PDB's resolved region. Short unresolved termini are fine (ESM-2 uses the full-length CSV sequence; the graph uses only resolved residues).

---

## 12. Reproducibility

- Environment: `uv sync --all-extras`, Python 3.11, dependencies pinned in `pyproject.toml` + `uv.lock`.
- Seeded: Python, NumPy, PyTorch, CUDA, fold assignment — all from a single Hydra `seed` field.
- Hydra config fully serialized with every run; resolved config logged on startup.
- Commit hashes in git identify every incremental state: see `git log --oneline`.
- Tests (`uv run pytest`) are the smallest executable description of every component's contract.

---

## 13. References (full)

- Schütt, K., Kindermans, P.-J., Sauceda, H., Chmiela, S., Tkatchenko, A., Müller, K.-R. *SchNet: A continuous-filter convolutional neural network for modeling quantum interactions.* NeurIPS 2017.
- Brody, S., Alon, U., Yahav, E. *How Attentive are Graph Attention Networks?* ICLR 2022. (GATv2.)
- Veličković, P., Cucurull, G., Casanova, A., Romero, A., Liò, P., Bengio, Y. *Graph Attention Networks.* ICLR 2018. (Original GAT.)
- Gilmer, J., Schoenholz, S., Riley, P., Vinyals, O., Dahl, G. *Neural Message Passing for Quantum Chemistry.* ICML 2017. (MPNN framework background.)
- Satorras, V., Hoogeboom, E., Welling, M. *E(n) Equivariant Graph Neural Networks.* ICML 2021. (EGNN — rejected, see §8.)
- Lin, Z. et al. *Evolutionary-scale prediction of atomic-level protein structure (ESM-2).* Science, 2023.
- Steinegger, M., Söding, J. *MMseqs2 enables sensitive protein sequence searching for the analysis of massive data sets.* Nature Biotechnology, 2017. (Used for sequence-identity clustering.)
