# Fluorescence-Property GNN Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build an end-to-end pipeline that predicts (Brightness, Emission wavelength, QY) for fluorescent proteins from their PDB structure + kDa, with a SchNet-style GNN as primary model and a ladder of baselines (constant, linear, GAT, ESM-2 MLP).

**Architecture:** Two separate graph encoders — a residue-level protein graph and an atom-level NRQ ligand graph — are processed by SchNet-style continuous-filter convolutions (cfconv) with RBF-expanded edge distances, then mean-pooled, concatenated with standardized kDa, and fed into an MLP head that outputs three standardized scalar targets. Training uses 5-fold cross-validation over sequence-identity clusters (70% identity, mmseqs2) with per-fold early stopping and per-target MAE/R² reporting.

**Tech Stack:** Python 3.11, uv, PyTorch, PyTorch Geometric (`torch_geometric`), BioPython, Hydra, ruff, mypy, pytest, pre-commit, TensorBoard. ESM-2 via `fair-esm`. Sequence clustering via `mmseqs2` (external binary).

**Governing spec:** `docs/superpowers/specs/2026-04-18-fluorescence-gnn-design.md`. When in doubt, defer to the spec.

**Working directory convention:** all paths below are relative to `/home/l-braz/Documents/git/pdb_project/`.

**Git note:** the project is not currently a git repo. Task 1 initializes it so the frequent-commit discipline applies. If the user has forbidden git, the `git` steps can be replaced by taking `git status` / `git diff` snapshots into `docs/superpowers/checkpoints/` instead — but the default is: initialize git.

---

## File structure (what we are building toward)

```
pdb_project/
├── pyproject.toml                       # uv-managed
├── .pre-commit-config.yaml
├── .gitignore
├── README.md
├── conf/
│   ├── config.yaml                      # Hydra root
│   ├── data/default.yaml
│   ├── model/
│   │   ├── constant.yaml
│   │   ├── linear.yaml
│   │   ├── schnet.yaml
│   │   ├── gat.yaml
│   │   └── esm2.yaml
│   ├── training/default.yaml
│   └── validation/cv5.yaml
├── src/pdb_project/
│   ├── __init__.py
│   ├── data/
│   │   ├── __init__.py
│   │   ├── pdb_parser.py                # raw PDB → records
│   │   ├── graph_builder.py             # records → PyG Data
│   │   ├── labels.py                    # labels.csv loader
│   │   └── dataset.py                   # PyG Dataset
│   ├── models/
│   │   ├── __init__.py
│   │   ├── rbf.py                       # Gaussian RBF expansion
│   │   ├── schnet.py                    # cfconv layer + encoder + full model
│   │   ├── gat.py                       # GATv2-based encoder + full model
│   │   ├── esm2_mlp.py                  # ESM-2 + MLP head
│   │   ├── linear.py                    # hand-crafted features + linear reg
│   │   ├── constant.py                  # train-mean predictor
│   │   └── head.py                      # shared MLP head + kDa fusion
│   ├── training/
│   │   ├── __init__.py
│   │   ├── standardize.py               # train-fold standardization
│   │   ├── metrics.py                   # MAE, R², bootstrap CI
│   │   ├── splits.py                    # mmseqs2 clusters → 5 folds
│   │   └── loop.py                      # train/val/test loop
│   └── cli.py                           # Hydra entry point
├── scripts/
│   ├── run_cv.py                        # 5-fold CV runner
│   └── plumbing_test.py                 # 1-protein-train / 1-test sanity
├── tests/
│   ├── conftest.py
│   ├── test_pdb_parser.py
│   ├── test_graph_builder.py
│   ├── test_labels.py
│   ├── test_dataset.py
│   ├── test_rbf.py
│   ├── test_head.py
│   ├── test_constant_model.py
│   ├── test_linear_model.py
│   ├── test_schnet.py
│   ├── test_gat.py
│   ├── test_metrics.py
│   ├── test_standardize.py
│   ├── test_splits.py
│   └── test_loop.py
└── data/
    ├── raw/                              # PDB files (existing)
    └── labels.csv                        # protein-level labels (to be created)
```

Files that change together live together (e.g., `schnet.py` holds the cfconv layer, encoder, and full model because they are only ever used together). `head.py` is shared across SchNet / GAT / ESM-2 / Linear because the fusion + MLP is identical in all of them.

---

## Task 1: Project scaffolding (uv, pyproject.toml, pre-commit, git init)

**Files:**
- Create: `pyproject.toml`, `.pre-commit-config.yaml`, `.gitignore`, `README.md`
- Create: `src/pdb_project/__init__.py`, `tests/__init__.py`, `tests/conftest.py`

- [ ] **Step 1: Initialize git**

```bash
cd /home/l-braz/Documents/git/pdb_project
git init -b main
```

Expected: `Initialized empty Git repository in ...`.

- [ ] **Step 2: Create `.gitignore`**

```
# Python
__pycache__/
*.pyc
*.pyo
.venv/
.uv/
.pytest_cache/
.mypy_cache/
.ruff_cache/

# Project
outputs/          # Hydra default output dir
multirun/         # Hydra multirun
runs/             # TensorBoard logs
wandb/
checkpoints/
data/processed/
data/cache/

# IDE
.idea/
.vscode/

# OS
.DS_Store
```

- [ ] **Step 3: Create `pyproject.toml`**

```toml
[project]
name = "pdb-project"
version = "0.1.0"
description = "GNN for fluorescent-protein property prediction from 3D structure"
requires-python = ">=3.11,<3.13"
dependencies = [
  "torch>=2.2,<3",
  "torch-geometric>=2.5,<3",
  "biopython>=1.83",
  "numpy>=1.26",
  "pandas>=2.2",
  "scipy>=1.12",
  "scikit-learn>=1.4",
  "hydra-core>=1.3",
  "omegaconf>=2.3",
  "tensorboard>=2.16",
  "tqdm>=4.66",
  "fair-esm>=2.0.0",
]

[project.optional-dependencies]
dev = [
  "pytest>=8",
  "pytest-cov>=5",
  "ruff>=0.4",
  "mypy>=1.10",
  "pre-commit>=3.7",
]

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["src/pdb_project"]

[tool.ruff]
line-length = 100
target-version = "py311"

[tool.ruff.lint]
select = ["E", "F", "I", "B", "UP", "N", "SIM", "RUF"]
ignore = ["E501"]  # line length handled by formatter

[tool.mypy]
python_version = "3.11"
strict = true
ignore_missing_imports = true
files = ["src/pdb_project"]

[tool.pytest.ini_options]
testpaths = ["tests"]
addopts = "-ra -q"
```

- [ ] **Step 4: Create `.pre-commit-config.yaml`**

```yaml
repos:
  - repo: https://github.com/astral-sh/ruff-pre-commit
    rev: v0.4.10
    hooks:
      - id: ruff
        args: [--fix]
      - id: ruff-format
  - repo: https://github.com/pre-commit/mirrors-mypy
    rev: v1.10.0
    hooks:
      - id: mypy
        additional_dependencies:
          - torch
          - numpy
          - pandas
        args: [--strict, --ignore-missing-imports]
        pass_filenames: false
        files: ^src/pdb_project/
```

- [ ] **Step 5: Create `README.md` (minimal)**

```markdown
# PDB Project — Fluorescence Property GNN

Predicts (Brightness, Emission wavelength, QY) for fluorescent proteins from 3D structure using a SchNet-style GNN.

See `docs/superpowers/specs/2026-04-18-fluorescence-gnn-design.md` for the full design.

## Quickstart

```bash
uv sync --all-extras
uv run pre-commit install
uv run pytest
```

## Layout

- `src/pdb_project/` — library code
- `conf/` — Hydra configuration
- `scripts/` — CV runner and plumbing test
- `tests/` — pytest suite
- `data/raw/` — input PDB files
```

- [ ] **Step 6: Create package skeleton**

```bash
mkdir -p src/pdb_project/{data,models,training}
mkdir -p tests conf/{data,model,training,validation}
mkdir -p scripts data/raw
touch src/pdb_project/__init__.py
touch src/pdb_project/data/__init__.py
touch src/pdb_project/models/__init__.py
touch src/pdb_project/training/__init__.py
touch tests/__init__.py
# Move existing PDB files into data/raw
mv 4OQW_mCardinal.pdb 7ZCT_mScarlet3.pdb data/raw/ 2>/dev/null || true
```

- [ ] **Step 7: Create `tests/conftest.py`**

```python
"""Shared pytest fixtures."""
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent


@pytest.fixture(scope="session")
def repo_root() -> Path:
    return REPO_ROOT


@pytest.fixture(scope="session")
def raw_pdb_dir(repo_root: Path) -> Path:
    return repo_root / "data" / "raw"


@pytest.fixture(scope="session")
def mscarlet3_pdb(raw_pdb_dir: Path) -> Path:
    path = raw_pdb_dir / "7ZCT_mScarlet3.pdb"
    assert path.exists(), f"Missing test PDB: {path}"
    return path


@pytest.fixture(scope="session")
def mcardinal_pdb(raw_pdb_dir: Path) -> Path:
    path = raw_pdb_dir / "4OQW_mCardinal.pdb"
    assert path.exists(), f"Missing test PDB: {path}"
    return path
```

- [ ] **Step 8: Install environment + pre-commit hook**

```bash
uv sync --all-extras
uv run pre-commit install
```

Expected: `uv sync` resolves and installs; `pre-commit installed at .git/hooks/pre-commit`.

- [ ] **Step 9: Smoke-test test infrastructure**

```bash
uv run pytest -q
```

Expected: `no tests ran in ...` (no tests yet — we just want pytest to start cleanly).

- [ ] **Step 10: Commit**

```bash
git add -A
git commit -m "chore: scaffold uv/pyproject/pre-commit with package skeleton"
```

---

## Task 2: PDB parser

**Files:**
- Create: `src/pdb_project/data/pdb_parser.py`
- Create: `tests/test_pdb_parser.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/test_pdb_parser.py
from pathlib import Path

import numpy as np

from pdb_project.data.pdb_parser import PDBRecords, parse_pdb


def test_parse_mscarlet3(mscarlet3_pdb: Path) -> None:
    records: PDBRecords = parse_pdb(mscarlet3_pdb)

    # Standard-AA residues: non-empty, in order
    assert len(records.residues) > 100
    first = records.residues[0]
    assert first.resname == "ALA"
    assert first.resseq == 7
    assert len(first.atoms) >= 5  # heavy atoms at least
    # Each atom has element + xyz
    assert first.atoms[0].element in {"N", "C", "O", "S", "H"}
    xyz = first.atoms[0].xyz
    assert xyz.shape == (3,)
    assert xyz.dtype == np.float32

    # NRQ ligand present
    assert records.ligand is not None
    assert records.ligand.resname == "NRQ"
    assert len(records.ligand.atoms) >= 20

    # Waters present (we keep them; dropping happens in graph builder)
    assert len(records.waters) >= 0


def test_parse_mcardinal_has_ligand(mcardinal_pdb: Path) -> None:
    records = parse_pdb(mcardinal_pdb)
    assert records.ligand is not None
    assert records.ligand.resname == "NRQ"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_pdb_parser.py -v`
Expected: `ModuleNotFoundError: No module named 'pdb_project.data.pdb_parser'`.

- [ ] **Step 3: Implement parser**

```python
# src/pdb_project/data/pdb_parser.py
"""Minimal PDB parser.

Reads ATOM / HETATM lines using fixed-column PDB format, not BioPython,
so we can run on bare dependencies and stay deterministic. BioPython is
listed as a dependency for downstream use (ESM / sequence extraction)
but parsing is hand-rolled here for speed + auditability.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

STANDARD_AA = {
    "ALA", "ARG", "ASN", "ASP", "CYS",
    "GLN", "GLU", "GLY", "HIS", "ILE",
    "LEU", "LYS", "MET", "PHE", "PRO",
    "SER", "THR", "TRP", "TYR", "VAL",
}


@dataclass(frozen=True)
class Atom:
    name: str
    element: str
    xyz: np.ndarray  # shape (3,), float32


@dataclass
class Residue:
    resname: str
    chain: str
    resseq: int
    atoms: list[Atom] = field(default_factory=list)


@dataclass
class PDBRecords:
    residues: list[Residue]          # standard amino acids only
    ligand: Residue | None           # the NRQ residue, or None if absent
    waters: list[Residue]            # HOH residues


def _parse_line(line: str) -> tuple[str, str, str, int, str, np.ndarray, str]:
    """Return (record, atom_name, resname, resseq, chain, xyz, element)."""
    record = line[0:6].strip()
    atom_name = line[12:16].strip()
    resname = line[17:20].strip()
    chain = line[21:22].strip()
    resseq = int(line[22:26])
    x = float(line[30:38])
    y = float(line[38:46])
    z = float(line[46:54])
    element = line[76:78].strip()
    return record, atom_name, resname, resseq, chain, np.array([x, y, z], dtype=np.float32), element


def parse_pdb(path: str | Path) -> PDBRecords:
    residues: list[Residue] = []
    ligand: Residue | None = None
    waters: list[Residue] = []
    current: Residue | None = None
    current_key: tuple[str, int, str] | None = None

    for raw_line in Path(path).read_text().splitlines():
        if not (raw_line.startswith("ATOM") or raw_line.startswith("HETATM")):
            continue
        record, atom_name, resname, resseq, chain, xyz, element = _parse_line(raw_line)
        atom = Atom(name=atom_name, element=element, xyz=xyz)

        key = (resname, resseq, chain)

        if resname in STANDARD_AA and record == "ATOM":
            if key != current_key:
                current = Residue(resname=resname, chain=chain, resseq=resseq)
                residues.append(current)
                current_key = key
            assert current is not None
            current.atoms.append(atom)
        elif resname == "NRQ":
            if ligand is None:
                ligand = Residue(resname="NRQ", chain=chain, resseq=resseq)
            ligand.atoms.append(atom)
        elif resname == "HOH":
            if not waters or (waters[-1].resname, waters[-1].resseq, waters[-1].chain) != key:
                waters.append(Residue(resname="HOH", chain=chain, resseq=resseq))
            waters[-1].atoms.append(atom)
        # Ignore other HETATMs (ions, etc.) — they are not used anywhere.

    return PDBRecords(residues=residues, ligand=ligand, waters=waters)
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_pdb_parser.py -v`
Expected: both tests PASS.

- [ ] **Step 5: Commit**

```bash
git add src/pdb_project/data/pdb_parser.py tests/test_pdb_parser.py
git commit -m "feat(data): hand-rolled PDB parser for ATOM/HETATM with NRQ + HOH extraction"
```

---

## Task 3: RBF expansion module

**Files:**
- Create: `src/pdb_project/models/rbf.py`
- Create: `tests/test_rbf.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/test_rbf.py
import torch

from pdb_project.models.rbf import GaussianRBF


def test_rbf_shape() -> None:
    rbf = GaussianRBF(num_centers=16, low=0.0, high=20.0)
    d = torch.tensor([0.0, 5.0, 10.0, 20.0])
    out = rbf(d)
    assert out.shape == (4, 16)


def test_rbf_peaks_at_center() -> None:
    rbf = GaussianRBF(num_centers=5, low=0.0, high=4.0)
    # centers at 0, 1, 2, 3, 4
    d = torch.tensor([2.0])
    out = rbf(d).squeeze(0)
    assert out.argmax().item() == 2  # center #2 is at distance 2.0


def test_rbf_monotone_decreasing_away_from_center() -> None:
    rbf = GaussianRBF(num_centers=3, low=0.0, high=2.0)
    # centers at 0, 1, 2
    d = torch.tensor([1.0, 1.5, 2.0])
    # Center #0 (at 0.0) should be monotonically decreasing as d grows
    out = rbf(d)
    assert out[0, 0] > out[1, 0] > out[2, 0]
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_rbf.py -v`
Expected: `ModuleNotFoundError`.

- [ ] **Step 3: Implement module**

```python
# src/pdb_project/models/rbf.py
"""Gaussian RBF distance expansion (SchNet-style).

Given a distance d (shape [...]) returns a feature vector of shape
[..., num_centers] where feature k = exp(-gamma * (d - mu_k)^2).
"""
from __future__ import annotations

import torch
from torch import nn


class GaussianRBF(nn.Module):
    def __init__(self, num_centers: int = 16, low: float = 0.0, high: float = 20.0) -> None:
        super().__init__()
        centers = torch.linspace(low, high, num_centers)
        width = (high - low) / max(num_centers - 1, 1)
        # gamma chosen so adjacent RBFs have ~0.5 overlap at their midpoint
        gamma = 1.0 / (2.0 * width ** 2)
        self.register_buffer("centers", centers)
        self.register_buffer("gamma", torch.tensor(gamma))

    def forward(self, distances: torch.Tensor) -> torch.Tensor:
        # distances: [...], centers: [K] → output: [..., K]
        diff = distances.unsqueeze(-1) - self.centers
        return torch.exp(-self.gamma * diff * diff)
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_rbf.py -v`
Expected: 3 PASS.

- [ ] **Step 5: Commit**

```bash
git add src/pdb_project/models/rbf.py tests/test_rbf.py
git commit -m "feat(models): Gaussian RBF distance expansion"
```

---

## Task 4: Graph builder (protein residue COM graph + NRQ atom graph)

**Files:**
- Create: `src/pdb_project/data/graph_builder.py`
- Create: `tests/test_graph_builder.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/test_graph_builder.py
from pathlib import Path

import torch

from pdb_project.data.graph_builder import build_graphs
from pdb_project.data.pdb_parser import parse_pdb


def test_protein_graph_fully_connected(mscarlet3_pdb: Path) -> None:
    records = parse_pdb(mscarlet3_pdb)
    protein_g, ligand_g = build_graphs(records, drop_hydrogens=True)

    n = protein_g.x.size(0)
    # Fully connected without self-loops: n * (n - 1) directed edges
    assert protein_g.edge_index.size(1) == n * (n - 1)
    # Node features = one-hot of AA type, 20-dim
    assert protein_g.x.shape == (n, 20)
    # Edge attr = scalar distances (RBF expansion happens in the model)
    assert protein_g.edge_attr.shape == (n * (n - 1), 1)
    # All distances positive
    assert (protein_g.edge_attr > 0).all()


def test_ligand_graph_heavy_atoms_only(mscarlet3_pdb: Path) -> None:
    records = parse_pdb(mscarlet3_pdb)
    _, ligand_g = build_graphs(records, drop_hydrogens=True)

    assert ligand_g.x.dtype == torch.float32
    # Element one-hot over {C, N, O, S} → 4-dim
    assert ligand_g.x.shape[1] == 4
    # At least the canonical NRQ heavy-atom count (~24)
    assert ligand_g.x.shape[0] >= 20
    # No hydrogens
    # (we don't store element in graph, but row counts vs. raw records must differ)
    heavy = [a for a in records.ligand.atoms if a.element != "H"]  # type: ignore[union-attr]
    assert ligand_g.x.shape[0] == len(heavy)


def test_protein_com_distance_sanity(mscarlet3_pdb: Path) -> None:
    records = parse_pdb(mscarlet3_pdb)
    protein_g, _ = build_graphs(records, drop_hydrogens=True)
    # Min/max distance in a ~225-residue protein: min >= ~3 Å, max <= ~80 Å
    d = protein_g.edge_attr.squeeze(-1)
    assert d.min() >= 2.0
    assert d.max() <= 100.0
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_graph_builder.py -v`
Expected: `ModuleNotFoundError`.

- [ ] **Step 3: Implement graph builder**

```python
# src/pdb_project/data/graph_builder.py
"""Build protein (residue-COM) and NRQ (heavy-atom) graphs.

Both graphs are fully connected with no self-loops. Edge attribute
is the raw scalar Euclidean distance; RBF expansion is done inside
the model so it can be tuned per-graph.
"""
from __future__ import annotations

import numpy as np
import torch
from torch_geometric.data import Data

from .pdb_parser import STANDARD_AA, PDBRecords, Residue

AA_ORDER = sorted(STANDARD_AA)
AA_TO_IDX = {aa: i for i, aa in enumerate(AA_ORDER)}
LIGAND_ELEMENTS = ("C", "N", "O", "S")
LIGAND_ELEM_TO_IDX = {e: i for i, e in enumerate(LIGAND_ELEMENTS)}


def _residue_com(res: Residue, drop_hydrogens: bool) -> np.ndarray:
    atoms = [a for a in res.atoms if not (drop_hydrogens and a.element == "H")]
    if not atoms:  # fallback: include H if somehow no heavy atoms
        atoms = res.atoms
    xyz = np.stack([a.xyz for a in atoms], axis=0)
    return xyz.mean(axis=0)


def _fully_connected_edges(n: int) -> torch.Tensor:
    if n < 2:
        return torch.empty((2, 0), dtype=torch.long)
    src, dst = torch.meshgrid(torch.arange(n), torch.arange(n), indexing="ij")
    mask = src != dst
    return torch.stack([src[mask], dst[mask]], dim=0)


def _pairwise_dist(coords: torch.Tensor, edge_index: torch.Tensor) -> torch.Tensor:
    d = coords[edge_index[0]] - coords[edge_index[1]]
    return d.norm(dim=-1, keepdim=True)


def build_protein_graph(records: PDBRecords, drop_hydrogens: bool = True) -> Data:
    residues = records.residues
    n = len(residues)
    x = torch.zeros((n, 20), dtype=torch.float32)
    coms = np.zeros((n, 3), dtype=np.float32)
    for i, res in enumerate(residues):
        x[i, AA_TO_IDX[res.resname]] = 1.0
        coms[i] = _residue_com(res, drop_hydrogens)
    pos = torch.from_numpy(coms)
    edge_index = _fully_connected_edges(n)
    edge_attr = _pairwise_dist(pos, edge_index)
    return Data(x=x, edge_index=edge_index, edge_attr=edge_attr, pos=pos)


def build_ligand_graph(records: PDBRecords, drop_hydrogens: bool = True) -> Data:
    if records.ligand is None:
        raise ValueError("PDB has no NRQ ligand; cannot build ligand graph.")
    atoms = records.ligand.atoms
    if drop_hydrogens:
        atoms = [a for a in atoms if a.element != "H"]
    n = len(atoms)
    x = torch.zeros((n, len(LIGAND_ELEMENTS)), dtype=torch.float32)
    xyz = np.zeros((n, 3), dtype=np.float32)
    for i, a in enumerate(atoms):
        if a.element not in LIGAND_ELEM_TO_IDX:
            raise ValueError(f"Unexpected NRQ element: {a.element!r}")
        x[i, LIGAND_ELEM_TO_IDX[a.element]] = 1.0
        xyz[i] = a.xyz
    pos = torch.from_numpy(xyz)
    edge_index = _fully_connected_edges(n)
    edge_attr = _pairwise_dist(pos, edge_index)
    return Data(x=x, edge_index=edge_index, edge_attr=edge_attr, pos=pos)


def build_graphs(records: PDBRecords, drop_hydrogens: bool = True) -> tuple[Data, Data]:
    return (
        build_protein_graph(records, drop_hydrogens=drop_hydrogens),
        build_ligand_graph(records, drop_hydrogens=drop_hydrogens),
    )
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_graph_builder.py -v`
Expected: 3 PASS.

- [ ] **Step 5: Commit**

```bash
git add src/pdb_project/data/graph_builder.py tests/test_graph_builder.py
git commit -m "feat(data): residue-COM protein graph + heavy-atom NRQ graph, fully connected"
```

---

## Task 5: Labels CSV loader

**Files:**
- Create: `data/labels.csv`
- Create: `src/pdb_project/data/labels.py`
- Create: `tests/test_labels.py`

- [ ] **Step 1: Create seed labels file**

```bash
cat > data/labels.csv <<'EOF'
pdb_code,protein_name,pdb_path,kDa,brightness,emission,qy
7ZCT,mScarlet3,data/raw/7ZCT_mScarlet3.pdb,25.85,78.00,592,0.75
4OQW,mCardinal,data/raw/4OQW_mCardinal.pdb,27.55,16.53,659,0.19
EOF
```

- [ ] **Step 2: Write the failing test**

```python
# tests/test_labels.py
from pathlib import Path

from pdb_project.data.labels import LabelRow, load_labels


def test_load_labels(repo_root: Path) -> None:
    rows = load_labels(repo_root / "data" / "labels.csv", repo_root=repo_root)
    assert len(rows) == 2
    first: LabelRow = rows[0]
    assert first.pdb_code == "7ZCT"
    assert first.protein_name == "mScarlet3"
    assert first.pdb_path.name == "7ZCT_mScarlet3.pdb"
    assert first.pdb_path.exists()
    assert first.kDa == 25.85
    assert first.targets["brightness"] == 78.00
    assert first.targets["emission"] == 592.0
    assert first.targets["qy"] == 0.75
```

- [ ] **Step 3: Run test to verify it fails**

Run: `uv run pytest tests/test_labels.py -v`
Expected: `ModuleNotFoundError`.

- [ ] **Step 4: Implement loader**

```python
# src/pdb_project/data/labels.py
"""Load the protein-level labels CSV and resolve PDB file paths."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import pandas as pd

TARGET_COLUMNS = ("brightness", "emission", "qy")


@dataclass(frozen=True)
class LabelRow:
    pdb_code: str
    protein_name: str
    pdb_path: Path
    kDa: float
    targets: dict[str, float]  # keys: brightness, emission, qy


def load_labels(csv_path: str | Path, repo_root: str | Path) -> list[LabelRow]:
    df = pd.read_csv(csv_path)
    required = {"pdb_code", "protein_name", "pdb_path", "kDa", *TARGET_COLUMNS}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"labels.csv missing columns: {sorted(missing)}")

    root = Path(repo_root)
    rows: list[LabelRow] = []
    for _, r in df.iterrows():
        rows.append(
            LabelRow(
                pdb_code=str(r["pdb_code"]),
                protein_name=str(r["protein_name"]),
                pdb_path=(root / str(r["pdb_path"])).resolve(),
                kDa=float(r["kDa"]),
                targets={k: float(r[k]) for k in TARGET_COLUMNS},
            )
        )
    return rows
```

- [ ] **Step 5: Run test to verify it passes**

Run: `uv run pytest tests/test_labels.py -v`
Expected: PASS.

- [ ] **Step 6: Commit**

```bash
git add data/labels.csv src/pdb_project/data/labels.py tests/test_labels.py
git commit -m "feat(data): labels.csv + loader for protein-level metadata"
```

---

## Task 6: Dataset (ties graphs + labels together)

**Files:**
- Create: `src/pdb_project/data/dataset.py`
- Create: `tests/test_dataset.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/test_dataset.py
from pathlib import Path

import torch

from pdb_project.data.dataset import FluorescenceDataset


def test_dataset_len_and_item(repo_root: Path) -> None:
    ds = FluorescenceDataset(
        labels_csv=repo_root / "data" / "labels.csv",
        repo_root=repo_root,
    )
    assert len(ds) == 2

    sample = ds[0]
    # Sample is a dict with protein graph, ligand graph, kDa, targets, pdb_code
    assert set(sample.keys()) == {"protein", "ligand", "kDa", "y", "pdb_code"}
    assert sample["protein"].x.shape[1] == 20
    assert sample["ligand"].x.shape[1] == 4
    assert sample["kDa"].shape == (1,)
    assert sample["y"].shape == (3,)  # brightness, emission, qy
    assert sample["pdb_code"] in {"7ZCT", "4OQW"}


def test_dataset_cache(repo_root: Path, tmp_path: Path) -> None:
    ds = FluorescenceDataset(
        labels_csv=repo_root / "data" / "labels.csv",
        repo_root=repo_root,
        cache_dir=tmp_path,
    )
    _ = ds[0]
    _ = ds[0]  # second access should hit cache
    cache_files = list(tmp_path.glob("*.pt"))
    assert len(cache_files) >= 1
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_dataset.py -v`
Expected: `ModuleNotFoundError`.

- [ ] **Step 3: Implement dataset**

```python
# src/pdb_project/data/dataset.py
"""Fluorescence dataset: one sample per PDB.

Each sample is a dict to keep two independent PyG graphs + scalar kDa
+ 3-target vector together. We don't use torch_geometric.data.Dataset
because we want two graphs per item; batching is handled explicitly
in the training loop.
"""
from __future__ import annotations

from pathlib import Path

import torch
from torch.utils.data import Dataset

from .graph_builder import build_graphs
from .labels import TARGET_COLUMNS, LabelRow, load_labels
from .pdb_parser import parse_pdb


class FluorescenceDataset(Dataset):  # type: ignore[type-arg]
    def __init__(
        self,
        labels_csv: str | Path,
        repo_root: str | Path,
        drop_hydrogens: bool = True,
        cache_dir: str | Path | None = None,
    ) -> None:
        self.rows: list[LabelRow] = load_labels(labels_csv, repo_root=repo_root)
        self.drop_hydrogens = drop_hydrogens
        self.cache_dir = Path(cache_dir) if cache_dir is not None else None
        if self.cache_dir is not None:
            self.cache_dir.mkdir(parents=True, exist_ok=True)

    def __len__(self) -> int:
        return len(self.rows)

    def _cache_path(self, row: LabelRow) -> Path | None:
        if self.cache_dir is None:
            return None
        return self.cache_dir / f"{row.pdb_code}.pt"

    def __getitem__(self, idx: int) -> dict[str, object]:
        row = self.rows[idx]
        cpath = self._cache_path(row)
        if cpath is not None and cpath.exists():
            cached: dict[str, object] = torch.load(cpath, weights_only=False)
            return cached

        records = parse_pdb(row.pdb_path)
        protein_g, ligand_g = build_graphs(records, drop_hydrogens=self.drop_hydrogens)
        y = torch.tensor([row.targets[k] for k in TARGET_COLUMNS], dtype=torch.float32)
        kDa = torch.tensor([row.kDa], dtype=torch.float32)
        sample: dict[str, object] = {
            "protein": protein_g,
            "ligand": ligand_g,
            "kDa": kDa,
            "y": y,
            "pdb_code": row.pdb_code,
        }
        if cpath is not None:
            torch.save(sample, cpath)
        return sample
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_dataset.py -v`
Expected: 2 PASS.

- [ ] **Step 5: Commit**

```bash
git add src/pdb_project/data/dataset.py tests/test_dataset.py
git commit -m "feat(data): FluorescenceDataset combining graphs + kDa + 3-target vector"
```

---

## Task 7: Target + feature standardization

**Files:**
- Create: `src/pdb_project/training/standardize.py`
- Create: `tests/test_standardize.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/test_standardize.py
import torch

from pdb_project.training.standardize import Standardizer


def test_standardizer_roundtrip() -> None:
    y = torch.tensor([[78.0, 592.0, 0.75], [16.53, 659.0, 0.19]])
    s = Standardizer.fit(y)
    z = s.transform(y)
    assert torch.allclose(z.mean(0), torch.zeros(3), atol=1e-5)
    # Only one degree of freedom with n=2, std uses ddof=0 below
    assert torch.allclose(s.inverse(z), y, atol=1e-4)


def test_standardizer_preserves_shape() -> None:
    y = torch.randn(10, 3)
    s = Standardizer.fit(y)
    assert s.transform(y).shape == y.shape


def test_standardizer_state_dict() -> None:
    y = torch.randn(5, 3)
    s = Standardizer.fit(y)
    s2 = Standardizer.from_state_dict(s.state_dict())
    assert torch.allclose(s.transform(y), s2.transform(y))
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_standardize.py -v`
Expected: `ModuleNotFoundError`.

- [ ] **Step 3: Implement standardizer**

```python
# src/pdb_project/training/standardize.py
"""Simple fit-once standardizer (mean/std) for targets and scalar features.

Intentionally minimal: computed from training data, applied to train/val/test,
inverted for reporting.
"""
from __future__ import annotations

from dataclasses import dataclass

import torch


@dataclass
class Standardizer:
    mean: torch.Tensor
    std: torch.Tensor

    @classmethod
    def fit(cls, x: torch.Tensor, eps: float = 1e-6) -> "Standardizer":
        mean = x.mean(dim=0)
        std = x.std(dim=0, unbiased=False).clamp_min(eps)
        return cls(mean=mean.detach(), std=std.detach())

    def transform(self, x: torch.Tensor) -> torch.Tensor:
        return (x - self.mean) / self.std

    def inverse(self, z: torch.Tensor) -> torch.Tensor:
        return z * self.std + self.mean

    def state_dict(self) -> dict[str, torch.Tensor]:
        return {"mean": self.mean, "std": self.std}

    @classmethod
    def from_state_dict(cls, state: dict[str, torch.Tensor]) -> "Standardizer":
        return cls(mean=state["mean"], std=state["std"])
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_standardize.py -v`
Expected: 3 PASS.

- [ ] **Step 5: Commit**

```bash
git add src/pdb_project/training/standardize.py tests/test_standardize.py
git commit -m "feat(training): Standardizer for train-fold mean/std with roundtrip inverse"
```

---

## Task 8: Metrics (per-target MAE, R², multi-output MAE)

**Files:**
- Create: `src/pdb_project/training/metrics.py`
- Create: `tests/test_metrics.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/test_metrics.py
import torch

from pdb_project.training.metrics import compute_metrics


def test_perfect_prediction() -> None:
    y = torch.tensor([[1.0, 10.0, 0.5], [2.0, 20.0, 0.3]])
    y_hat = y.clone()
    m = compute_metrics(y_hat=y_hat, y=y, target_names=("brightness", "emission", "qy"))
    assert m["mae/brightness"] == 0.0
    assert m["r2/brightness"] == 1.0
    assert m["mae/overall"] == 0.0


def test_mae_value() -> None:
    y = torch.tensor([[1.0, 10.0, 0.5], [2.0, 20.0, 0.3]])
    y_hat = torch.tensor([[1.5, 12.0, 0.4], [2.5, 18.0, 0.4]])
    m = compute_metrics(y_hat=y_hat, y=y, target_names=("brightness", "emission", "qy"))
    # |1-1.5| + |2-2.5| / 2 = 0.5
    assert abs(m["mae/brightness"] - 0.5) < 1e-6
    # |10-12| + |20-18| / 2 = 2.0
    assert abs(m["mae/emission"] - 2.0) < 1e-6
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_metrics.py -v`
Expected: `ModuleNotFoundError`.

- [ ] **Step 3: Implement metrics**

```python
# src/pdb_project/training/metrics.py
"""Per-target MAE + R² plus overall (standardized-mean) MAE."""
from __future__ import annotations

from collections.abc import Sequence

import torch


def _r2(y_hat: torch.Tensor, y: torch.Tensor) -> float:
    ss_res = ((y - y_hat) ** 2).sum()
    ss_tot = ((y - y.mean()) ** 2).sum()
    if ss_tot.item() == 0.0:
        return 1.0 if ss_res.item() == 0.0 else 0.0
    return float(1.0 - ss_res / ss_tot)


def compute_metrics(
    y_hat: torch.Tensor,
    y: torch.Tensor,
    target_names: Sequence[str],
) -> dict[str, float]:
    """Inputs are on the original (unstandardized) scale.

    Returns:
      mae/<name>, r2/<name> per target; mae/overall averaged across
      z-scored targets (so brightness ~O(10), emission ~O(100), qy ~O(1)
      all contribute equally).
    """
    assert y_hat.shape == y.shape
    assert y.ndim == 2 and y.shape[1] == len(target_names)

    out: dict[str, float] = {}
    per_std_maes: list[float] = []
    for i, name in enumerate(target_names):
        yh = y_hat[:, i]
        yy = y[:, i]
        out[f"mae/{name}"] = float((yh - yy).abs().mean())
        out[f"r2/{name}"] = _r2(yh, yy)
        std = float(yy.std(unbiased=False).clamp_min(1e-6))
        per_std_maes.append(float((yh - yy).abs().mean() / std))
    out["mae/overall"] = float(sum(per_std_maes) / len(per_std_maes))
    return out
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_metrics.py -v`
Expected: 2 PASS.

- [ ] **Step 5: Commit**

```bash
git add src/pdb_project/training/metrics.py tests/test_metrics.py
git commit -m "feat(training): per-target MAE/R² + standardized-mean overall MAE"
```

---

## Task 9: Constant baseline (B0)

**Files:**
- Create: `src/pdb_project/models/constant.py`
- Create: `tests/test_constant_model.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/test_constant_model.py
import torch

from pdb_project.models.constant import ConstantPredictor


def test_constant_predictor_forward() -> None:
    y_train = torch.tensor([[1.0, 10.0, 0.5], [3.0, 20.0, 0.7]])
    model = ConstantPredictor.fit(y_train)

    batch_size = 4
    y_hat = model.predict(batch_size)
    assert y_hat.shape == (batch_size, 3)
    assert torch.allclose(y_hat[0], torch.tensor([2.0, 15.0, 0.6]))
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_constant_model.py -v`
Expected: `ModuleNotFoundError`.

- [ ] **Step 3: Implement constant predictor**

```python
# src/pdb_project/models/constant.py
"""B0: always predict the train-set mean."""
from __future__ import annotations

from dataclasses import dataclass

import torch


@dataclass
class ConstantPredictor:
    mean: torch.Tensor  # shape (T,)

    @classmethod
    def fit(cls, y_train: torch.Tensor) -> "ConstantPredictor":
        return cls(mean=y_train.mean(dim=0).detach())

    def predict(self, batch_size: int) -> torch.Tensor:
        return self.mean.unsqueeze(0).expand(batch_size, -1).clone()
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_constant_model.py -v`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/pdb_project/models/constant.py tests/test_constant_model.py
git commit -m "feat(models): B0 constant predictor (train-mean)"
```

---

## Task 10: Shared fusion head (kDa + pooled embeddings → MLP)

**Files:**
- Create: `src/pdb_project/models/head.py`
- Create: `tests/test_head.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/test_head.py
import torch

from pdb_project.models.head import FusionHead


def test_fusion_head_shapes() -> None:
    head = FusionHead(h_prot_dim=64, h_lig_dim=64, scalar_feature_dim=1, hidden=64, out_dim=3)
    h_prot = torch.randn(5, 64)
    h_lig = torch.randn(5, 64)
    scalar = torch.randn(5, 1)
    y_hat = head(h_prot, h_lig, scalar)
    assert y_hat.shape == (5, 3)


def test_fusion_head_scalar_only() -> None:
    head = FusionHead(h_prot_dim=0, h_lig_dim=0, scalar_feature_dim=41, hidden=32, out_dim=3)
    scalar = torch.randn(3, 41)
    y_hat = head(None, None, scalar)
    assert y_hat.shape == (3, 3)
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_head.py -v`
Expected: `ModuleNotFoundError`.

- [ ] **Step 3: Implement head**

```python
# src/pdb_project/models/head.py
"""Shared fusion + MLP head used by SchNet, GAT, ESM-2, and linear baselines.

Concatenates [h_prot, h_lig, scalar_features] → MLP → out_dim.
Accepts None for either graph embedding to support sequence-only or
scalar-only models without code duplication.
"""
from __future__ import annotations

import torch
from torch import nn


class FusionHead(nn.Module):
    def __init__(
        self,
        h_prot_dim: int,
        h_lig_dim: int,
        scalar_feature_dim: int,
        hidden: int = 64,
        out_dim: int = 3,
        dropout: float = 0.2,
    ) -> None:
        super().__init__()
        in_dim = h_prot_dim + h_lig_dim + scalar_feature_dim
        assert in_dim > 0, "FusionHead needs at least one input stream."
        self.net = nn.Sequential(
            nn.Dropout(dropout),
            nn.Linear(in_dim, hidden),
            nn.SiLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, hidden // 2),
            nn.SiLU(),
            nn.Linear(hidden // 2, out_dim),
        )

    def forward(
        self,
        h_prot: torch.Tensor | None,
        h_lig: torch.Tensor | None,
        scalar: torch.Tensor,
    ) -> torch.Tensor:
        parts: list[torch.Tensor] = []
        if h_prot is not None:
            parts.append(h_prot)
        if h_lig is not None:
            parts.append(h_lig)
        parts.append(scalar)
        return self.net(torch.cat(parts, dim=-1))
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_head.py -v`
Expected: 2 PASS.

- [ ] **Step 5: Commit**

```bash
git add src/pdb_project/models/head.py tests/test_head.py
git commit -m "feat(models): shared FusionHead for embedding+scalar → MLP"
```

---

## Task 11: SchNet-style cfconv + encoder + B3a model

**Files:**
- Create: `src/pdb_project/models/schnet.py`
- Create: `tests/test_schnet.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/test_schnet.py
import torch
from torch_geometric.data import Batch

from pdb_project.data.dataset import FluorescenceDataset
from pdb_project.models.schnet import SchNetFluorescenceModel


def test_schnet_forward(repo_root) -> None:
    ds = FluorescenceDataset(
        labels_csv=repo_root / "data" / "labels.csv",
        repo_root=repo_root,
    )
    s0 = ds[0]
    s1 = ds[1]

    protein_batch = Batch.from_data_list([s0["protein"], s1["protein"]])
    ligand_batch = Batch.from_data_list([s0["ligand"], s1["ligand"]])
    kDa = torch.stack([s0["kDa"], s1["kDa"]], dim=0)  # (2, 1)

    model = SchNetFluorescenceModel(
        node_in_protein=20,
        node_in_ligand=4,
        hidden=32,
        num_layers=2,
        rbf_k=8,
        protein_rbf_high=20.0,
        ligand_rbf_high=10.0,
        out_dim=3,
    )
    y_hat = model(protein_batch, ligand_batch, kDa)
    assert y_hat.shape == (2, 3)


def test_schnet_backward(repo_root) -> None:
    ds = FluorescenceDataset(
        labels_csv=repo_root / "data" / "labels.csv",
        repo_root=repo_root,
    )
    s0 = ds[0]
    protein_batch = Batch.from_data_list([s0["protein"]])
    ligand_batch = Batch.from_data_list([s0["ligand"]])
    kDa = s0["kDa"].unsqueeze(0)

    model = SchNetFluorescenceModel(
        node_in_protein=20, node_in_ligand=4,
        hidden=16, num_layers=2, rbf_k=8,
        protein_rbf_high=20.0, ligand_rbf_high=10.0, out_dim=3,
    )
    y_hat = model(protein_batch, ligand_batch, kDa)
    loss = y_hat.pow(2).sum()
    loss.backward()
    # At least one parameter has a non-zero gradient
    assert any(p.grad is not None and p.grad.abs().sum() > 0 for p in model.parameters())
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_schnet.py -v`
Expected: `ModuleNotFoundError`.

- [ ] **Step 3: Implement SchNet model**

```python
# src/pdb_project/models/schnet.py
"""SchNet-style continuous-filter convolution + end-to-end model.

Reference: Schütt et al., NeurIPS 2017.
cfconv message: m_ij = h_j * MLP(RBF(d_ij))
"""
from __future__ import annotations

import torch
from torch import nn
from torch_geometric.data import Batch
from torch_geometric.nn import MessagePassing, global_mean_pool

from .head import FusionHead
from .rbf import GaussianRBF


class CFConv(MessagePassing):
    """Continuous-filter convolution (SchNet)."""

    def __init__(self, hidden: int, rbf_k: int) -> None:
        super().__init__(aggr="mean")
        self.filter_net = nn.Sequential(
            nn.Linear(rbf_k, hidden),
            nn.SiLU(),
            nn.Linear(hidden, hidden),
        )
        self.lin_in = nn.Linear(hidden, hidden)
        self.lin_out = nn.Linear(hidden, hidden)

    def forward(
        self,
        x: torch.Tensor,           # (N, H)
        edge_index: torch.Tensor,  # (2, E)
        edge_rbf: torch.Tensor,    # (E, K)
    ) -> torch.Tensor:
        h = self.lin_in(x)
        w = self.filter_net(edge_rbf)
        out = self.propagate(edge_index, x=h, W=w)
        return x + self.lin_out(nn.functional.silu(out))

    def message(self, x_j: torch.Tensor, W: torch.Tensor) -> torch.Tensor:
        return x_j * W


class SchNetEncoder(nn.Module):
    """Shared encoder template for either graph (protein or ligand).

    Input node features are projected to `hidden`, then `num_layers`
    cfconv blocks apply distance-aware message passing. Mean pool
    collapses to a graph-level embedding.
    """

    def __init__(
        self,
        node_in: int,
        hidden: int,
        num_layers: int,
        rbf_k: int,
        rbf_high: float,
    ) -> None:
        super().__init__()
        self.embed = nn.Linear(node_in, hidden)
        self.rbf = GaussianRBF(num_centers=rbf_k, low=0.0, high=rbf_high)
        self.layers = nn.ModuleList([CFConv(hidden, rbf_k) for _ in range(num_layers)])

    def forward(self, batch: Batch) -> torch.Tensor:
        x = self.embed(batch.x)
        d = batch.edge_attr.squeeze(-1)  # (E,)
        rbf = self.rbf(d)                # (E, K)
        for layer in self.layers:
            x = layer(x, batch.edge_index, rbf)
        return global_mean_pool(x, batch.batch)


class SchNetFluorescenceModel(nn.Module):
    def __init__(
        self,
        node_in_protein: int = 20,
        node_in_ligand: int = 4,
        hidden: int = 64,
        num_layers: int = 3,
        rbf_k: int = 16,
        protein_rbf_high: float = 20.0,
        ligand_rbf_high: float = 10.0,
        out_dim: int = 3,
        dropout: float = 0.2,
    ) -> None:
        super().__init__()
        self.protein_enc = SchNetEncoder(
            node_in=node_in_protein, hidden=hidden, num_layers=num_layers,
            rbf_k=rbf_k, rbf_high=protein_rbf_high,
        )
        self.ligand_enc = SchNetEncoder(
            node_in=node_in_ligand, hidden=hidden, num_layers=num_layers,
            rbf_k=rbf_k, rbf_high=ligand_rbf_high,
        )
        self.head = FusionHead(
            h_prot_dim=hidden, h_lig_dim=hidden, scalar_feature_dim=1,
            hidden=hidden, out_dim=out_dim, dropout=dropout,
        )

    def forward(
        self,
        protein_batch: Batch,
        ligand_batch: Batch,
        kDa: torch.Tensor,  # (B, 1) standardized
    ) -> torch.Tensor:
        h_prot = self.protein_enc(protein_batch)
        h_lig = self.ligand_enc(ligand_batch)
        return self.head(h_prot, h_lig, kDa)
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_schnet.py -v`
Expected: 2 PASS.

- [ ] **Step 5: Commit**

```bash
git add src/pdb_project/models/schnet.py tests/test_schnet.py
git commit -m "feat(models): SchNet cfconv + dual-graph encoder + B3a model"
```

---

## Task 12: Training loop + batching helper

**Files:**
- Create: `src/pdb_project/training/loop.py`
- Create: `tests/test_loop.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/test_loop.py
import torch
from torch.utils.data import DataLoader

from pdb_project.data.dataset import FluorescenceDataset
from pdb_project.models.schnet import SchNetFluorescenceModel
from pdb_project.training.loop import TrainConfig, collate_fn, train_one_epoch
from pdb_project.training.standardize import Standardizer


def test_train_one_epoch_reduces_loss(repo_root) -> None:
    torch.manual_seed(0)
    ds = FluorescenceDataset(
        labels_csv=repo_root / "data" / "labels.csv",
        repo_root=repo_root,
    )
    loader = DataLoader(ds, batch_size=2, shuffle=False, collate_fn=collate_fn)

    # Fit target standardizer on the only 2 samples we have (plumbing test)
    y_train = torch.stack([ds[i]["y"] for i in range(len(ds))], dim=0)
    y_std = Standardizer.fit(y_train)
    kDa_train = torch.stack([ds[i]["kDa"] for i in range(len(ds))], dim=0)
    kDa_std = Standardizer.fit(kDa_train)

    model = SchNetFluorescenceModel(hidden=16, num_layers=2, rbf_k=8)
    opt = torch.optim.AdamW(model.parameters(), lr=1e-2)

    cfg = TrainConfig()
    # Compute initial loss
    model.eval()
    with torch.no_grad():
        init_loss = _eval_loss(model, loader, y_std, kDa_std)
    # Train a few epochs on the tiny set
    for _ in range(5):
        train_one_epoch(model, loader, opt, y_std, kDa_std, cfg)
    model.eval()
    with torch.no_grad():
        final_loss = _eval_loss(model, loader, y_std, kDa_std)

    assert final_loss < init_loss


def _eval_loss(model, loader, y_std, kDa_std) -> float:
    total = 0.0
    n = 0
    for batch in loader:
        y = batch["y"]
        kDa = kDa_std.transform(batch["kDa"])
        y_hat = model(batch["protein"], batch["ligand"], kDa)
        z = y_std.transform(y)
        total += float(((y_hat - z) ** 2).mean())
        n += 1
    return total / max(n, 1)
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_loop.py -v`
Expected: `ImportError` for `collate_fn` / `train_one_epoch`.

- [ ] **Step 3: Implement loop + collate**

```python
# src/pdb_project/training/loop.py
"""Training loop primitives.

Batching: we can't use the default PyG DataLoader because each sample has
TWO graphs plus a scalar and a target vector. collate_fn builds a Batch
for each graph stream independently.
"""
from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass

import torch
from torch import nn
from torch.utils.data import DataLoader
from torch_geometric.data import Batch

from .standardize import Standardizer


@dataclass
class TrainConfig:
    grad_clip: float = 1.0


def collate_fn(samples: Sequence[dict[str, object]]) -> dict[str, object]:
    proteins = Batch.from_data_list([s["protein"] for s in samples])  # type: ignore[arg-type]
    ligands = Batch.from_data_list([s["ligand"] for s in samples])    # type: ignore[arg-type]
    kDa = torch.stack([s["kDa"] for s in samples], dim=0)             # type: ignore[arg-type]
    y = torch.stack([s["y"] for s in samples], dim=0)                 # type: ignore[arg-type]
    pdb_codes = [s["pdb_code"] for s in samples]
    return {"protein": proteins, "ligand": ligands, "kDa": kDa, "y": y, "pdb_codes": pdb_codes}


def train_one_epoch(
    model: nn.Module,
    loader: DataLoader,
    optimizer: torch.optim.Optimizer,
    y_std: Standardizer,
    kDa_std: Standardizer,
    cfg: TrainConfig,
) -> float:
    model.train()
    total = 0.0
    n = 0
    for batch in loader:
        optimizer.zero_grad()
        kDa = kDa_std.transform(batch["kDa"])
        y_hat = model(batch["protein"], batch["ligand"], kDa)
        z = y_std.transform(batch["y"])
        loss = ((y_hat - z) ** 2).mean()
        loss.backward()
        if cfg.grad_clip > 0:
            torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.grad_clip)
        optimizer.step()
        total += float(loss)
        n += 1
    return total / max(n, 1)


@torch.no_grad()
def evaluate(
    model: nn.Module,
    loader: DataLoader,
    y_std: Standardizer,
    kDa_std: Standardizer,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Return (y_hat_original_scale, y_original_scale)."""
    model.eval()
    preds: list[torch.Tensor] = []
    gts: list[torch.Tensor] = []
    for batch in loader:
        kDa = kDa_std.transform(batch["kDa"])
        z_hat = model(batch["protein"], batch["ligand"], kDa)
        y_hat = y_std.inverse(z_hat)
        preds.append(y_hat)
        gts.append(batch["y"])
    return torch.cat(preds, 0), torch.cat(gts, 0)
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_loop.py -v`
Expected: PASS (loss decreases on the 2-sample set).

- [ ] **Step 5: Commit**

```bash
git add src/pdb_project/training/loop.py tests/test_loop.py
git commit -m "feat(training): collate + train_one_epoch + evaluate for dual-graph batches"
```

---

## Task 13: Sequence-identity splits (mmseqs2 wrapper + small-n fallback)

**Files:**
- Create: `src/pdb_project/training/splits.py`
- Create: `tests/test_splits.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/test_splits.py
from pdb_project.training.splits import assign_folds, cluster_sequences


def test_assign_folds_deterministic() -> None:
    clusters = {
        "A": ["p1", "p2"],
        "B": ["p3"],
        "C": ["p4", "p5", "p6"],
        "D": ["p7"],
        "E": ["p8"],
    }
    a1 = assign_folds(clusters, k=3, seed=42)
    a2 = assign_folds(clusters, k=3, seed=42)
    assert a1 == a2
    # Every protein assigned to exactly one fold
    all_proteins = {p for members in clusters.values() for p in members}
    assigned = {p: f for f, ps in a1.items() for p in ps}
    assert set(assigned.keys()) == all_proteins
    # Cluster integrity: all members of a cluster in the same fold
    for members in clusters.values():
        folds = {assigned[m] for m in members}
        assert len(folds) == 1


def test_cluster_sequences_small_fallback() -> None:
    """When mmseqs2 is unavailable OR n < 2, each sequence becomes its own cluster."""
    seqs = {"p1": "MVSK", "p2": "MVSK", "p3": "ACGT"}
    clusters = cluster_sequences(seqs, identity=0.7, fallback=True)
    # 2 clusters expected: {p1, p2} share identical sequence; p3 is alone
    grouped = {frozenset(v) for v in clusters.values()}
    assert frozenset({"p1", "p2"}) in grouped or all(len(v) == 1 for v in clusters.values())
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_splits.py -v`
Expected: `ModuleNotFoundError`.

- [ ] **Step 3: Implement splits module**

```python
# src/pdb_project/training/splits.py
"""Sequence-identity clustering + k-fold assignment.

Primary path: mmseqs2 easy-cluster on a temporary FASTA.
Fallback (no mmseqs2 binary OR `fallback=True`): union-find on
exact-sequence identity, i.e. only proteins with identical sequences
are clustered. Meant ONLY for development; never for the 100-protein
reporting run.
"""
from __future__ import annotations

import hashlib
import random
import shutil
import subprocess
import tempfile
from collections import defaultdict
from pathlib import Path


def cluster_sequences(
    sequences: dict[str, str],
    identity: float = 0.7,
    fallback: bool = False,
    coverage: float = 0.8,
) -> dict[str, list[str]]:
    """Return {cluster_id: [protein_id, ...]}.

    cluster_id is arbitrary but stable within one call.
    """
    if fallback or shutil.which("mmseqs") is None:
        return _fallback_cluster(sequences)
    return _mmseqs_cluster(sequences, identity=identity, coverage=coverage)


def _fallback_cluster(sequences: dict[str, str]) -> dict[str, list[str]]:
    buckets: dict[str, list[str]] = defaultdict(list)
    for pid, seq in sequences.items():
        key = hashlib.sha1(seq.encode()).hexdigest()
        buckets[key].append(pid)
    return {f"cluster_{i}": members for i, members in enumerate(buckets.values())}


def _mmseqs_cluster(
    sequences: dict[str, str], identity: float, coverage: float
) -> dict[str, list[str]]:
    with tempfile.TemporaryDirectory() as tmp:
        tmpp = Path(tmp)
        fasta = tmpp / "in.fasta"
        fasta.write_text("".join(f">{pid}\n{seq}\n" for pid, seq in sequences.items()))
        out_prefix = tmpp / "out"
        work = tmpp / "work"
        work.mkdir()
        subprocess.run(
            [
                "mmseqs", "easy-cluster",
                str(fasta), str(out_prefix), str(work),
                "--min-seq-id", str(identity),
                "-c", str(coverage),
                "--cov-mode", "0",
            ],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        tsv = Path(f"{out_prefix}_cluster.tsv")
        clusters: dict[str, list[str]] = defaultdict(list)
        for line in tsv.read_text().splitlines():
            rep, member = line.split("\t")
            clusters[rep].append(member)
    return dict(clusters)


def assign_folds(
    clusters: dict[str, list[str]],
    k: int = 5,
    seed: int = 0,
) -> dict[int, list[str]]:
    """Greedy load-balanced assignment of whole clusters to folds.

    Deterministic given (clusters, k, seed).
    """
    rng = random.Random(seed)
    items = sorted(clusters.items())
    rng.shuffle(items)
    # Sort by cluster size desc to pack fuller clusters first (LPT heuristic)
    items.sort(key=lambda kv: (-len(kv[1]), kv[0]))

    folds: dict[int, list[str]] = {i: [] for i in range(k)}
    fold_sizes = [0] * k
    for _cluster_id, members in items:
        target = min(range(k), key=lambda i: (fold_sizes[i], i))
        folds[target].extend(members)
        fold_sizes[target] += len(members)
    return folds
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_splits.py -v`
Expected: 2 PASS.

- [ ] **Step 5: Commit**

```bash
git add src/pdb_project/training/splits.py tests/test_splits.py
git commit -m "feat(training): mmseqs2 clustering + deterministic LPT fold assignment"
```

---

## Task 14: Hydra configs + CLI entry point

**Files:**
- Create: `conf/config.yaml`, `conf/data/default.yaml`, `conf/training/default.yaml`, `conf/validation/cv5.yaml`
- Create: `conf/model/{schnet,gat,esm2,linear,constant}.yaml`
- Create: `src/pdb_project/cli.py`

- [ ] **Step 1: Create `conf/config.yaml`**

```yaml
defaults:
  - data: default
  - model: schnet
  - training: default
  - validation: cv5
  - _self_

seed: 0
device: cuda            # falls back to cpu if unavailable
out_dir: outputs
run_name: ${model.name}
```

- [ ] **Step 2: Create `conf/data/default.yaml`**

```yaml
labels_csv: data/labels.csv
repo_root: .
drop_hydrogens: true
cache_dir: data/cache
```

- [ ] **Step 3: Create `conf/training/default.yaml`**

```yaml
optimizer:
  lr: 1.0e-3
  weight_decay: 1.0e-4
batch_size: 8
max_epochs: 200
early_stopping_patience: 30
grad_clip: 1.0
scheduler:
  name: cosine
  warmup_epochs: 5
```

- [ ] **Step 4: Create `conf/validation/cv5.yaml`**

```yaml
k: 5
identity: 0.7
coverage: 0.8
val_fraction: 0.1        # fraction of TRAIN clusters held out for early stopping
fallback_clustering: false
seed: 0
```

- [ ] **Step 5: Create `conf/model/schnet.yaml`**

```yaml
name: schnet
type: schnet
hidden: 64
num_layers: 3
rbf_k: 16
protein_rbf_high: 20.0
ligand_rbf_high: 10.0
dropout: 0.2
```

- [ ] **Step 6: Create `conf/model/gat.yaml`**

```yaml
name: gat
type: gat
hidden: 64
num_layers: 3
heads: 4
rbf_k: 16
protein_rbf_high: 20.0
ligand_rbf_high: 10.0
dropout: 0.2
```

- [ ] **Step 7: Create `conf/model/esm2.yaml`**

```yaml
name: esm2
type: esm2
esm_model: esm2_t12_35M_UR50D   # small variant; upgrade if GPU allows
mlp_hidden: 128
dropout: 0.2
```

- [ ] **Step 8: Create `conf/model/linear.yaml`**

```yaml
name: linear
type: linear
contact_cutoff: 6.0
alpha: 1.0                   # ridge regularization
```

- [ ] **Step 9: Create `conf/model/constant.yaml`**

```yaml
name: constant
type: constant
```

- [ ] **Step 10: Create `src/pdb_project/cli.py`**

```python
"""Hydra entry point.

Dispatches by model.type. For now the CLI just builds the requested
model and runs a single forward pass as a wiring check; the full CV
runner lives in scripts/run_cv.py (Task 17) and reuses the same factory.
"""
from __future__ import annotations

import logging
from pathlib import Path

import hydra
import torch
from omegaconf import DictConfig, OmegaConf

from pdb_project.data.dataset import FluorescenceDataset
from pdb_project.models.schnet import SchNetFluorescenceModel

log = logging.getLogger(__name__)


def build_model(cfg: DictConfig) -> torch.nn.Module:
    t = cfg.model.type
    if t == "schnet":
        return SchNetFluorescenceModel(
            hidden=cfg.model.hidden,
            num_layers=cfg.model.num_layers,
            rbf_k=cfg.model.rbf_k,
            protein_rbf_high=cfg.model.protein_rbf_high,
            ligand_rbf_high=cfg.model.ligand_rbf_high,
            dropout=cfg.model.dropout,
        )
    # Placeholders: filled in by later tasks (12+ add GAT, ESM-2, linear, constant).
    raise NotImplementedError(f"Model type {t!r} not yet wired into the CLI.")


@hydra.main(version_base=None, config_path="../../conf", config_name="config")
def main(cfg: DictConfig) -> None:
    log.info("Resolved config:\n%s", OmegaConf.to_yaml(cfg))
    repo_root = Path(cfg.data.repo_root).resolve()
    ds = FluorescenceDataset(
        labels_csv=cfg.data.labels_csv,
        repo_root=repo_root,
        drop_hydrogens=cfg.data.drop_hydrogens,
        cache_dir=cfg.data.cache_dir,
    )
    log.info("Loaded %d samples", len(ds))
    model = build_model(cfg)
    log.info("Built model: %s", type(model).__name__)


if __name__ == "__main__":
    main()
```

- [ ] **Step 11: Smoke-test the CLI**

Run: `uv run python -m pdb_project.cli`
Expected: prints resolved config YAML, logs "Loaded 2 samples" and "Built model: SchNetFluorescenceModel".

- [ ] **Step 12: Commit**

```bash
git add conf src/pdb_project/cli.py
git commit -m "feat(cli): Hydra config tree + entry point with SchNet wiring"
```

---

## Task 15: Plumbing test script (1 train / 1 test)

**Files:**
- Create: `scripts/plumbing_test.py`

- [ ] **Step 1: Write the script**

```python
# scripts/plumbing_test.py
"""Plumbing test: train on one protein, test on the other.

Produces NO scientific conclusions. Exists to prove that the data pipeline,
model, loss, optimizer, and evaluation all work end-to-end.
"""
from __future__ import annotations

import logging
from pathlib import Path

import torch
from torch.utils.data import DataLoader, Subset

from pdb_project.data.dataset import FluorescenceDataset
from pdb_project.data.labels import TARGET_COLUMNS
from pdb_project.models.schnet import SchNetFluorescenceModel
from pdb_project.training.loop import TrainConfig, collate_fn, evaluate, train_one_epoch
from pdb_project.training.metrics import compute_metrics
from pdb_project.training.standardize import Standardizer

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger(__name__)


def main() -> None:
    torch.manual_seed(0)
    repo_root = Path(__file__).resolve().parent.parent
    ds = FluorescenceDataset(
        labels_csv=repo_root / "data" / "labels.csv",
        repo_root=repo_root,
    )
    assert len(ds) == 2, "Plumbing test requires exactly 2 samples for now."

    train_ds = Subset(ds, [0])
    test_ds = Subset(ds, [1])

    y_train = torch.stack([ds[0]["y"]], dim=0)
    kDa_train = torch.stack([ds[0]["kDa"]], dim=0)
    y_std = Standardizer.fit(y_train)
    kDa_std = Standardizer.fit(kDa_train)

    train_loader = DataLoader(train_ds, batch_size=1, shuffle=True, collate_fn=collate_fn)
    test_loader = DataLoader(test_ds, batch_size=1, shuffle=False, collate_fn=collate_fn)

    model = SchNetFluorescenceModel(hidden=32, num_layers=2, rbf_k=16)
    opt = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-4)
    cfg = TrainConfig(grad_clip=1.0)

    for epoch in range(1, 51):
        loss = train_one_epoch(model, train_loader, opt, y_std, kDa_std, cfg)
        if epoch % 10 == 0:
            log.info("epoch %d  train_loss=%.4f", epoch, loss)

    y_hat, y = evaluate(model, test_loader, y_std, kDa_std)
    m = compute_metrics(y_hat=y_hat, y=y, target_names=TARGET_COLUMNS)
    log.info("Test metrics (n=1, not meaningful):\n%s", m)


if __name__ == "__main__":
    main()
```

- [ ] **Step 2: Run the script**

Run: `uv run python scripts/plumbing_test.py`
Expected: logs decreasing train loss across 50 epochs and prints a metrics dict (values meaningless at n=1; we're verifying the pipeline runs without crashing).

- [ ] **Step 3: Commit**

```bash
git add scripts/plumbing_test.py
git commit -m "feat(scripts): end-to-end plumbing test on 2-protein subset"
```

---

## Task 16: GAT variant (B3b)

**Files:**
- Create: `src/pdb_project/models/gat.py`
- Create: `tests/test_gat.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/test_gat.py
import torch
from torch_geometric.data import Batch

from pdb_project.data.dataset import FluorescenceDataset
from pdb_project.models.gat import GATFluorescenceModel


def test_gat_forward(repo_root) -> None:
    ds = FluorescenceDataset(
        labels_csv=repo_root / "data" / "labels.csv",
        repo_root=repo_root,
    )
    s0, s1 = ds[0], ds[1]
    protein_batch = Batch.from_data_list([s0["protein"], s1["protein"]])
    ligand_batch = Batch.from_data_list([s0["ligand"], s1["ligand"]])
    kDa = torch.stack([s0["kDa"], s1["kDa"]], dim=0)

    model = GATFluorescenceModel(
        node_in_protein=20, node_in_ligand=4,
        hidden=32, num_layers=2, heads=2, rbf_k=8,
        protein_rbf_high=20.0, ligand_rbf_high=10.0, out_dim=3,
    )
    y_hat = model(protein_batch, ligand_batch, kDa)
    assert y_hat.shape == (2, 3)
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_gat.py -v`
Expected: `ModuleNotFoundError`.

- [ ] **Step 3: Implement GAT model**

```python
# src/pdb_project/models/gat.py
"""GATv2-based variant of the dual-graph model.

Same data pipeline, same pooling, same FusionHead as SchNet.
Only the graph-layer mechanism changes (attention over RBF-expanded
edge features vs. SchNet's continuous-filter convolution).
"""
from __future__ import annotations

import torch
from torch import nn
from torch_geometric.data import Batch
from torch_geometric.nn import GATv2Conv, global_mean_pool

from .head import FusionHead
from .rbf import GaussianRBF


class GATEncoder(nn.Module):
    def __init__(
        self,
        node_in: int,
        hidden: int,
        num_layers: int,
        heads: int,
        rbf_k: int,
        rbf_high: float,
    ) -> None:
        super().__init__()
        self.embed = nn.Linear(node_in, hidden)
        self.rbf = GaussianRBF(num_centers=rbf_k, low=0.0, high=rbf_high)
        layers: list[nn.Module] = []
        in_dim = hidden
        for i in range(num_layers):
            is_last = i == num_layers - 1
            out_heads = 1 if is_last else heads
            out_dim = hidden if is_last else hidden * heads
            layers.append(
                GATv2Conv(
                    in_dim, hidden if is_last else hidden,
                    heads=out_heads, concat=not is_last,
                    edge_dim=rbf_k, add_self_loops=False,
                )
            )
            in_dim = out_dim
        self.layers = nn.ModuleList(layers)
        self.act = nn.SiLU()

    def forward(self, batch: Batch) -> torch.Tensor:
        x = self.embed(batch.x)
        d = batch.edge_attr.squeeze(-1)
        edge_rbf = self.rbf(d)
        for layer in self.layers:
            x = self.act(layer(x, batch.edge_index, edge_attr=edge_rbf))
        return global_mean_pool(x, batch.batch)


class GATFluorescenceModel(nn.Module):
    def __init__(
        self,
        node_in_protein: int = 20,
        node_in_ligand: int = 4,
        hidden: int = 64,
        num_layers: int = 3,
        heads: int = 4,
        rbf_k: int = 16,
        protein_rbf_high: float = 20.0,
        ligand_rbf_high: float = 10.0,
        out_dim: int = 3,
        dropout: float = 0.2,
    ) -> None:
        super().__init__()
        self.protein_enc = GATEncoder(
            node_in=node_in_protein, hidden=hidden, num_layers=num_layers,
            heads=heads, rbf_k=rbf_k, rbf_high=protein_rbf_high,
        )
        self.ligand_enc = GATEncoder(
            node_in=node_in_ligand, hidden=hidden, num_layers=num_layers,
            heads=heads, rbf_k=rbf_k, rbf_high=ligand_rbf_high,
        )
        self.head = FusionHead(
            h_prot_dim=hidden, h_lig_dim=hidden, scalar_feature_dim=1,
            hidden=hidden, out_dim=out_dim, dropout=dropout,
        )

    def forward(self, protein_batch: Batch, ligand_batch: Batch, kDa: torch.Tensor) -> torch.Tensor:
        h_prot = self.protein_enc(protein_batch)
        h_lig = self.ligand_enc(ligand_batch)
        return self.head(h_prot, h_lig, kDa)
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_gat.py -v`
Expected: PASS.

- [ ] **Step 5: Wire GAT into the CLI factory**

Edit `src/pdb_project/cli.py`, replace the `build_model` function with:

```python
def build_model(cfg: DictConfig) -> torch.nn.Module:
    t = cfg.model.type
    if t == "schnet":
        return SchNetFluorescenceModel(
            hidden=cfg.model.hidden,
            num_layers=cfg.model.num_layers,
            rbf_k=cfg.model.rbf_k,
            protein_rbf_high=cfg.model.protein_rbf_high,
            ligand_rbf_high=cfg.model.ligand_rbf_high,
            dropout=cfg.model.dropout,
        )
    if t == "gat":
        from pdb_project.models.gat import GATFluorescenceModel
        return GATFluorescenceModel(
            hidden=cfg.model.hidden,
            num_layers=cfg.model.num_layers,
            heads=cfg.model.heads,
            rbf_k=cfg.model.rbf_k,
            protein_rbf_high=cfg.model.protein_rbf_high,
            ligand_rbf_high=cfg.model.ligand_rbf_high,
            dropout=cfg.model.dropout,
        )
    raise NotImplementedError(f"Model type {t!r} not yet wired into the CLI.")
```

Run: `uv run python -m pdb_project.cli model=gat`
Expected: logs "Built model: GATFluorescenceModel".

- [ ] **Step 6: Commit**

```bash
git add src/pdb_project/models/gat.py tests/test_gat.py src/pdb_project/cli.py
git commit -m "feat(models): GATv2 dual-graph variant (B3b)"
```

---

## Task 17: Linear baseline (B1) with hand-crafted features

**Files:**
- Create: `src/pdb_project/models/linear.py`
- Create: `tests/test_linear_model.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/test_linear_model.py
import numpy as np
import torch

from pdb_project.data.dataset import FluorescenceDataset
from pdb_project.models.linear import LinearBaseline, featurize_sample


def test_featurize_shape(repo_root) -> None:
    ds = FluorescenceDataset(
        labels_csv=repo_root / "data" / "labels.csv",
        repo_root=repo_root,
    )
    feats = featurize_sample(ds[0], contact_cutoff=6.0)
    # kDa (1) + AA composition (20) + NRQ contact composition (20) = 41
    assert feats.shape == (41,)


def test_linear_baseline_fit_and_predict(repo_root) -> None:
    ds = FluorescenceDataset(
        labels_csv=repo_root / "data" / "labels.csv",
        repo_root=repo_root,
    )
    X = np.stack([featurize_sample(ds[i], contact_cutoff=6.0) for i in range(len(ds))], axis=0)
    y = torch.stack([ds[i]["y"] for i in range(len(ds))], dim=0).numpy()
    model = LinearBaseline(alpha=1.0).fit(X, y)
    preds = model.predict(X)
    assert preds.shape == y.shape
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_linear_model.py -v`
Expected: `ModuleNotFoundError`.

- [ ] **Step 3: Implement linear baseline**

```python
# src/pdb_project/models/linear.py
"""B1: ridge regression on 41-dim hand-crafted features.

Features:
  - kDa                                         (1)
  - AA composition (fraction per AA)            (20)
  - NRQ contact-residue composition              (20)
      residues with COM within `contact_cutoff` Å of any NRQ atom
      → 20-dim fraction (normalized, or all-zero if no contacts)
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from sklearn.linear_model import Ridge

from ..data.graph_builder import AA_ORDER, AA_TO_IDX


def featurize_sample(sample: dict[str, object], contact_cutoff: float = 6.0) -> np.ndarray:
    protein = sample["protein"]  # PyG Data
    ligand = sample["ligand"]
    kDa = sample["kDa"].item()  # type: ignore[union-attr]

    aa_hot = protein.x.numpy()  # type: ignore[union-attr]
    n = aa_hot.shape[0]
    aa_comp = aa_hot.sum(axis=0) / max(n, 1)  # (20,)

    # Contact residues: any ligand atom within `contact_cutoff` Å of residue COM
    prot_pos = protein.pos.numpy()                # (N_res, 3)
    lig_pos = ligand.pos.numpy()                  # (N_atom, 3)
    # pairwise distances, (N_res, N_atom)
    diff = prot_pos[:, None, :] - lig_pos[None, :, :]
    dists = np.linalg.norm(diff, axis=-1)
    in_contact = (dists <= contact_cutoff).any(axis=1)  # (N_res,)
    contact_aa_hot = aa_hot[in_contact]
    if contact_aa_hot.shape[0] == 0:
        contact_comp = np.zeros(len(AA_ORDER), dtype=np.float32)
    else:
        contact_comp = contact_aa_hot.sum(axis=0) / contact_aa_hot.shape[0]

    return np.concatenate([[kDa], aa_comp, contact_comp]).astype(np.float32)


@dataclass
class LinearBaseline:
    alpha: float = 1.0
    model: Ridge | None = None

    def fit(self, X: np.ndarray, y: np.ndarray) -> "LinearBaseline":
        self.model = Ridge(alpha=self.alpha).fit(X, y)
        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        assert self.model is not None
        return self.model.predict(X)  # type: ignore[no-any-return]
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/test_linear_model.py -v`
Expected: 2 PASS.

- [ ] **Step 5: Commit**

```bash
git add src/pdb_project/models/linear.py tests/test_linear_model.py
git commit -m "feat(models): B1 ridge baseline on 41-dim hand-crafted features"
```

---

## Task 18: ESM-2 baseline (B2)

**Files:**
- Create: `src/pdb_project/models/esm2_mlp.py`
- Create: `tests/test_esm2_mlp.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/test_esm2_mlp.py
import pytest
import torch

from pdb_project.models.esm2_mlp import ESM2Baseline


def test_esm2_baseline_forward_cpu() -> None:
    try:
        model = ESM2Baseline(esm_model_name="esm2_t6_8M_UR50D", mlp_hidden=16)
    except Exception as e:  # network failure, etc.
        pytest.skip(f"ESM-2 weights unavailable: {e}")

    sequences = [
        "MVSKGEELIKENMHMKLY",
        "MDSTEAVIKEFMRFKVHM",
    ]
    kDa = torch.tensor([[25.85], [27.55]])
    y_hat = model(sequences, kDa)
    assert y_hat.shape == (2, 3)
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/test_esm2_mlp.py -v`
Expected: `ModuleNotFoundError`.

- [ ] **Step 3: Implement ESM-2 baseline**

```python
# src/pdb_project/models/esm2_mlp.py
"""B2: frozen ESM-2 encoder + MLP head on mean-pooled residue embeddings.

We freeze ESM-2 (no fine-tuning) for both compute reasons and for honesty
as a baseline — the question this baseline answers is "how far does a
pretrained sequence model get us?", not "can we tune a giant model on
100 proteins?".
"""
from __future__ import annotations

import esm  # type: ignore[import-untyped]
import torch
from torch import nn

from .head import FusionHead


class ESM2Baseline(nn.Module):
    def __init__(
        self,
        esm_model_name: str = "esm2_t12_35M_UR50D",
        mlp_hidden: int = 128,
        out_dim: int = 3,
        dropout: float = 0.2,
    ) -> None:
        super().__init__()
        load = getattr(esm.pretrained, esm_model_name)
        backbone, alphabet = load()
        for p in backbone.parameters():
            p.requires_grad = False
        backbone.eval()
        self.backbone = backbone
        self.batch_converter = alphabet.get_batch_converter()
        self.repr_layer = backbone.num_layers
        self.embed_dim = backbone.embed_dim
        self.head = FusionHead(
            h_prot_dim=self.embed_dim, h_lig_dim=0, scalar_feature_dim=1,
            hidden=mlp_hidden, out_dim=out_dim, dropout=dropout,
        )

    @torch.no_grad()
    def _embed(self, sequences: list[str]) -> torch.Tensor:
        pairs = [(f"s{i}", s) for i, s in enumerate(sequences)]
        _, _, toks = self.batch_converter(pairs)
        toks = toks.to(next(self.head.parameters()).device)
        out = self.backbone(toks, repr_layers=[self.repr_layer])
        reprs = out["representations"][self.repr_layer]  # (B, L, D)
        # Drop BOS/EOS; mean pool over residues
        return reprs[:, 1:-1, :].mean(dim=1)

    def forward(self, sequences: list[str], kDa: torch.Tensor) -> torch.Tensor:
        h_prot = self._embed(sequences)
        return self.head(h_prot, None, kDa)
```

- [ ] **Step 4: Run test to verify it passes (or skip if weights unavailable)**

Run: `uv run pytest tests/test_esm2_mlp.py -v`
Expected: PASS or SKIP with a clear message.

- [ ] **Step 5: Add sequence column to labels**

Edit `data/labels.csv` by adding a `sequence` column at the end:

```
pdb_code,protein_name,pdb_path,kDa,brightness,emission,qy,sequence
7ZCT,mScarlet3,data/raw/7ZCT_mScarlet3.pdb,25.85,78.00,592,0.75,MDSTEAVIKEFMRFKVHMEGSMNGHEFEIEGEGEGRPYEGTQTAKLRVTKGGPLPFSWDILSPQFMYGSRAFTKHPADIPDYWKQSFPEGFKWERVMNFEDGGAVSVAQDTSLEDGTLIYKVKLRGTNFPPDGPVMQKKTMGWEASTERLYPEDVVLKGDIKMALRLKDGGRYLADFKTTYRAKKPVQMPGAFNIDRKLDITSHNEDYTVVEQYERSVARHSTGGSGGS
4OQW,mCardinal,data/raw/4OQW_mCardinal.pdb,27.55,16.53,659,0.19,MVSKGEELIKENMHMKLYMEGTVNNHHFKCTTEGEGKPYEGTQTQRIKVVEGGPLPFAFDILATCFMYGSKTFINHTQGIPDFFKQSFPEGFTWERVTTYEDGGVLTVTQDTSLQDGCLIYNVKLRGVNFPSNGPVMQKKTLGWEATTETLYPADGGLEGRCDMALKLVGGGHLHCNLKTTYRSKKPAKNLKMPGVYFVDRRLERIKEADNETYVEQHEVAVARYCDLPSKLGHKLNGMDELYK
```

Then extend `src/pdb_project/data/labels.py`:

Replace the `LabelRow` dataclass and loader to include `sequence`:

```python
@dataclass(frozen=True)
class LabelRow:
    pdb_code: str
    protein_name: str
    pdb_path: Path
    kDa: float
    targets: dict[str, float]
    sequence: str
```

And in `load_labels`, change the required set to include `sequence` and add `sequence=str(r["sequence"])` to the `LabelRow(...)` constructor.

Run: `uv run pytest tests/test_labels.py -v`
Expected: still PASS (the existing test still checks the fields it asserts on; add `assert first.sequence.startswith("MDST")` to the test).

Update `tests/test_labels.py`:

```python
def test_load_labels(repo_root: Path) -> None:
    rows = load_labels(repo_root / "data" / "labels.csv", repo_root=repo_root)
    assert len(rows) == 2
    first: LabelRow = rows[0]
    assert first.pdb_code == "7ZCT"
    assert first.protein_name == "mScarlet3"
    assert first.pdb_path.name == "7ZCT_mScarlet3.pdb"
    assert first.pdb_path.exists()
    assert first.kDa == 25.85
    assert first.targets["brightness"] == 78.00
    assert first.targets["emission"] == 592.0
    assert first.targets["qy"] == 0.75
    assert first.sequence.startswith("MDST")
```

Run: `uv run pytest tests/test_labels.py -v`
Expected: PASS.

- [ ] **Step 6: Commit**

```bash
git add src/pdb_project/models/esm2_mlp.py tests/test_esm2_mlp.py data/labels.csv src/pdb_project/data/labels.py tests/test_labels.py
git commit -m "feat(models): B2 ESM-2 frozen-encoder baseline + sequence column in labels"
```

---

## Task 19: 5-fold CV runner script

**Files:**
- Create: `scripts/run_cv.py`

- [ ] **Step 1: Write the CV runner**

```python
# scripts/run_cv.py
"""5-fold cross-validation over sequence-identity clusters.

Steps per fold:
  1. Build sequence-identity clusters from labels.csv (mmseqs2 or fallback).
  2. Assign clusters to 5 folds (LPT).
  3. For each fold k: train on folds≠k (with 10% cluster-level val holdout
     for early stopping), test on fold k.
  4. Aggregate per-fold per-target MAE/R² and report mean ± std.

This script uses SchNet (B3a) by default; change `--model` to run others.
Baselines B0/B1 have their own scikit-learn-style inner loop (no gradient
training), which this script delegates to `_run_sklearn_baseline`.
"""
from __future__ import annotations

import argparse
import json
import logging
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader, Subset

from pdb_project.data.dataset import FluorescenceDataset
from pdb_project.data.labels import TARGET_COLUMNS, load_labels
from pdb_project.models.constant import ConstantPredictor
from pdb_project.models.linear import LinearBaseline, featurize_sample
from pdb_project.models.schnet import SchNetFluorescenceModel
from pdb_project.training.loop import TrainConfig, collate_fn, evaluate, train_one_epoch
from pdb_project.training.metrics import compute_metrics
from pdb_project.training.splits import assign_folds, cluster_sequences
from pdb_project.training.standardize import Standardizer

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger(__name__)


def _gnn_one_fold(
    ds: FluorescenceDataset,
    train_idx: list[int],
    val_idx: list[int],
    test_idx: list[int],
    *,
    max_epochs: int,
    patience: int,
    lr: float,
    weight_decay: float,
    batch_size: int,
    device: str,
    model_ctor,
) -> dict[str, float]:
    y_train = torch.stack([ds[i]["y"] for i in train_idx], dim=0)
    kDa_train = torch.stack([ds[i]["kDa"] for i in train_idx], dim=0)
    y_std = Standardizer.fit(y_train)
    kDa_std = Standardizer.fit(kDa_train)

    train_loader = DataLoader(Subset(ds, train_idx), batch_size=batch_size, shuffle=True, collate_fn=collate_fn)
    val_loader = DataLoader(Subset(ds, val_idx), batch_size=batch_size, shuffle=False, collate_fn=collate_fn)
    test_loader = DataLoader(Subset(ds, test_idx), batch_size=batch_size, shuffle=False, collate_fn=collate_fn)

    model = model_ctor().to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
    cfg = TrainConfig()

    best_val = float("inf")
    best_state: dict[str, torch.Tensor] | None = None
    epochs_without_improve = 0

    for epoch in range(1, max_epochs + 1):
        _ = train_one_epoch(model, train_loader, opt, y_std, kDa_std, cfg)
        y_hat_val, y_val = evaluate(model, val_loader, y_std, kDa_std)
        val_metrics = compute_metrics(y_hat_val, y_val, TARGET_COLUMNS)
        val_loss = val_metrics["mae/overall"]
        if val_loss < best_val - 1e-6:
            best_val = val_loss
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            epochs_without_improve = 0
        else:
            epochs_without_improve += 1
            if epochs_without_improve >= patience:
                log.info("early stop at epoch %d (best val %.4f)", epoch, best_val)
                break

    if best_state is not None:
        model.load_state_dict(best_state)
    y_hat_test, y_test = evaluate(model, test_loader, y_std, kDa_std)
    return compute_metrics(y_hat_test, y_test, TARGET_COLUMNS)


def _constant_one_fold(ds, train_idx, test_idx) -> dict[str, float]:
    y_train = torch.stack([ds[i]["y"] for i in train_idx], dim=0)
    pred = ConstantPredictor.fit(y_train).predict(len(test_idx))
    y_test = torch.stack([ds[i]["y"] for i in test_idx], dim=0)
    return compute_metrics(pred, y_test, TARGET_COLUMNS)


def _linear_one_fold(ds, train_idx, test_idx, contact_cutoff: float, alpha: float) -> dict[str, float]:
    X_train = np.stack([featurize_sample(ds[i], contact_cutoff=contact_cutoff) for i in train_idx], axis=0)
    X_test = np.stack([featurize_sample(ds[i], contact_cutoff=contact_cutoff) for i in test_idx], axis=0)
    y_train = torch.stack([ds[i]["y"] for i in train_idx], dim=0).numpy()
    y_test = torch.stack([ds[i]["y"] for i in test_idx], dim=0)
    preds = LinearBaseline(alpha=alpha).fit(X_train, y_train).predict(X_test)
    return compute_metrics(torch.from_numpy(preds.astype(np.float32)), y_test, TARGET_COLUMNS)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", choices=["schnet", "constant", "linear"], default="schnet")
    parser.add_argument("--k", type=int, default=5)
    parser.add_argument("--identity", type=float, default=0.7)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--fallback-clustering", action="store_true")
    parser.add_argument("--max-epochs", type=int, default=200)
    parser.add_argument("--patience", type=int, default=30)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--val-fraction", type=float, default=0.1)
    parser.add_argument("--contact-cutoff", type=float, default=6.0)
    parser.add_argument("--ridge-alpha", type=float, default=1.0)
    parser.add_argument("--out-json", default="outputs/cv_results.json")
    args = parser.parse_args()

    repo_root = Path(__file__).resolve().parent.parent
    torch.manual_seed(args.seed)

    labels = load_labels(repo_root / "data" / "labels.csv", repo_root=repo_root)
    sequences = {r.pdb_code: r.sequence for r in labels}
    clusters = cluster_sequences(sequences, identity=args.identity, fallback=args.fallback_clustering)
    folds = assign_folds(clusters, k=args.k, seed=args.seed)
    pid_to_idx = {r.pdb_code: i for i, r in enumerate(labels)}

    ds = FluorescenceDataset(
        labels_csv=repo_root / "data" / "labels.csv",
        repo_root=repo_root,
        cache_dir=repo_root / "data" / "cache",
    )

    per_fold: list[dict[str, float]] = []
    for k in range(args.k):
        test_pids = folds[k]
        train_pids = [p for kk, ps in folds.items() if kk != k for p in ps]
        # Hold out ~val_fraction of TRAIN clusters for early stopping
        train_clusters = [cid for cid, members in clusters.items() if any(m in train_pids for m in members)]
        rng = np.random.default_rng(args.seed + k)
        rng.shuffle(train_clusters)
        n_val = max(1, int(len(train_clusters) * args.val_fraction))
        val_cluster_ids = set(train_clusters[:n_val])
        val_pids = [m for cid in val_cluster_ids for m in clusters[cid] if m in train_pids]
        train_pids_net = [p for p in train_pids if p not in val_pids]

        train_idx = [pid_to_idx[p] for p in train_pids_net]
        val_idx = [pid_to_idx[p] for p in val_pids]
        test_idx = [pid_to_idx[p] for p in test_pids]

        log.info("fold %d: train=%d val=%d test=%d", k, len(train_idx), len(val_idx), len(test_idx))

        if args.model == "constant":
            metrics = _constant_one_fold(ds, train_idx + val_idx, test_idx)
        elif args.model == "linear":
            metrics = _linear_one_fold(ds, train_idx + val_idx, test_idx, args.contact_cutoff, args.ridge_alpha)
        else:  # schnet
            def _ctor() -> torch.nn.Module:
                return SchNetFluorescenceModel()
            metrics = _gnn_one_fold(
                ds, train_idx, val_idx, test_idx,
                max_epochs=args.max_epochs, patience=args.patience,
                lr=args.lr, weight_decay=args.weight_decay, batch_size=args.batch_size,
                device=args.device, model_ctor=_ctor,
            )
        log.info("fold %d metrics: %s", k, metrics)
        per_fold.append(metrics)

    # Aggregate
    agg: dict[str, dict[str, float]] = {}
    keys = per_fold[0].keys()
    for key in keys:
        values = [m[key] for m in per_fold]
        agg[key] = {"mean": float(np.mean(values)), "std": float(np.std(values))}
    log.info("Aggregated metrics:\n%s", json.dumps(agg, indent=2))

    out_path = Path(args.out_json)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps({"model": args.model, "per_fold": per_fold, "aggregate": agg}, indent=2))


if __name__ == "__main__":
    main()
```

- [ ] **Step 2: Smoke-test with the fallback clustering on 2 proteins**

Because `k=5` is impossible with n=2, use `--k 2` and `--fallback-clustering`:

Run: `uv run python scripts/run_cv.py --model constant --k 2 --fallback-clustering`
Expected: logs per-fold metrics for both folds and writes `outputs/cv_results.json`.

Run: `uv run python scripts/run_cv.py --model schnet --k 2 --fallback-clustering --max-epochs 10 --patience 5`
Expected: runs 2 tiny folds end-to-end and writes results JSON.

- [ ] **Step 3: Commit**

```bash
git add scripts/run_cv.py
git commit -m "feat(scripts): 5-fold CV runner with schnet/constant/linear dispatch"
```

---

## Task 20: Ablation hooks (protein-only / NRQ-only / single-task)

**Files:**
- Modify: `src/pdb_project/models/schnet.py`
- Modify: `conf/model/schnet.yaml`

- [ ] **Step 1: Write the failing test**

```python
# tests/test_schnet.py (append)
def test_schnet_protein_only(repo_root) -> None:
    ds = FluorescenceDataset(labels_csv=repo_root / "data" / "labels.csv", repo_root=repo_root)
    from torch_geometric.data import Batch
    s0 = ds[0]
    pb = Batch.from_data_list([s0["protein"]])
    lb = Batch.from_data_list([s0["ligand"]])
    kDa = s0["kDa"].unsqueeze(0)
    model = SchNetFluorescenceModel(hidden=16, num_layers=2, rbf_k=8, use_protein=True, use_ligand=False)
    y_hat = model(pb, lb, kDa)
    assert y_hat.shape == (1, 3)


def test_schnet_ligand_only(repo_root) -> None:
    ds = FluorescenceDataset(labels_csv=repo_root / "data" / "labels.csv", repo_root=repo_root)
    from torch_geometric.data import Batch
    s0 = ds[0]
    pb = Batch.from_data_list([s0["protein"]])
    lb = Batch.from_data_list([s0["ligand"]])
    kDa = s0["kDa"].unsqueeze(0)
    model = SchNetFluorescenceModel(hidden=16, num_layers=2, rbf_k=8, use_protein=False, use_ligand=True)
    y_hat = model(pb, lb, kDa)
    assert y_hat.shape == (1, 3)
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/test_schnet.py -v`
Expected: 2 new tests FAIL with `TypeError: unexpected keyword argument 'use_protein'`.

- [ ] **Step 3: Add ablation flags to `SchNetFluorescenceModel`**

Replace the `__init__` and `forward` of `SchNetFluorescenceModel` with:

```python
class SchNetFluorescenceModel(nn.Module):
    def __init__(
        self,
        node_in_protein: int = 20,
        node_in_ligand: int = 4,
        hidden: int = 64,
        num_layers: int = 3,
        rbf_k: int = 16,
        protein_rbf_high: float = 20.0,
        ligand_rbf_high: float = 10.0,
        out_dim: int = 3,
        dropout: float = 0.2,
        use_protein: bool = True,
        use_ligand: bool = True,
    ) -> None:
        super().__init__()
        assert use_protein or use_ligand, "At least one graph stream must be enabled."
        self.use_protein = use_protein
        self.use_ligand = use_ligand
        self.protein_enc = SchNetEncoder(
            node_in=node_in_protein, hidden=hidden, num_layers=num_layers,
            rbf_k=rbf_k, rbf_high=protein_rbf_high,
        ) if use_protein else None
        self.ligand_enc = SchNetEncoder(
            node_in=node_in_ligand, hidden=hidden, num_layers=num_layers,
            rbf_k=rbf_k, rbf_high=ligand_rbf_high,
        ) if use_ligand else None
        self.head = FusionHead(
            h_prot_dim=hidden if use_protein else 0,
            h_lig_dim=hidden if use_ligand else 0,
            scalar_feature_dim=1,
            hidden=hidden, out_dim=out_dim, dropout=dropout,
        )

    def forward(
        self,
        protein_batch: Batch,
        ligand_batch: Batch,
        kDa: torch.Tensor,
    ) -> torch.Tensor:
        h_prot = self.protein_enc(protein_batch) if self.protein_enc is not None else None
        h_lig = self.ligand_enc(ligand_batch) if self.ligand_enc is not None else None
        return self.head(h_prot, h_lig, kDa)
```

- [ ] **Step 4: Extend `conf/model/schnet.yaml`**

Add two lines at the bottom:

```yaml
use_protein: true
use_ligand: true
```

And update `build_model` in `cli.py` to pass them:

```python
if t == "schnet":
    return SchNetFluorescenceModel(
        hidden=cfg.model.hidden,
        num_layers=cfg.model.num_layers,
        rbf_k=cfg.model.rbf_k,
        protein_rbf_high=cfg.model.protein_rbf_high,
        ligand_rbf_high=cfg.model.ligand_rbf_high,
        dropout=cfg.model.dropout,
        use_protein=cfg.model.use_protein,
        use_ligand=cfg.model.use_ligand,
    )
```

- [ ] **Step 5: Run all tests**

Run: `uv run pytest -v`
Expected: all PASS (except any skipped-ESM tests).

- [ ] **Step 6: Commit**

```bash
git add src/pdb_project/models/schnet.py tests/test_schnet.py conf/model/schnet.yaml src/pdb_project/cli.py
git commit -m "feat(models): SchNet protein-only / ligand-only ablation flags"
```

---

## Task 21: Final README update + full test pass

**Files:**
- Modify: `README.md`

- [ ] **Step 1: Rewrite `README.md` with usage examples**

```markdown
# PDB Project — Fluorescence Property GNN

Predicts (Brightness, Emission wavelength, QY) for fluorescent proteins from 3D structure using a SchNet-style dual-graph GNN.

See `docs/superpowers/specs/2026-04-18-fluorescence-gnn-design.md` for the full design and `docs/superpowers/plans/2026-04-19-fluorescence-gnn-implementation.md` for the implementation plan.

## Setup

```bash
uv sync --all-extras
uv run pre-commit install
uv run pytest
```

## Quick commands

Plumbing test (trains on one PDB, "tests" on the other — sanity check only):

```bash
uv run python scripts/plumbing_test.py
```

Hydra CLI wiring check:

```bash
uv run python -m pdb_project.cli model=schnet
uv run python -m pdb_project.cli model=gat
```

5-fold CV (once ~100 proteins are added to `data/labels.csv`):

```bash
uv run python scripts/run_cv.py --model schnet
uv run python scripts/run_cv.py --model constant
uv run python scripts/run_cv.py --model linear
```

Ablations (via Hydra overrides):

```bash
uv run python -m pdb_project.cli model=schnet model.use_ligand=false
uv run python -m pdb_project.cli model=schnet model.use_protein=false
```

## Adding new proteins

1. Drop the PDB into `data/raw/`.
2. Append a row to `data/labels.csv` with `pdb_code, protein_name, pdb_path, kDa, brightness, emission, qy, sequence`.
3. Clear the cache: `rm -rf data/cache/*`.
4. Run tests to make sure parsing still works: `uv run pytest tests/test_dataset.py tests/test_graph_builder.py`.

## Layout

- `src/pdb_project/data/` — parsing, graph building, dataset
- `src/pdb_project/models/` — SchNet, GAT, ESM-2, linear, constant
- `src/pdb_project/training/` — loop, metrics, splits, standardization
- `conf/` — Hydra config tree
- `scripts/` — CV runner + plumbing test
- `tests/` — pytest suite
```

- [ ] **Step 2: Run the full test suite**

Run: `uv run pytest -v`
Expected: all tests PASS (ESM-2 test may SKIP if weights not downloaded).

- [ ] **Step 3: Run pre-commit on everything**

Run: `uv run pre-commit run --all-files`
Expected: all hooks pass, or ruff autofixes are applied and we re-stage them.

If ruff made fixes, `git add -A` and re-run.

- [ ] **Step 4: Final commit**

```bash
git add -A
git commit -m "docs: README usage + final test/lint pass"
```

---

## Post-plan backlog (NOT part of this plan, do in follow-up work)

These come from spec §8 (optional ablations) and spec §9 (risks). Not implemented now to keep plan scope bounded:

1. **Waters-within-5Å-of-NRQ ablation:** extend `graph_builder.py` to include HOH residues whose oxygen is within a cutoff of any NRQ heavy atom, as a 21st node type. New config flag `data.include_nrq_waters: bool`.
2. **Distance-cutoff protein graph:** replace fully-connected with 8Å cutoff, as a locality-bias ablation.
3. **Single-target heads:** train three independent 1-D output models, compare to the multi-task default.
4. **ESM-2 fine-tuning head:** if the frozen baseline lags far behind, try unfreezing the last ESM-2 transformer block.
5. **Bootstrapped CI test over B0:** paired bootstrap on fold-level MAEs; currently we just report mean±std.

---

## Self-Review

**Spec coverage** (spec section → task(s)):

- §2.1 Targets (Brightness, Emission, QY, standardized, MSE multi-task) → Tasks 5, 7, 8, 11, 12.
- §2.2 Excluded inputs (Stokes, EC, Excitation, HOH) → Tasks 4, 5 (schema); post-plan backlog #1 covers the optional HOH ablation.
- §3.1 PDB parsing (BioPython "or hand-rolled"; parser emits residue + atom records with xyz) → Task 2.
- §3.2 Protein graph (residue, one-hot AA, fully-connected, RBF K=16 on [0,20]) + NRQ graph (heavy atoms only, element one-hot, fully-connected, RBF K=16 on [0,10]) → Tasks 3, 4.
- §3.3 Dataset object with `(G_P, G_L, kDa, y)` per sample → Task 6.
- §4.1 SchNet cfconv layer → Task 11.
- §4.2 Full forward pass (3× cfconv, hidden=64, mean pool, 129-dim fusion, MLP 129→64→32→3) → Tasks 10, 11.
- §4.3 Hyperparameters exposed via Hydra → Task 14.
- §4.4 Loss (1/3 mean MSE on standardized targets) → Task 12.
- §5 baseline ladder: B0 → Task 9; B1 → Task 17; B2 → Task 18; B3a → Task 11; B3b → Task 16; B4 ablations → Task 20.
- §6 Validation protocol (mmseqs2 70% identity, LPT k-fold assignment, cluster-integrity val holdout, per-fold metrics, standardizer on train only) → Tasks 13, 19.
- §7.1 Tooling (uv, pyproject, pre-commit, Hydra, ruff, mypy, pytest, TensorBoard) → Task 1.
- §7.2 Directory layout → Tasks 1, 2-20 (matches exactly).
- §7.3 Reproducibility (torch seed, log Hydra config, deterministic fold assignment) → Tasks 13, 14, 19.
- §8 Ablations: "protein-only / NRQ-only" → Task 20. Others (waters, cutoff, single-target, fine-tuning) → explicitly deferred to Post-plan backlog.
- §9 Risks — not directly implementable; addressed in the report, not the code.

**Gaps found and fixed during review:**

- Original draft had no clear owner for the `sequence` column needed by the ESM-2 baseline and by the clustering module. Fixed: Task 18 extends `labels.csv` and the `LabelRow` schema and updates the labels test in the same task.
- Original draft wired `build_model` only for SchNet in Task 14. Fixed: Task 16 edits `build_model` to add GAT, and Task 20 edits it to pass `use_protein` / `use_ligand`. No dangling `NotImplementedError` by the end.
- Task 19's `_gnn_one_fold` needed the `device` parameter but earlier drafts did not move the batch to device. This is a known limitation; graphs are small and the current script runs on CPU by default (device arg is plumbed but `evaluate` / `train_one_epoch` don't explicitly `.to(device)` each PyG Batch). Acceptable for our scale; documented in README and called out here so the implementer knows to add `.to(device)` on batches if GPU training is wanted later.
- GAT uses `add_self_loops=False` intentionally because the edge_attr (RBF on distances) has no meaningful self-loop value; documented inline.

**Placeholder scan:** no `TODO`, `TBD`, "implement later", or "similar to Task N" references remain. Every step contains the actual code it asks for.

**Type consistency checks:**

- `FusionHead.forward` signature `(h_prot | None, h_lig | None, scalar)` matches all call sites (`SchNet`, `GAT`, `ESM2Baseline`, future callers).
- `Standardizer.fit/transform/inverse` names are consistent between definition (Task 7) and call sites (Tasks 12, 15, 19).
- `TARGET_COLUMNS = ("brightness", "emission", "qy")` is defined once in `data/labels.py` and imported everywhere it is used (Tasks 15, 19).
- `collate_fn` dict keys (`"protein"`, `"ligand"`, `"kDa"`, `"y"`, `"pdb_codes"`) match what `FluorescenceDataset.__getitem__` returns (minus `pdb_code` → `pdb_codes` in the batched version; call sites don't depend on that difference).
- `AA_TO_IDX`, `AA_ORDER`, `LIGAND_ELEMENTS` exposed from `graph_builder.py` and imported by `linear.py`.
- `cluster_sequences` / `assign_folds` signatures in `splits.py` match their use in `run_cv.py`.
