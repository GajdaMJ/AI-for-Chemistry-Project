# Fluorescence-Property GNN — Design Spec

**Date:** 2026-04-18
**Context:** Course/collaboration project to predict fluorescent-protein optical properties from 3D structure using a graph neural network.
**Dataset:** ~100 fluorescent proteins (PDB files), each containing the protein + an NRQ chromophore ligand. Two examples currently available: `7ZCT_mScarlet3.pdb`, `4OQW_mCardinal.pdb`.

## 1. Goals & non-goals

**Goals**
- Build a GNN that maps `(protein 3D structure, NRQ 3D structure, kDa)` → `(Brightness, Emission wavelength, QY)`.
- Provide a small scientific framework with honest baselines so the contribution of the 3D-structure signal can be measured, not assumed.
- Keep the project simple enough to run end-to-end on a laptop/single GPU.

**Non-goals**
- Beating state-of-the-art on fluorescent-protein property prediction.
- Supporting arbitrary ligands. The ligand is always NRQ in this dataset.
- Predicting spectra, photo-stability, maturation time, or other properties not listed above.

## 2. Problem framing

### 2.1 Targets

| Target              | Type   | Source column         | Notes                                  |
|---------------------|--------|-----------------------|----------------------------------------|
| Brightness          | scalar | `Brightness`          | Defined as `EC × QY / 1000`.           |
| Emission wavelength | scalar | `Emission wavelength` | In nanometers.                         |
| QY                  | scalar | `QY value`            | Quantum yield in [0, 1]. Auxiliary.    |

All targets are standardized (z-score) on the training fold before loss computation. Reported metrics use unstandardized values.

### 2.2 Inputs (and what we deliberately exclude)

**Included inputs**
- Protein 3D structure (all ATOM records).
- NRQ ligand 3D structure (HETATM records with resname `NRQ`).
- Molecular mass `kDa` (scalar).

**Deliberately excluded, with reason**
- `Stokes shift` — equals `Emission − Excitation`. Including it would leak the Emission target.
- `EC value` — `Brightness = EC × QY / 1000` by identity. Including EC reduces Brightness prediction to guessing QY.
- `Excitation wavelength` — strongly coupled to Emission (Stokes shift is small). Excluded to keep the task non-trivial.
- Crystallographic water molecules (HOH) — included in the raw PDB but dropped from the graph. Their positions are partly crystallization artifacts and counts vary widely across structures; with n≈100 they add more noise than signal. (Kept as an ablation option: "waters within 5 Å of NRQ heavy atoms" — see §8.)

## 3. Data pipeline

### 3.1 PDB parsing
- Parse ATOM + HETATM records with BioPython or a small hand-rolled parser.
- Extract for each residue: residue name (3-letter code), chain ID, residue sequence number, list of atoms with element and xyz.
- Compute per-residue **center of mass (COM)** from its atoms (equal-weighted over heavy atoms; hydrogens dropped).
- For NRQ, keep only heavy atoms (drop H) with their element symbol and xyz.

### 3.2 Graph construction
- **Protein graph** `G_P`:
  - Nodes: residues (20 standard amino-acid types).
  - Node feature: one-hot of AA type (20-dim).
  - Edges: **fully connected** (including self-loops optional, default off).
  - Edge feature per edge `(i, j)`: RBF expansion of the COM–COM Euclidean distance, `K = 16` Gaussians with centers evenly spaced on `[0, 20] Å` and width `σ = (20/K) Å`.
- **NRQ graph** `G_L`:
  - Nodes: heavy atoms of the NRQ ligand.
  - Node feature: one-hot of element (C, N, O, S → 4-dim).
  - Edges: fully connected.
  - Edge feature: RBF expansion of atom–atom Euclidean distance, `K = 16`, centers on `[0, 10] Å`.

### 3.3 Dataset object
- One sample per PDB: `(G_P, G_L, kDa, y)` with `y = (Brightness, Emission, QY)`.
- Backed by PyTorch Geometric `Data` / `Batch`.

## 4. Model architecture

### 4.1 Core: SchNet-style MPNN

Reference: **Schütt et al., NeurIPS 2017, "SchNet: A continuous-filter convolutional neural network for modeling quantum interactions."** The continuous-filter convolution (cfconv) layer computes messages as `m_ij = h_j ⊙ W(RBF(d_ij))` where `W` is a small MLP over the RBF-expanded distance.

Both `G_P` and `G_L` are processed by stacks of cfconv layers (same mechanism, different scale).

### 4.2 Full forward pass

```
protein graph G_P
  → Linear(20 → 64)                         # embed AA one-hot
  → 3× cfconv(hidden=64, RBF_K=16)          # protein encoder
  → mean pool over residues
  → h_prot  (64-dim)

NRQ graph G_L
  → Linear(4 → 64)                          # embed element one-hot
  → 3× cfconv(hidden=64, RBF_K=16)          # ligand encoder
  → mean pool over atoms
  → h_lig   (64-dim)

kDa (standardized on train fold)            # (1-dim)

concat [h_prot, h_lig, kDa]   → (129-dim)
  → Dropout(0.2)
  → Linear(129 → 64) → SiLU
  → Dropout(0.2)
  → Linear(64 → 32)  → SiLU
  → Linear(32 → 3)
  → outputs: [Brightness_hat, Emission_hat, QY_hat]   (standardized)
```

**Why mean pool:** sum pool is sensitive to graph size (the protein graph has ~10× more nodes than the NRQ graph), which would let the protein branch dominate the fused vector by default. Mean pool puts both branches on comparable scales.

**Why no attention pooling / Set2Set:** adds parameters we can't afford at n≈100.

### 4.3 Hyperparameters (starting point)

| Name              | Default | Notes                                     |
|-------------------|---------|-------------------------------------------|
| Hidden dim        | 64      | Try 32 if overfitting; 128 if underfitting. |
| cfconv layers     | 3       | Enough to propagate signal across ~230 residues. |
| RBF K             | 16      | Protein range 0–20 Å; NRQ range 0–10 Å.  |
| Dropout           | 0.2     | In head and between cfconv layers.        |
| Optimizer         | AdamW   | `lr=1e-3`, `weight_decay=1e-4`.          |
| Scheduler         | Cosine  | Over total epochs; warmup optional.       |
| Batch size        | 8       | Small dataset, small graphs.              |
| Max epochs        | 200     | With early stopping on val fold.          |

All hyperparameters are exposed via Hydra config (§7.1).

### 4.4 Loss

`L = (1/3) * (MSE(Brightness_std) + MSE(Emission_std) + MSE(QY_std))`

Targets are standardized on the training fold only (no leakage across folds). At evaluation time we invert the standardization and report MAE and R² per target on the original scale.

## 5. Scientific framework: baseline ladder

At n≈100, baselines aren't optional — they're the only way to tell whether the GNN is learning from structure or memorizing.

| ID   | Model                                           | Purpose                                                                |
|------|-------------------------------------------------|------------------------------------------------------------------------|
| B0   | Constant predictor (train-set mean)             | Floor. Any model not beating this is broken.                           |
| B1   | Linear regression on hand-crafted features      | How much signal is in "bag of residues" + kDa, no geometry?            |
| B2   | MLP on ESM-2 mean-pooled sequence embeddings    | Strong baseline. Does a pretrained sequence model match the GNN?       |
| B3a  | **SchNet MPNN (primary model, §4)**             | The main proposal.                                                     |
| B3b  | GAT variant (distance-agnostic attention)       | Controls for "does distance actually help vs. learned attention?"      |
| B4   | Ablations of B3a: protein-only, NRQ-only        | Which graph is doing the work?                                         |

**Feature specification for B1:** `[kDa, AA composition (20-dim fraction), NRQ contact-residue composition (20-dim, residues within 6 Å of any NRQ heavy atom)]`. 41-dim feature vector.

**B2 details:** ESM-2 (`esm2_t33_650M_UR50D` or a smaller variant depending on compute) on the protein sequence, mean-pool over residues → 1280-dim (or 640-dim for smaller variants). Concatenate kDa, feed into a 2-layer MLP with the same output head.

**B3b details:** same data pipeline, same pooling, same head, **same RBF-expanded distance edge features** as B3a — the only difference is the graph-layer mechanism (`GATv2Conv` instead of cfconv). This keeps the comparison clean: we're testing "attention over edges" vs. "continuous-filter convolution over edges," not "with vs. without RBF." Reference: **Veličković et al., ICLR 2018, "Graph Attention Networks."**

**Why not EGNN / SE(3)-Transformer:** our edge features are interatomic distances, which are already SE(3)-invariant, and our targets are scalars, which are trivially equivariant. EGNN's main selling point (equivariance-by-construction) doesn't buy us much here, while its implementation and debugging cost is non-trivial at n=100. Mentioned in the report's discussion, not implemented. Reference: **Satorras, Hoogeboom, Welling, ICML 2021, "E(n) Equivariant Graph Neural Networks."**

## 6. Validation protocol

**Primary protocol: 5-fold cross-validation on sequence-identity-clustered splits.**

1. Run CD-HIT (or `mmseqs2 easy-cluster`) on all protein sequences at **70% identity**. Each cluster becomes an atomic unit that cannot be split across folds.
2. Assign clusters to 5 folds such that fold sizes are roughly balanced (by protein count).
3. For each fold `k`:
   - Train set: folds `≠ k`.
   - Val set: ~10% of the training **clusters** (not random proteins) held out for early stopping, so cluster integrity is preserved end-to-end.
   - Test set: fold `k`.
   - Fit target standardization and any feature standardization on train only.
4. Report per-fold metrics; overall result = mean ± std across folds.

**Metrics per target (Brightness, Emission, QY):**
- MAE (original scale)
- R² (original scale)
- Additionally, overall multi-output MAE (mean of standardized MAEs) for model selection.

**Bootstrapped test of improvement over B0:** paired bootstrap on fold-level MAE differences, 10k resamples, report 95% CI. A model that doesn't clear B0's CI is not considered to have learned anything.

**Current "plumbing test" with only 2 proteins:** train on one, test on one. Purpose is strictly to verify that the data loader, forward pass, loss, and training loop work; no conclusions drawn from numbers. Replaced by the 5-fold protocol once ~100 proteins are available.

## 7. Project structure & tooling

### 7.1 Tooling

- **Python env:** `uv` with `pyproject.toml` pinning dependencies and dev tools.
- **Config:** `Hydra` for all hyperparameters, model variant selection (`model=schnet|gat|esm2`), data options, and training settings. No hardcoded constants outside of the config tree.
- **Pre-commit:** `ruff` (lint + format), `mypy --strict` on `src/`, `nbstripout` if notebooks are used. Runs on every commit.
- **Experiment tracking:** TensorBoard locally; optional W&B via a Hydra flag.

### 7.2 Proposed directory layout

```
pdb_project/
├── pyproject.toml               # uv-managed, pins torch / pyg / biopython / hydra / esm
├── .pre-commit-config.yaml
├── conf/                        # Hydra configs
│   ├── config.yaml              # root
│   ├── data/default.yaml
│   ├── model/{schnet,gat,esm2,linear,constant}.yaml
│   ├── training/default.yaml
│   └── validation/cv5.yaml
├── src/pdb_project/
│   ├── data/
│   │   ├── pdb_parser.py        # PDB → residue/atom records
│   │   ├── graph_builder.py     # records → PyG Data
│   │   └── dataset.py           # PyG Dataset wrapper
│   ├── models/
│   │   ├── schnet.py            # cfconv blocks + protein/ligand encoders
│   │   ├── gat.py
│   │   ├── esm2_mlp.py
│   │   ├── linear.py            # B1
│   │   └── constant.py          # B0
│   ├── training/
│   │   ├── loop.py              # train/val/test loop
│   │   ├── metrics.py
│   │   └── splits.py            # CD-HIT / mmseqs2 wrapper + fold assignment
│   └── cli.py                   # Hydra entry point
├── scripts/
│   ├── run_cv.py                # 5-fold CV runner
│   └── plumbing_test.py         # single-protein sanity check
├── tests/
│   ├── test_parser.py
│   ├── test_graph.py
│   └── test_model_shapes.py
├── docs/superpowers/specs/      # this file
└── data/
    ├── raw/                     # PDB files
    └── labels.csv               # protein-level labels (Brightness, Emission, QY, kDa, …)
```

### 7.3 Reproducibility

- Seed torch, numpy, python random, and CUDA at the start of each run. Seed is a Hydra config value.
- Log the full resolved Hydra config with each run.
- Fold assignment is deterministic given the seed and the sequence-identity-cluster output.

## 8. Planned ablations (optional, time-permitting)

1. **Waters near NRQ.** Re-include HOH residues whose oxygen is within 5 Å of any NRQ heavy atom, as a 21st node type. Measures whether crystallographically resolved waters near the chromophore carry signal at our data scale.
2. **Protein-only vs. NRQ-only.** Drop one graph branch from B3a. Tells us which graph the model depends on.
3. **Distance cutoff vs. fully connected.** Replace fully connected protein edges with an 8 Å cutoff graph. Tests whether the inductive bias of locality helps.
4. **Single-target vs. multi-task.** Train three independent single-target heads; compare to the multi-task model. Tests whether auxiliary QY regularizes the other targets.

## 9. Risks & open questions

- **n=100 is small.** The most likely outcome is that the GNN either ties or loses to B2 (ESM-2 MLP). This is itself a valid scientific finding for the report.
- **Label noise.** Brightness/QY reported in databases like FPBase are aggregated from different measurement conditions. Expect a noise floor on the targets.
- **Chromophore variation.** The spec assumes NRQ is the ligand in every PDB. If some of the ~100 proteins have different chromophore resnames, the data pipeline needs a small branch (not addressed here).
- **ESM-2 model size.** The 650M-parameter variant may not fit alongside training on a laptop GPU. Fall back to `esm2_t12_35M_UR50D` if needed; the *fact* that a pretrained sequence model is included matters more than its exact size for B2's role.

## 10. References

- Schütt, K., Kindermans, P.-J., Sauceda, H., Chmiela, S., Tkatchenko, A., Müller, K.-R. *SchNet: A continuous-filter convolutional neural network for modeling quantum interactions.* NeurIPS 2017.
- Veličković, P., Cucurull, G., Casanova, A., Romero, A., Liò, P., Bengio, Y. *Graph Attention Networks.* ICLR 2018.
- Gilmer, J., Schoenholz, S., Riley, P., Vinyals, O., Dahl, G. *Neural Message Passing for Quantum Chemistry.* ICML 2017.
- Satorras, V., Hoogeboom, E., Welling, M. *E(n) Equivariant Graph Neural Networks.* ICML 2021.
- Lin, Z. et al. *Evolutionary-scale prediction of atomic-level protein structure (ESM-2).* Science, 2023.
