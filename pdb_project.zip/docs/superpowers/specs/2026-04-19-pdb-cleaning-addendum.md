# PDB Cleaning Addendum — Design Spec

**Date:** 2026-04-19
**Type:** Addendum to `2026-04-18-fluorescence-gnn-design.md`.
**Status:** Implemented in commits `177da6d`, `ce9c22e`, `6b95497`.
**Trigger:** Review of typical PDB preprocessing pitfalls before the 100-protein run.

## 1. Context

The original design spec (§3.1) described a minimal PDB parser that reads ATOM/HETATM records and splits them into standard residues, the NRQ ligand, and HOH waters. It did not address three well-known sources of downstream silent errors in PDB-driven ML pipelines: alternate conformations (altLoc), multi-chain deposits, and CSV-level label typos. This addendum documents the three small changes we made to close those gaps, and it records the preprocessing items we explicitly chose *not* to add and why.

## 2. Changes

### 2.1 altLoc filtering

**Problem.** When a crystallographer modeled two conformations of the same atom, the PDB has two (or more) ATOM lines with the same atom name but different altLoc indicators (column 17: typically `A` and `B`, occasionally `C`). The original parser appended all of them, which inflated atom counts (affecting COM) and created ambiguous bond assignments.

**Fix.** Keep atoms whose altLoc is blank (`" "` or `""`) or `"A"`; skip the rest. Rationale: `A` is the crystallographic primary-conformation convention. More sophisticated policies (highest occupancy, per-residue consensus) are not worth the complexity at n≈100.

**Code.** `src/pdb_project/data/pdb_parser.py` — `_parse_line` now returns `altloc`; `parse_pdb` skips atoms with `altloc not in (" ", "A", "")`.

**Test.** `tests/test_pdb_altloc.py` — synthetic residue with duplicate CA (altLoc A and B) plus a CB; expect 3 atoms kept, not 4.

### 2.2 Chain selection

**Problem.** Fluorescent-protein PDBs are often deposited as dimers or tetramers even when the biology is monomeric. Graphing all chains produces a protein graph N× larger than a monomer, destroying model input-size consistency across the dataset and contaminating residue-level COM computations.

**Fix.** Add an optional `chain` column to `labels.csv` (defaults to `"A"` when absent). `parse_pdb` now accepts a `chain: str | None` parameter; when set, only atoms on that chain are retained. `build_protein_graph` raises on an empty residue list rather than silently producing a 0-node graph.

**Code.**
- `src/pdb_project/data/labels.py` — `LabelRow.chain: str = "A"`; `load_labels` tolerates a missing `chain` column.
- `src/pdb_project/data/pdb_parser.py` — `parse_pdb(path, chain=None)`.
- `src/pdb_project/data/graph_builder.py` — `build_protein_graph` raises `ValueError` on empty residue list.
- `src/pdb_project/data/dataset.py` — passes `row.chain` to `parse_pdb`.

**Test.** `tests/test_chain_selection.py` — duplicate the 7ZCT row with a fake `chain=Z`; expect the Z row to raise on graph construction, while the `chain=A` row builds normally.

### 2.3 Label sanity checks at load time

**Problem.** A single typo in `labels.csv` (e.g., `qy=7.5` instead of `0.75`) silently trains the model on garbage and corrupts the aggregate metrics for an entire fold. Catching this at load time is strictly cheaper than discovering it in the results.

**Fix.** Validate every row in `load_labels` against basic fluorescent-protein physics:
- `brightness >= 0`
- `400 ≤ emission ≤ 800` (nm)
- `0 < qy ≤ 1`
- `10 ≤ kDa ≤ 100`

A failure raises `ValueError` naming the offending row.

**Code.** `src/pdb_project/data/labels.py` — `_validate_row(row)` called at the end of `load_labels`.

**Test.** `tests/test_label_sanity.py` — 5 cases: one per violated bound plus one valid row.

## 3. Explicitly NOT added (and why)

These were considered during the review and deferred. The design goal is to preprocess enough to prevent silent bugs without introducing hyperparameters that harm a dataset as small as n≈100.

| Item | Why deferred |
|------|--------------|
| Occupancy filtering | Partial-occupancy atoms (occ < 1) are rare and the signal lost by averaging over them is well below the label noise floor at n=100. Would add a threshold hyperparameter. |
| B-factor outlier trimming | Same rationale: high-B atoms are disproportionately in flexible loops, which contribute little to chromophore environment. |
| Geometry/clash detection | Re-doing crystallographic QC that deposition pipelines already enforce. Not our job. |
| Missing-residue reconstruction | Fluorescent-protein β-barrels rarely have unresolved residues in the chromophore-bearing region. Graph-side COM is robust to a 1–2 residue gap. |
| Target-outlier removal | At n=100, any "weird" protein is informative, not a data-quality issue. Throwing out tails would bias the model toward the mode of FPBase. |
| Brightness ↔ EC × QY / 1000 consistency check | Requires adding `EC value` to the CSV even though it's excluded from inputs (see design spec §2.2). Useful later, not now. |

## 4. Consequences for the rest of the pipeline

- **Dataset cache invalidation.** Adding altLoc filtering changes the residue/ligand atom counts for some PDBs. Any cached `data/cache/*.pt` from before commit `177da6d` is stale; clear it before training.
- **Label sanity errors are strict.** If a user adds a row with `qy=0` (some dark mutants report exactly zero), it will now fail. Intentional — the test run should raise and the user should update the bound or the row.
- **Default chain = A.** If a PDB's canonical chain is something other than A (rare for FPs), the `chain` column must be populated.
- **`parse_pdb` signature is a superset** of the original (new `chain=None` default), so all existing call sites continue to work unchanged.

## 5. References

Inherits from `2026-04-18-fluorescence-gnn-design.md`. No new references.
